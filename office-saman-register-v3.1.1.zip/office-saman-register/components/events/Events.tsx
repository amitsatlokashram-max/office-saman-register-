'use client';

// Events: Panchayat, Satsang, Samagam, Interview… — tareekh, jagah, kaun aaye the, data kisne diya / liya, kaunsi drives me hai.

import Link from 'next/link';
import { useRouter, useSearchParams } from 'next/navigation';
import { useEffect, useMemo, useState } from 'react';
import { CalendarDays, Database, HardDrive, Lock, Pencil, Plus, Printer, Trash2, Users } from 'lucide-react';
import { saveEvent, setEventDeleted, type EventInput } from '@/lib/assets/db';
import { copyState, gb, matches, nameKey, whereIs } from '@/lib/assets/model';
import { EVENT_TYPES, type AshramEvent } from '@/lib/assets/types';
import { distinct, today } from '@/lib/calc';
import { CatalogForm } from '../assets/CatalogForm';
import { useAssets } from '../assets/store';
import { useReg } from '../context';
import { PrintDesignerModal, type PrintTable } from '../print/PrintDesigner';
import { DataTable, type Col } from '../ui/DataTable';
import { Badge, Card, Empty, Field, Modal, PageHeader, Stat, fmtDate, useBusy } from '../ui';

const fd = (s: string) => (s ? fmtDate(s) : '—');
const list = (s: string) => s.split(/[,\n]+/).map((x) => x.trim()).filter(Boolean);

export function EventsPage() {
  const A = useAssets();
  const router = useRouter();
  const sp = useSearchParams();
  const [form, setForm] = useState<AshramEvent | 'new' | null>(null);
  const [type, setType] = useState('');
  const [year, setYear] = useState('');
  const [who, setWho] = useState('');
  useEffect(() => {
    if (sp.get('new') === '1' && A.can('events', 'create')) setForm('new');
  }, [sp, A]);

  const rows = useMemo(
    () =>
      A.events.filter(
        (e) =>
          (!type || e.type === type) &&
          (!year || e.date.startsWith(year)) &&
          (!who || matches([...e.participants, ...e.mainPersons, ...e.recordingTeam, e.submittedBy, e.receivedBy, e.responsible].join(' '), who)),
      ),
    [A.events, type, year, who],
  );
  const years = distinct(A.events.map((e) => e.date.slice(0, 4))).sort().reverse();
  const dataOf = (id: string) => A.catalog.filter((c) => c.eventId === id);

  const cols: Col<AshramEvent>[] = [
    { key: 'date', label: 'Date', value: (e) => e.date, render: (e) => <span className="nowrap">{fd(e.date)}</span>, card: true },
    { key: 'type', label: 'Type', value: (e) => e.type, render: (e) => <Badge tone="violet" plain>{e.type}</Badge>, card: true },
    { key: 'title', label: 'Title', value: (e) => e.title, render: (e) => (
      <span>
        <b>{e.title}</b> {e.confidential && <Lock aria-label="Confidential" className="ic" style={{ width: 14, height: 14, verticalAlign: -2 }} />}
        {e.eventNo && <div className="u-faint u-sm">{e.eventNo}</div>}
      </span>
    ) },
    { key: 'location', label: 'Location', value: (e) => e.location, render: (e) => e.location || '—', card: true },
    { key: 'people', label: 'Persons present', value: (e) => e.participants.length, render: (e) => <span className="u-sm">{[...e.mainPersons, ...e.participants.filter((p) => !e.mainPersons.includes(p))].slice(0, 6).join(', ')}{e.participants.length > 6 ? ' +' + (e.participants.length - 6) : ''}</span> },
    { key: 'submitted', label: 'Data submitted by', value: (e) => e.submittedBy, render: (e) => e.submittedBy || '—', hidden: true },
    { key: 'received', label: 'Data received by', value: (e) => e.receivedBy, render: (e) => e.receivedBy || '—', hidden: true },
    { key: 'data', label: 'Data / drives', num: true, value: (e) => dataOf(e.id).length, render: (e) => {
      const d = dataOf(e.id);
      const dr = new Set(d.map((c) => c.driveId));
      return d.length ? d.length + ' · ' + dr.size + ' drive' : '—';
    }, card: true },
  ];

  return (
    <>
      <PageHeader
        title="Events"
        sub="Panchayat, Satsang, Samagam, Interview… kis din, kahan, kaun aaye the, aur unka data kaunsi drive me hai."
        actions={
          A.can('events', 'create') && (
            <button type="button" className="btn primary" onClick={() => setForm('new')}>
              <Plus aria-hidden className="ic" /> New event
            </button>
          )
        }
      />
      <div className="u-grid c4">
        <Stat index={0} label="Events" value={A.events.length} icon={CalendarDays} />
        <Stat index={1} label="This year" value={A.events.filter((e) => e.date.startsWith(today().slice(0, 4))).length} icon={CalendarDays} tone="violet" />
        <Stat index={2} label="Events with data" value={A.events.filter((e) => dataOf(e.id).length).length} icon={Database} tone="green" />
        <Stat index={3} label="Events without data" value={A.events.filter((e) => !dataOf(e.id).length).length} icon={HardDrive} tone="amber" sub="Data abhi kisi drive se nahi juda" />
      </div>
      <DataTable
        id="events"
        rows={rows}
        cols={cols}
        exportName="events"
        canExport={A.can('events', 'export')}
        searchText={(e) => [e.eventNo, e.title, e.type, e.location, e.description, e.project, e.episode, ...e.participants, ...e.mainPersons, ...e.recordingTeam, e.submittedBy, e.receivedBy, e.responsible, ...e.tags].join(' ')}
        onRow={(e) => router.push('/events/' + e.id)}
        cardTitle={(e) => <b>{e.title}</b>}
        initialSort={{ key: 'date', dir: 'desc' }}
        toolbar={
          <>
            <select value={type} onChange={(e) => setType(e.target.value)} aria-label="Event type">
              <option value="">All types</option>
              {distinct([...EVENT_TYPES, ...A.events.map((e) => e.type)]).map((t) => (
                <option key={t}>{t}</option>
              ))}
            </select>
            {years.length > 0 && (
              <select value={year} onChange={(e) => setYear(e.target.value)} aria-label="Year">
                <option value="">All years</option>
                {years.map((y) => (
                  <option key={y}>{y}</option>
                ))}
              </select>
            )}
            <input value={who} onChange={(e) => setWho(e.target.value)} placeholder="Kaun aaye the (naam)" list="dl-allpeople" style={{ maxWidth: 220, background: 'var(--surface)' }} aria-label="Person present" />
          </>
        }
        empty={<Empty icon={CalendarDays} title="Abhi koi event nahi">Panchayat / Satsang ka record banao, phir uska data drive se jodo.</Empty>}
      />
      {form && <EventForm ev={form === 'new' ? null : form} onClose={() => setForm(null)} onSaved={(id) => router.push('/events/' + id)} />}
    </>
  );
}

export function EventForm({ ev, onClose, onSaved }: { ev: AshramEvent | null; onClose: () => void; onSaved?: (id: string) => void }) {
  const { me, toast } = useReg();
  const A = useAssets();
  const [v, setV] = useState({
    title: ev?.title || '',
    type: ev?.type || 'Panchayat',
    date: ev?.date || today(),
    time: ev?.time || '',
    recordingDate: ev?.recordingDate || '',
    location: ev?.location || '',
    description: ev?.description || '',
    participants: ev?.participants.join(', ') || '',
    mainPersons: ev?.mainPersons.join(', ') || '',
    recordingTeam: ev?.recordingTeam.join(', ') || '',
    submittedBy: ev?.submittedBy || '',
    receivedBy: ev?.receivedBy || '',
    responsible: ev?.responsible || '',
    project: ev?.project || '',
    episode: ev?.episode || '',
    tags: ev?.tags.join(', ') || '',
    links: ev?.links.join('\n') || '',
    notes: ev?.notes || '',
    confidential: !!ev?.confidential,
  });
  const [err, setErr] = useState('');
  const [busy, run] = useBusy();
  const set = (k: keyof typeof v, x: string | boolean) => setV((p) => ({ ...p, [k]: x }));
  const dup = !ev && A.events.find((e) => e.date === v.date && e.type === v.type && nameKey(e.title) === nameKey(v.title));
  return (
    <Modal
      open
      size="lg"
      onClose={onClose}
      title={ev ? 'Edit event' : 'New event'}
      sub={ev?.eventNo}
      onSubmit={() =>
        run(async () => {
          setErr('');
          if (!v.title.trim()) return setErr('Event ka title likho.');
          const data: EventInput = {
            title: v.title.trim(),
            type: v.type,
            date: v.date,
            time: v.time,
            recordingDate: v.recordingDate,
            location: v.location.trim(),
            description: v.description.trim(),
            participants: list(v.participants),
            mainPersons: list(v.mainPersons),
            recordingTeam: list(v.recordingTeam),
            submittedBy: v.submittedBy.trim(),
            receivedBy: v.receivedBy.trim(),
            responsible: v.responsible.trim(),
            project: v.project.trim(),
            episode: v.episode.trim(),
            tags: list(v.tags),
            links: v.links.split(/\s+/).filter((x) => /^https?:\/\//.test(x)),
            notes: v.notes.trim(),
            confidential: v.confidential,
          };
          try {
            const id = await saveEvent(data, me, ev?.id);
            toast('✓ Event saved');
            onClose();
            onSaved?.(id);
          } catch {
            setErr('Save nahi hua (ijaazat ya internet).');
          }
        })
      }
      foot={
        <>
          <button type="button" className="btn" onClick={onClose}>
            Cancel
          </button>
          <button type="submit" className="btn primary" disabled={busy}>
            {busy ? 'Saving…' : 'Save event'}
          </button>
        </>
      }
    >
      {err && <div className="ferr">{err}</div>}
      {dup && <div className="ferr">Isi tareekh ka isi naam ka {v.type} pehle se hai ({dup.eventNo}). Dobara mat banao — us event me hi data jodo.</div>}
      <div className="fgrid g3">
        <Field label="Type">
          <select value={v.type} onChange={(e) => set('type', e.target.value)}>
            {distinct([...EVENT_TYPES, ...A.events.map((e) => e.type)]).map((t) => (
              <option key={t}>{t}</option>
            ))}
          </select>
        </Field>
        <Field label="Title" span>
          <input value={v.title} onChange={(e) => set('title', e.target.value)} required maxLength={200} placeholder="Jaise: Gaon ki Panchayat — paani ka masla" autoFocus />
        </Field>
        <Field label="Event date">
          <input type="date" value={v.date} onChange={(e) => set('date', e.target.value)} />
        </Field>
        <Field label="Time">
          <input type="time" value={v.time} onChange={(e) => set('time', e.target.value)} />
        </Field>
        <Field label="Recording date (alag ho to)">
          <input type="date" value={v.recordingDate} onChange={(e) => set('recordingDate', e.target.value)} />
        </Field>
        <Field label="Location">
          <input value={v.location} onChange={(e) => set('location', e.target.value)} list="dl-places" maxLength={200} />
        </Field>
        <Field label="Project">
          <input value={v.project} onChange={(e) => set('project', e.target.value)} list="dl-projects" />
        </Field>
        <Field label="Episode no.">
          <input value={v.episode} onChange={(e) => set('episode', e.target.value)} />
        </Field>
        <Field label="Persons present (comma se alag)" span hint="Inhi naamo se baad me event dhoondh sakte ho">
          <textarea rows={2} value={v.participants} onChange={(e) => set('participants', e.target.value)} />
        </Field>
        <Field label="Main persons (comma)">
          <input value={v.mainPersons} onChange={(e) => set('mainPersons', e.target.value)} />
        </Field>
        <Field label="Recording team / camera (comma)" span>
          <input value={v.recordingTeam} onChange={(e) => set('recordingTeam', e.target.value)} />
        </Field>
        <Field label="Data kisne diya (submitted by)">
          <input value={v.submittedBy} onChange={(e) => set('submittedBy', e.target.value)} list="dl-allpeople" />
        </Field>
        <Field label="Data kisne liya (received by)">
          <input value={v.receivedBy} onChange={(e) => set('receivedBy', e.target.value)} list="dl-allpeople" />
        </Field>
        <Field label="Zimmedar (responsible)">
          <input value={v.responsible} onChange={(e) => set('responsible', e.target.value)} list="dl-allpeople" />
        </Field>
        <Field label="Description" span>
          <textarea rows={3} value={v.description} onChange={(e) => set('description', e.target.value)} maxLength={5000} />
        </Field>
        <Field label="Tags (comma)">
          <input value={v.tags} onChange={(e) => set('tags', e.target.value)} />
        </Field>
        <Field label="Published video links (har line me ek)" span>
          <textarea rows={2} value={v.links} onChange={(e) => set('links', e.target.value)} />
        </Field>
        <Field label="Note" span>
          <input value={v.notes} onChange={(e) => set('notes', e.target.value)} />
        </Field>
        <label className="u-check">
          <input type="checkbox" checked={v.confidential} onChange={(e) => set('confidential', e.target.checked)} /> Confidential (gopniya)
        </label>
      </div>
    </Modal>
  );
}

export function EventDetail({ id }: { id: string }) {
  const A = useAssets();
  const { me, toast } = useReg();
  const router = useRouter();
  const ev = A.allEvents.find((e) => e.id === id);
  const [edit, setEdit] = useState(false);
  const [add, setAdd] = useState(false);
  const [print, setPrint] = useState<PrintTable | null>(null);
  if (!A.loaded.events) return <p className="u-muted">Loading…</p>;
  if (!ev)
    return (
      <Card>
        <Empty icon={CalendarDays} title="Event nahi mila" action={<Link className="btn" href="/events">All events</Link>} />
      </Card>
    );
  const data = A.catalog.filter((c) => c.eventId === ev.id);
  const drives = Array.from(new Set(data.map((c) => c.driveId))).map((d) => A.driveMap.get(d)).filter((d): d is NonNullable<typeof d> => !!d);
  const person = (n: string) =>
    n ? (
      <Link key={n} href={'/persons/' + encodeURIComponent(nameKey(n))} className="u-chip">
        {n}
      </Link>
    ) : null;
  return (
    <>
      <PageHeader
        title={
          <span className="u-row" style={{ gap: 10 }}>
            {ev.title} <Badge tone="violet" plain>{ev.type}</Badge> {ev.confidential && <Badge tone="red">Confidential</Badge>} {ev.deletedAt && <Badge tone="red">Deleted</Badge>}
          </span>
        }
        sub={[ev.eventNo, fd(ev.date) + (ev.time ? ' ' + ev.time : ''), ev.location].filter(Boolean).join(' · ')}
        actions={
          <>
            {A.can('catalog', 'create') && (
              <button type="button" className="btn primary" onClick={() => setAdd(true)} disabled={!A.drives.length}>
                <Plus aria-hidden className="ic" /> Add data (drive)
              </button>
            )}
            {A.can('events', 'edit') && (
              <button type="button" className="btn" onClick={() => setEdit(true)}>
                <Pencil aria-hidden className="ic" /> Edit
              </button>
            )}
            <button
              type="button"
              className="btn"
              onClick={() =>
                setPrint({
                  title: ev.type + ': ' + ev.title,
                  subtitle: [ev.eventNo, fd(ev.date), ev.location].filter(Boolean).join(' · '),
                  blocks: [
                    { label: 'Persons present', value: ev.participants.join(', ') || '—' },
                    { label: 'Main persons', value: ev.mainPersons.join(', ') || '—' },
                    { label: 'Recording team', value: ev.recordingTeam.join(', ') || '—' },
                    { label: 'Data submitted by', value: ev.submittedBy || '—' },
                    { label: 'Data received by', value: ev.receivedBy || '—' },
                    { label: 'Description', value: ev.description || '—' },
                  ],
                  head: ['Data', 'Category', 'Drive', 'Drive is', 'Folder', 'Size', 'Backup'],
                  align: ['left', 'left', 'left', 'left', 'left', 'right', 'left'],
                  sections: [
                    {
                      rows: data.map((c) => {
                        const d = A.driveMap.get(c.driveId);
                        const s = copyState(c, A.backups);
                        return [[c.project, c.title].filter(Boolean).join(' · '), c.category, d?.displayName || '', d ? whereIs(d, A.locMap) : '', c.folderPath, c.sizeGB ? gb(c.sizeGB) : '', s.state === 'none' ? 'Single copy' : s.copies + ' copy'];
                      }),
                    },
                  ],
                })
              }
            >
              <Printer aria-hidden className="ic" /> Print
            </button>
            {A.can('events', 'delete') && !ev.deletedAt && (
              <button
                type="button"
                className="btn quiet-danger"
                aria-label="Delete event"
                onClick={async () => {
                  if (!window.confirm('Event delete (recycle bin) karna hai? Data records nahi mitenge.')) return;
                  await setEventDeleted(ev, true, me).then(() => toast('✓ Deleted'), () => toast('Nahi hua'));
                  router.push('/events');
                }}
              >
                <Trash2 aria-hidden className="ic" />
              </button>
            )}
          </>
        }
      />
      <div className="u-grid span-2-1">
        <div className="u-stack">
          <Card title={'Data (' + data.length + ')'} sub="Is event ki recording / files kaunsi drive me, wo drive abhi kahan">
            {data.length === 0 ? (
              <Empty icon={Database} title="Abhi koi data nahi juda">
                &ldquo;Add data&rdquo; se batao kaunsi drive me kaunse folder me is event ki recording hai.
              </Empty>
            ) : (
              <table className="u-table">
                <thead>
                  <tr>
                    <th>Data</th>
                    <th>Drive</th>
                    <th>Drive is</th>
                    <th>Folder</th>
                    <th className="num">Size</th>
                    <th>Backup</th>
                  </tr>
                </thead>
                <tbody>
                  {data.map((c) => {
                    const d = A.driveMap.get(c.driveId);
                    const s = copyState(c, A.backups);
                    return (
                      <tr key={c.id} className="click" onClick={() => router.push('/catalog?open=' + c.id)}>
                        <td>
                          <b>{[c.project, c.title].filter(Boolean).join(' · ')}</b>
                          <div className="u-sm u-muted">{c.category}</div>
                        </td>
                        <td>{d ? <Link className="u-link" href={'/drives/' + d.id} onClick={(e) => e.stopPropagation()}>{d.displayName}</Link> : '—'}</td>
                        <td className="u-sm">{d ? whereIs(d, A.locMap) : '—'}</td>
                        <td className="u-mono u-sm">{c.folderPath || '—'}</td>
                        <td className="num">{c.sizeGB ? gb(c.sizeGB) : '—'}</td>
                        <td>
                          <Badge tone={s.state === 'verified' ? 'green' : s.state === 'none' ? 'red' : 'amber'}>{s.state === 'none' ? 'Single copy' : s.copies + ' copy'}</Badge>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            )}
          </Card>
          {ev.description && (
            <Card title="Description">
              <p style={{ whiteSpace: 'pre-wrap' }}>{ev.description}</p>
            </Card>
          )}
        </div>
        <div className="u-stack">
          <Card title="Log">
            <dl className="u-kv" style={{ gridTemplateColumns: '1fr' }}>
              <div>
                <dt>Persons present ({ev.participants.length})</dt>
                <dd className="u-row">{ev.participants.map(person)}</dd>
              </div>
              {ev.mainPersons.length > 0 && (
                <div>
                  <dt>Main persons</dt>
                  <dd className="u-row">{ev.mainPersons.map(person)}</dd>
                </div>
              )}
              {ev.recordingTeam.length > 0 && (
                <div>
                  <dt>Recording team</dt>
                  <dd className="u-row">{ev.recordingTeam.map(person)}</dd>
                </div>
              )}
              <div>
                <dt>Data submitted by → received by</dt>
                <dd className="u-row">
                  {person(ev.submittedBy) || '—'} → {person(ev.receivedBy) || '—'}
                </dd>
              </div>
              {ev.responsible && (
                <div>
                  <dt>Responsible</dt>
                  <dd>{person(ev.responsible)}</dd>
                </div>
              )}
              {(ev.project || ev.episode) && (
                <div>
                  <dt>Project / episode</dt>
                  <dd>{[ev.project, ev.episode && 'Ep ' + ev.episode].filter(Boolean).join(' · ')}</dd>
                </div>
              )}
              {ev.recordingDate && (
                <div>
                  <dt>Recording date</dt>
                  <dd>{fd(ev.recordingDate)}</dd>
                </div>
              )}
              {ev.tags.length > 0 && (
                <div>
                  <dt>Tags</dt>
                  <dd>{ev.tags.join(', ')}</dd>
                </div>
              )}
              {ev.links.length > 0 && (
                <div>
                  <dt>Published</dt>
                  <dd>
                    {ev.links.map((l) => (
                      <a key={l} href={l} target="_blank" rel="noreferrer" className="u-link" style={{ display: 'block' }}>
                        {l}
                      </a>
                    ))}
                  </dd>
                </div>
              )}
              {ev.notes && (
                <div>
                  <dt>Note</dt>
                  <dd>{ev.notes}</dd>
                </div>
              )}
            </dl>
          </Card>
          <Card title={'Drives (' + drives.length + ')'}>
            {drives.length === 0 ? (
              <p className="u-muted">—</p>
            ) : (
              drives.map((d) => (
                <div key={d.id} className="u-between" style={{ padding: '6px 0' }}>
                  <Link className="u-link" href={'/drives/' + d.id}>
                    <HardDrive aria-hidden className="ic" style={{ width: 15, height: 15, verticalAlign: -3 }} /> {d.displayName}
                  </Link>
                  <span className="u-sm u-muted">{whereIs(d, A.locMap)}</span>
                </div>
              ))
            )}
            <p className="hint" style={{ marginTop: 8 }}>
              <Users aria-hidden className="ic" style={{ width: 13, height: 13, verticalAlign: -2 }} /> Created {fd(ev.createdAt)} by {ev.createdByName}
            </p>
          </Card>
        </div>
      </div>
      {edit && <EventForm ev={ev} onClose={() => setEdit(false)} />}
      <CatalogForm open={add} onClose={() => setAdd(false)} entry={null} preset={{ eventId: ev.id, eventName: ev.title, eventDate: ev.date, year: ev.date.slice(0, 4), project: ev.project || ev.type, episode: ev.episode, owner: ev.receivedBy || ev.responsible, recordingDate: ev.recordingDate || ev.date, status: 'Registered' }} />
      {print && <PrintDesignerModal open onClose={() => setPrint(null)} doc={print} storeKey="event" />}
    </>
  );
}
