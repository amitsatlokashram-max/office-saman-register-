'use client';

import { useRouter, useSearchParams } from 'next/navigation';
import { useEffect, useMemo, useState } from 'react';
import { ArrowDown, ArrowUp, BookmarkPlus, FileSpreadsheet, FileText, Printer, Trash2 } from 'lucide-react';
import { deleteReport, saveReport, subscribeSavedReports, type SavedReport } from '@/lib/assets/db';
import { toCsv } from '@/lib/assets/csv';
import { saveFile } from '@/lib/bills';
import { distinct } from '@/lib/calc';
import { aliasMap, buildLedger } from '@/lib/people';
import { DATASETS, blankSpec, fmtCell, runReport, type Spec } from '@/lib/reports';
import { useAssets } from '../assets/store';
import { useReg } from '../context';
import { PrintDesignerModal, type PrintTable } from '../print/PrintDesigner';
import { Card, Empty, Field, PageHeader } from '../ui';
import type { Action, Module } from '@/lib/perm';

export function useSources() {
  const { items, groups } = useReg();
  const A = useAssets();
  return useMemo(() => {
    const am = aliasMap(A.persons);
    return {
      am,
      src: {
        items,
        groups,
        ledger: buildLedger(items, am),
        drives: A.drives,
        transfers: A.transfers,
        catalog: A.catalog,
        events: A.events,
        backups: A.backups,
        locs: A.locMap,
        driveMap: A.driveMap,
        asOf: '',
      },
    };
  }, [items, groups, A]);
}

export async function exportXlsx(name: string, head: string[], rows: (string | number)[][], types: string[]) {
  const { default: writeXlsxFile } = await import('write-excel-file/browser');
  const data = [
    head.map((h) => ({ value: h, fontWeight: 'bold' as const })),
    ...rows.map((r) => r.map((v, i) => (types[i] === 'number' || types[i] === 'money' ? { value: Number(v) || 0, type: Number } : { value: String(v ?? ''), type: String }))),
  ];
  await writeXlsxFile(data as never, { sheet: 'Report', columns: head.map((h) => ({ width: Math.min(50, Math.max(10, h.length + 4)) })) } as never).toFile(name.replace(/[^\w\- ]+/g, '_') + '.xlsx');
}

export function ReportBuilder() {
  const A = useAssets();
  const { me, toast } = useReg();
  const sp = useSearchParams();
  const router = useRouter();
  const { src } = useSources();
  const [spec, setSpec] = useState<Spec>(() => blankSpec());
  const [saved, setSaved] = useState<SavedReport[]>([]);
  const [printOpen, setPrintOpen] = useState(false);
  const [savedId, setSavedId] = useState('');

  const allowed = DATASETS.filter((d) => A.can(d.need as Module, 'view' as Action));

  useEffect(() => {
    const ds = sp.get('dataset');
    if (ds && DATASETS.some((d) => d.id === ds)) {
      const b = blankSpec(ds);
      setSpec({ ...b, person: sp.get('person') || '', dept: sp.get('dept') || '', drive: sp.get('drive') || '', event: sp.get('event') || '', location: sp.get('location') || '', item: sp.get('item') || '' });
    }
  }, [sp]);
  useEffect(() => (me?.uid ? subscribeSavedReports(me.uid, setSaved) : undefined), [me?.uid]);

  const res = useMemo(() => runReport(spec, src), [spec, src]);
  const D = res.D;
  const set = (p: Partial<Spec>) => setSpec((s) => ({ ...s, ...p }));
  const statuses = useMemo(() => distinct(D.rows(src).map((r) => String(r.status ?? ''))), [D, src]);

  const cell = (r: Record<string, unknown>, k: string) => {
    const c = D.cols.find((x) => x.key === k)!;
    return fmtCell(c, c.get(r));
  };
  const footRow = (tot: Record<string, number>, label: string) => res.cols.map((c, i) => (c.key in tot ? fmtCell(c, tot[c.key]) : i === 0 ? label : ''));

  const doc: PrintTable = {
    title: spec.title || D.label,
    subtitle: filterText(spec),
    meta: [res.rows.length + ' rows'],
    head: res.cols.map((c) => c.label),
    align: res.cols.map((c) => (c.type === 'number' || c.type === 'money' ? 'right' : 'left')),
    sections: res.groups.length
      ? res.groups.map((g) => ({ heading: g.key + ' (' + g.rows.length + ')', rows: g.rows.map((r) => res.cols.map((c) => cell(r, c.key))), foot: Object.keys(g.totals).length ? footRow(g.totals, 'Subtotal') : undefined }))
      : [{ rows: res.rows.map((r) => res.cols.map((c) => cell(r, c.key))) }],
    grandFoot: Object.keys(res.grand).length ? footRow(res.grand, 'Total') : undefined,
  };

  const exportData = () => {
    const head = res.cols.map((c) => c.label);
    const rows = res.rows.map((r) => res.cols.map((c) => (c.type === 'date' ? fmtCell(c, c.get(r)) : c.get(r))));
    return { head, rows, types: res.cols.map((c) => c.type) };
  };

  const moveCol = (k: string, dir: -1 | 1) =>
    setSpec((s) => {
      const a = s.cols.slice();
      const i = a.indexOf(k);
      const j = i + dir;
      if (i < 0 || j < 0 || j >= a.length) return s;
      [a[i], a[j]] = [a[j], a[i]];
      return { ...s, cols: a };
    });

  const canExport = A.can('reports', 'export');

  return (
    <>
      <PageHeader
        title="Report Builder"
        sub="Kisi bhi cheez ki report: bande, department, jagah, tareekh, item, drive, event — filter, column, group, total. Print / PDF / Excel."
        actions={
          <>
            <button type="button" className="btn" onClick={() => setPrintOpen(true)} disabled={!res.rows.length}>
              <Printer aria-hidden className="ic" /> Print / PDF
            </button>
            {canExport && (
              <>
                <button
                  type="button"
                  className="btn"
                  disabled={!res.rows.length}
                  onClick={() => {
                    const e = exportData();
                    exportXlsx(spec.title || D.label, e.head, e.rows, e.types).catch(() => toast('Excel nahi bana'));
                  }}
                >
                  <FileSpreadsheet aria-hidden className="ic" /> Excel
                </button>
                <button
                  type="button"
                  className="btn"
                  disabled={!res.rows.length}
                  onClick={() => {
                    const e = exportData();
                    saveFile((spec.title || D.label).replace(/[^\w\- ]+/g, '_') + '.csv', new Blob([toCsv(e.head, e.rows)], { type: 'text/csv;charset=utf-8' }));
                  }}
                >
                  <FileText aria-hidden className="ic" /> CSV
                </button>
              </>
            )}
          </>
        }
      />
      <div className="u-grid sidecol">
        <div className="u-stack">
          <Card title="Report">
            <div className="u-stack">
              <Field label="Kis cheez ki report">
                <select
                  value={spec.dataset}
                  onChange={(e) => {
                    setSavedId('');
                    setSpec(blankSpec(e.target.value));
                    router.replace('/reports');
                  }}
                >
                  {allowed.map((d) => (
                    <option key={d.id} value={d.id}>
                      {d.label}
                    </option>
                  ))}
                </select>
              </Field>
              <p className="hint">{D.hint}</p>
              <Field label="Report ka title">
                <input value={spec.title} onChange={(e) => set({ title: e.target.value })} />
              </Field>
              {D.dateKey && (
                <div className="fgrid">
                  <Field label="From date">
                    <input type="date" value={spec.from} onChange={(e) => set({ from: e.target.value })} />
                  </Field>
                  <Field label="To date">
                    <input type="date" value={spec.to} onChange={(e) => set({ to: e.target.value })} />
                  </Field>
                </div>
              )}
              {(D.id === 'holdings' || D.id === 'ledger') && (
                <Field label="As of date (us din tak ka hisaab)" hint="Khaali = aaj tak">
                  <input type="date" value={spec.asOf} onChange={(e) => set({ asOf: e.target.value })} />
                </Field>
              )}
              <div className="fgrid">
                {D.filters.includes('person') && (
                  <Field label="Person">
                    <input value={spec.person} onChange={(e) => set({ person: e.target.value })} list="dl-allpeople" />
                  </Field>
                )}
                {D.filters.includes('dept') && (
                  <Field label="Department">
                    <input value={spec.dept} onChange={(e) => set({ dept: e.target.value })} list="dl-depts" />
                  </Field>
                )}
                {D.filters.includes('location') && (
                  <Field label="Location / jagah">
                    <input value={spec.location} onChange={(e) => set({ location: e.target.value })} list="dl-places" />
                  </Field>
                )}
                {D.filters.includes('item') && (
                  <Field label="Item">
                    <input value={spec.item} onChange={(e) => set({ item: e.target.value })} list="dl-item" />
                  </Field>
                )}
                {D.filters.includes('category') && (
                  <Field label="Category / type">
                    <input value={spec.category} onChange={(e) => set({ category: e.target.value })} />
                  </Field>
                )}
                {D.filters.includes('drive') && (
                  <Field label="Drive">
                    <input value={spec.drive} onChange={(e) => set({ drive: e.target.value })} />
                  </Field>
                )}
                {D.filters.includes('event') && (
                  <Field label="Event">
                    <input value={spec.event} onChange={(e) => set({ event: e.target.value })} />
                  </Field>
                )}
                {D.filters.includes('status') && statuses.length > 0 && (
                  <Field label="Status">
                    <select value={spec.status} onChange={(e) => set({ status: e.target.value })}>
                      <option value="">All</option>
                      {statuses.map((x) => (
                        <option key={x} value={x}>
                          {x}
                        </option>
                      ))}
                    </select>
                  </Field>
                )}
              </div>
              <Field label="Kisi bhi column me dhoondho">
                <input value={spec.q} onChange={(e) => set({ q: e.target.value })} />
              </Field>
              <div className="fgrid">
                <Field label="Group by">
                  <select value={spec.groupBy} onChange={(e) => set({ groupBy: e.target.value })}>
                    <option value="">No grouping</option>
                    {D.cols
                      .filter((c) => c.type === 'text' || c.type === 'date')
                      .map((c) => (
                        <option key={c.key} value={c.key}>
                          {c.label}
                        </option>
                      ))}
                  </select>
                </Field>
                <Field label="Sort by">
                  <select value={spec.sortBy} onChange={(e) => set({ sortBy: e.target.value })}>
                    {D.cols.map((c) => (
                      <option key={c.key} value={c.key}>
                        {c.label}
                      </option>
                    ))}
                  </select>
                </Field>
              </div>
              <select value={spec.sortDir} onChange={(e) => set({ sortDir: e.target.value as 'asc' | 'desc' })} aria-label="Sort direction">
                <option value="asc">Ascending (A→Z, purana pehle)</option>
                <option value="desc">Descending (Z→A, naya pehle)</option>
              </select>
            </div>
          </Card>
          <Card title="Columns" sub="Tick = dikhega · arrows se order">
            <div className="u-stack" style={{ gap: 4 }}>
              {spec.cols.map((k) => {
                const c = D.cols.find((x) => x.key === k);
                if (!c) return null;
                return (
                  <div key={k} className="u-between" style={{ flexWrap: 'nowrap' }}>
                    <label className="u-check">
                      <input type="checkbox" checked onChange={() => set({ cols: spec.cols.filter((x) => x !== k) })} /> {c.label}
                    </label>
                    <span className="u-row" style={{ gap: 2, flexWrap: 'nowrap' }}>
                      <button type="button" className="u-iconbtn" style={{ width: 30, height: 30 }} onClick={() => moveCol(k, -1)} aria-label={'Move ' + c.label + ' up'}>
                        <ArrowUp aria-hidden />
                      </button>
                      <button type="button" className="u-iconbtn" style={{ width: 30, height: 30 }} onClick={() => moveCol(k, 1)} aria-label={'Move ' + c.label + ' down'}>
                        <ArrowDown aria-hidden />
                      </button>
                    </span>
                  </div>
                );
              })}
              {D.cols
                .filter((c) => !spec.cols.includes(c.key))
                .map((c) => (
                  <label key={c.key} className="u-check u-muted">
                    <input type="checkbox" checked={false} onChange={() => set({ cols: [...spec.cols, c.key] })} /> {c.label}
                  </label>
                ))}
            </div>
          </Card>
          <Card title="Saved reports">
            <div className="u-stack">
              <div className="u-row" style={{ flexWrap: 'nowrap' }}>
                <button
                  type="button"
                  className="btn sm"
                  onClick={async () => {
                    if (!me?.uid) return;
                    const name = window.prompt('Report ka naam', spec.title || D.label);
                    if (!name) return;
                    try {
                      const id = await saveReport(me.uid, name, spec as unknown as Record<string, unknown>, savedId || undefined);
                      setSavedId(id);
                      toast('✓ Report saved');
                    } catch {
                      toast('Save nahi hua');
                    }
                  }}
                >
                  <BookmarkPlus aria-hidden className="ic" /> {savedId ? 'Update saved' : 'Save this report'}
                </button>
              </div>
              {saved.length === 0 ? (
                <p className="hint">Abhi koi saved report nahi.</p>
              ) : (
                saved.map((r) => (
                  <div key={r.id} className="u-between" style={{ flexWrap: 'nowrap' }}>
                    <button
                      type="button"
                      className="u-link u-ell"
                      style={{ textAlign: 'left' }}
                      onClick={() => {
                        setSavedId(r.id);
                        setSpec({ ...blankSpec(String(r.spec.dataset || 'ledger')), ...(r.spec as Partial<Spec>) });
                      }}
                    >
                      {r.name}
                    </button>
                    <button type="button" className="u-iconbtn" aria-label={'Delete ' + r.name} onClick={() => window.confirm('Delete "' + r.name + '"?') && deleteReport(r.id)}>
                      <Trash2 aria-hidden />
                    </button>
                  </div>
                ))
              )}
            </div>
          </Card>
        </div>

        <Card title={(spec.title || D.label) + ' — ' + res.rows.length + ' rows'} sub={filterText(spec)}>
          {res.rows.length === 0 ? (
            <Empty icon={FileText} title="Is filter me kuch nahi mila" />
          ) : (
            <div className="u-table-wrap" style={{ maxHeight: '75vh' }}>
              <table className="u-table">
                <thead>
                  <tr>
                    {res.cols.map((c) => (
                      <th key={c.key} className={c.type === 'number' || c.type === 'money' ? 'num' : undefined}>
                        {c.label}
                      </th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {(res.groups.length ? res.groups : [{ key: '', rows: res.rows.slice(0, 2000), totals: {} as Record<string, number> }]).map((g) => (
                    <GroupRows key={g.key || '_'} g={g} cols={res.cols} cell={cell} foot={g.key ? footRow(g.totals, 'Subtotal') : null} />
                  ))}
                </tbody>
                {Object.keys(res.grand).length > 0 && (
                  <tfoot>
                    <tr>
                      {footRow(res.grand, 'Total (' + res.rows.length + ')').map((f, i) => (
                        <td key={i} className={res.cols[i].type === 'number' || res.cols[i].type === 'money' ? 'num' : undefined} style={{ fontWeight: 800, background: 'var(--table-head)', position: 'sticky', bottom: 0 }}>
                          {f}
                        </td>
                      ))}
                    </tr>
                  </tfoot>
                )}
              </table>
              {!res.groups.length && res.rows.length > 2000 && <p className="hint" style={{ padding: 12 }}>Screen pe pehli 2000 rows. Print / Excel me sab {res.rows.length} rows aayengi.</p>}
            </div>
          )}
        </Card>
      </div>
      <PrintDesignerModal open={printOpen} onClose={() => setPrintOpen(false)} doc={doc} storeKey={'report-' + spec.dataset} />
    </>
  );
}

function GroupRows({
  g,
  cols,
  cell,
  foot,
}: {
  g: { key: string; rows: Record<string, unknown>[] };
  cols: { key: string; type: string }[];
  cell: (r: Record<string, unknown>, k: string) => string;
  foot: string[] | null;
}) {
  return (
    <>
      {g.key && (
        <tr>
          <td colSpan={cols.length} style={{ fontWeight: 800, background: 'var(--surface-2)' }}>
            {g.key} <span className="u-faint u-sm">({g.rows.length})</span>
          </td>
        </tr>
      )}
      {g.rows.map((r, i) => (
        <tr key={i}>
          {cols.map((c) => (
            <td key={c.key} className={c.type === 'number' || c.type === 'money' ? 'num nowrap' : c.type === 'date' ? 'nowrap' : undefined}>
              {cell(r, c.key)}
            </td>
          ))}
        </tr>
      ))}
      {foot && Object.keys(foot).length > 0 && foot.some((f, i) => i > 0 && f) && (
        <tr>
          {foot.map((f, i) => (
            <td key={i} className={cols[i].type === 'number' || cols[i].type === 'money' ? 'num' : undefined} style={{ fontWeight: 700, color: 'var(--muted)' }}>
              {f}
            </td>
          ))}
        </tr>
      )}
    </>
  );
}

export function filterText(s: Spec): string {
  const a: string[] = [];
  if (s.from || s.to) a.push((s.from || '…') + ' → ' + (s.to || '…'));
  if (s.asOf) a.push('as of ' + s.asOf);
  for (const [k, l] of [
    ['person', 'Person'],
    ['dept', 'Dept'],
    ['location', 'Place'],
    ['item', 'Item'],
    ['category', 'Category'],
    ['status', 'Status'],
    ['drive', 'Drive'],
    ['event', 'Event'],
    ['q', 'Search'],
  ] as const)
    if (s[k]) a.push(l + ': ' + s[k]);
  return a.join(' · ');
}
