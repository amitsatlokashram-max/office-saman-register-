'use client';

// Cash note calculator: 500 × 60 = 30,000 … sab ka jod, notes / coins alag, print statement.
// (Cash received / settlement me save karna agle phase me — abhi ye calculator + print hai.)

import { animate, useReducedMotion } from 'motion/react';
import { useEffect, useRef, useState } from 'react';
import { Printer, RotateCcw } from 'lucide-react';
import { today } from '@/lib/calc';
import { PrintDesignerModal, type PrintTable } from '../print/PrintDesigner';
import { Card, Field, PageHeader } from '../ui';

const DENOMS = [
  { v: 2000, coin: false },
  { v: 500, coin: false },
  { v: 200, coin: false },
  { v: 100, coin: false },
  { v: 50, coin: false },
  { v: 20, coin: false },
  { v: 10, coin: false },
  { v: 20, coin: true },
  { v: 10, coin: true },
  { v: 5, coin: true },
  { v: 2, coin: true },
  { v: 1, coin: true },
];
const key = (d: { v: number; coin: boolean }) => (d.coin ? 'c' : 'n') + d.v;
const rs = (n: number) => '₹' + Math.round(n).toLocaleString('en-IN');

function Big({ value }: { value: number }) {
  const ref = useRef<HTMLSpanElement>(null);
  const last = useRef(0);
  const reduce = useReducedMotion();
  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    if (reduce) {
      el.textContent = rs(value);
      return;
    }
    const c = animate(last.current, value, { duration: 0.35, onUpdate: (v) => (el.textContent = rs(v)) });
    last.current = value;
    return () => c.stop();
  }, [value, reduce]);
  return <span ref={ref}>{rs(value)}</span>;
}

export function CashCalculator() {
  const [counts, setCounts] = useState<Record<string, string>>({});
  const [enabled, setEnabled] = useState<string[]>(DENOMS.filter((d) => !(d.v === 2000 && !d.coin)).map(key));
  const [meta, setMeta] = useState({ date: today(), from: '', to: '', purpose: '' });
  const [print, setPrint] = useState<PrintTable | null>(null);

  useEffect(() => {
    try {
      const e = JSON.parse(localStorage.getItem('cash-denoms') || 'null');
      if (Array.isArray(e)) setEnabled(e);
    } catch {
      /* ignore */
    }
  }, []);
  const toggle = (k: string) =>
    setEnabled((e) => {
      const n = e.includes(k) ? e.filter((x) => x !== k) : [...e, k];
      try {
        localStorage.setItem('cash-denoms', JSON.stringify(n));
      } catch {
        /* ignore */
      }
      return n;
    });

  const list = DENOMS.filter((d) => enabled.includes(key(d)));
  const cnt = (d: (typeof DENOMS)[number]) => Math.max(0, Math.round(Number(counts[key(d)]) || 0));
  const notes = list.filter((d) => !d.coin).reduce((a, d) => a + cnt(d) * d.v, 0);
  const coins = list.filter((d) => d.coin).reduce((a, d) => a + cnt(d) * d.v, 0);
  const pieces = list.reduce((a, d) => a + cnt(d), 0);

  return (
    <>
      <PageHeader
        title="Cash Note Calculator"
        sub="Har note ki ginti likho — jod apne aap. Print karke sign le sakte ho."
        actions={
          <>
            <button type="button" className="btn" onClick={() => setCounts({})}>
              <RotateCcw aria-hidden className="ic" /> Reset
            </button>
            <button
              type="button"
              className="btn primary"
              disabled={!pieces}
              onClick={() =>
                setPrint({
                  title: 'Cash denomination statement',
                  subtitle: [meta.date, meta.purpose].filter(Boolean).join(' · '),
                  blocks: [
                    { label: 'Diya (from)', value: meta.from || '—' },
                    { label: 'Liya (to)', value: meta.to || '—' },
                    { label: 'Total', value: rs(notes + coins) },
                  ],
                  head: ['Denomination', 'Count', 'Amount'],
                  align: ['left', 'right', 'right'],
                  sections: [
                    { heading: 'Notes', rows: list.filter((d) => !d.coin && cnt(d)).map((d) => ['₹' + d.v + ' note', String(cnt(d)), rs(cnt(d) * d.v)]), foot: ['Notes total', '', rs(notes)] },
                    ...(coins ? [{ heading: 'Coins', rows: list.filter((d) => d.coin && cnt(d)).map((d) => ['₹' + d.v + ' coin', String(cnt(d)), rs(cnt(d) * d.v)]), foot: ['Coins total', '', rs(coins)] }] : []),
                  ],
                  grandFoot: ['Grand total', String(pieces), rs(notes + coins)],
                })
              }
            >
              <Printer aria-hidden className="ic" /> Print
            </button>
          </>
        }
      />
      <div className="u-grid span-2-1">
        <Card>
          <div className="cash-grid">
            {list.map((d, i) => (
              <label key={key(d)} className={'cash-row' + (cnt(d) ? ' on' : '')}>
                <span className="cash-d">
                  ₹{d.v} <small>{d.coin ? 'coin' : 'note'}</small>
                </span>
                <span className="cash-x">×</span>
                <input
                  type="number"
                  inputMode="numeric"
                  min={0}
                  value={counts[key(d)] || ''}
                  onChange={(e) => setCounts((c) => ({ ...c, [key(d)]: e.target.value }))}
                  onKeyDown={(e) => {
                    if (e.key === 'Enter') {
                      e.preventDefault();
                      const inputs = (e.currentTarget.closest('.cash-grid') as HTMLElement).querySelectorAll('input');
                      (inputs[i + 1] as HTMLInputElement | undefined)?.focus();
                    }
                  }}
                  aria-label={'₹' + d.v + (d.coin ? ' coin' : ' note') + ' count'}
                />
                <span className="cash-a">{cnt(d) ? rs(cnt(d) * d.v) : '—'}</span>
              </label>
            ))}
          </div>
        </Card>
        <div className="u-stack">
          <Card>
            <div className="cash-total">
              <span>Grand total</span>
              <b>
                <Big value={notes + coins} />
              </b>
              <small>
                Notes {rs(notes)} · Coins {rs(coins)} · {pieces} pieces
              </small>
            </div>
          </Card>
          <Card title="Statement details (print ke liye)">
            <div className="fgrid">
              <Field label="Date">
                <input type="date" value={meta.date} onChange={(e) => setMeta({ ...meta, date: e.target.value })} />
              </Field>
              <Field label="Purpose">
                <input value={meta.purpose} onChange={(e) => setMeta({ ...meta, purpose: e.target.value })} />
              </Field>
              <Field label="Diya (kisne)">
                <input value={meta.from} onChange={(e) => setMeta({ ...meta, from: e.target.value })} list="dl-allpeople" />
              </Field>
              <Field label="Liya (kisne)">
                <input value={meta.to} onChange={(e) => setMeta({ ...meta, to: e.target.value })} list="dl-allpeople" />
              </Field>
            </div>
          </Card>
          <Card title="Kaunse note / coin dikhaye">
            <div className="u-row">
              {DENOMS.map((d) => (
                <label key={key(d)} className="u-check u-sm">
                  <input type="checkbox" checked={enabled.includes(key(d))} onChange={() => toggle(key(d))} /> ₹{d.v} {d.coin ? 'coin' : ''}
                </label>
              ))}
            </div>
          </Card>
        </div>
      </div>
      {print && <PrintDesignerModal open onClose={() => setPrint(null)} doc={print} storeKey="cash" />}
    </>
  );
}
