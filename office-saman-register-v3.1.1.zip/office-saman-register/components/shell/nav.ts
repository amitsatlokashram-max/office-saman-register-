import {
  Building2,
  Calculator,
  CalendarDays,
  FileBarChart,
  Gauge,
  UserRound,
  Archive,
  BarChart3,
  ClipboardList,
  Database,
  HardDrive,
  KeyRound,
  LayoutDashboard,
  Layers,
  MapPin,
  Package,
  QrCode,
  ScanLine,
  ScrollText,
  Settings,
  ShieldCheck,
  Users,
  type LucideIcon,
} from 'lucide-react';
import type { Action, Module } from '@/lib/perm';

export type NavItem = {
  href: string;
  label: string;
  icon: LucideIcon;
  need?: [Module, Action];
  count?: 'items' | 'stock' | 'issues' | 'drives' | 'demands' | 'catalog' | 'risk';
};
export type NavGroup = { id: string; label: string; items: NavItem[] };

export const NAV: NavGroup[] = [
  {
    id: 'overview',
    label: 'Overview',
    items: [
      { href: '/', label: 'Dashboard', icon: LayoutDashboard },
      { href: '/reports', label: 'Report builder', icon: FileBarChart, need: ['reports', 'view'] },
    ],
  },
  {
    id: 'inventory',
    label: 'Inventory',
    items: [
      { href: '/saman', label: 'Items', icon: Package, need: ['inventory', 'view'], count: 'items' },
      { href: '/stock', label: 'Stock', icon: Layers, need: ['inventory', 'view'], count: 'stock' },
      { href: '/kisko-diya', label: 'Issued items', icon: Users, need: ['inventory', 'view'], count: 'issues' },
      { href: '/demand', label: 'Demand list', icon: ClipboardList, need: ['demands', 'view'], count: 'demands' },
    ],
  },
  {
    id: 'people',
    label: 'Persons & Departments',
    items: [
      { href: '/persons', label: 'Persons', icon: UserRound, need: ['persons', 'view'] },
      { href: '/departments', label: 'Departments', icon: Building2, need: ['persons', 'view'] },
    ],
  },
  {
    id: 'storage',
    label: 'Digital Data Manager',
    items: [
      { href: '/data', label: 'Data dashboard', icon: Gauge, need: ['drives', 'view'] },
      { href: '/drives', label: 'All drives', icon: HardDrive, need: ['drives', 'view'], count: 'drives' },
      { href: '/catalog', label: 'Data catalogue', icon: Database, need: ['catalog', 'view'], count: 'catalog' },
      { href: '/events', label: 'Events', icon: CalendarDays, need: ['events', 'view'] },
      { href: '/backups', label: 'Backups', icon: ShieldCheck, need: ['backups', 'view'], count: 'risk' },
      { href: '/stickers', label: 'QR stickers', icon: QrCode, need: ['stickers', 'view'] },
      { href: '/scan', label: 'QR scan', icon: ScanLine, need: ['drives', 'view'] },
    ],
  },
  {
    id: 'accounts',
    label: 'Accounts',
    items: [
      { href: '/hisaab', label: 'Accounts reports', icon: BarChart3, need: ['inventory', 'view'] },
      { href: '/cash', label: 'Cash calculator', icon: Calculator },
    ],
  },
  {
    id: 'admin',
    label: 'Admin',
    items: [
      { href: '/admin/roles', label: 'Roles & access', icon: KeyRound, need: ['roles', 'view'] },
      { href: '/admin/audit', label: 'Audit log', icon: ScrollText, need: ['audit', 'view'] },
      { href: '/admin/recycle', label: 'Recycle bin', icon: Archive, need: ['drives', 'delete'] },
      { href: '/locations', label: 'Racks (optional)', icon: MapPin, need: ['locations', 'view'] },
      { href: '/settings', label: 'Settings', icon: Settings },
    ],
  },
];

export const ALL_NAV = NAV.flatMap((g) => g.items.map((i) => ({ ...i, group: g.label })));

export function crumbFor(path: string): { group: string; label: string; href: string } | null {
  const hit = ALL_NAV.filter((n) => (n.href === '/' ? path === '/' : path === n.href || path.startsWith(n.href + '/'))).sort((a, b) => b.href.length - a.href.length)[0];
  return hit ? { group: hit.group, label: hit.label, href: hit.href } : null;
}
