'use client';

// Global search (Ctrl/⌘ + K): saman, drives, data catalogue, files (index), log, locations aur pages — sab ek jagah.

import { AnimatePresence, motion, useReducedMotion } from 'motion/react';
import { useRouter } from 'next/navigation';
import { useEffect, useMemo, useRef, useState } from 'react';
import { CalendarDays, Database, FileSearch, FolderOpen, HardDrive, MapPin, Package, Search, User } from 'lucide-react';
import { allPeople, canon, summarize } from '@/lib/people';
import { useSources } from '../reports/ReportBuilder';
import { searchIndex } from '@/lib/assets/db';
import { copyState, gb, locLabel, matches, words, bytes, whereIs } from '@/lib/assets/model';
import type { FileChunk } from '@/lib/assets/types';
import { inr } from '@/lib/calc';
import { useLang } from '@/lib/i18n';
import { useAssets } from '../assets/store';
import { useReg } from '../context';
import { ALL_NAV } from './nav';

type Hit = { key: string; sec: string; icon: typeof Search; title: string; sub: string; go: () => void };

export function CommandPalette({ open, onClose }: { open: boolean; onClose: () => void }) {
  const router = useRouter();
  const reduce = useReducedMotion();
  const { t } = useLang();
  const { items, openEntry } = useReg();
  const A = useAssets();
  const { src, am } = useSources();
  const [q, setQ] = useState('');
  const [files, setFiles] = useState<FileChunk[]>([]);
  const [fileBusy, setFileBusy] = useState(false);
  const [on, setOn] = useState(0);
  const inRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (open) {
      setQ('');
      setFiles([]);
      setOn(0);
      setTimeout(() => inRef.current?.focus(), 30);
    }
  }, [open]);

  // File index: sabse lamba shabd Firestore index se (array-contains), baaki shabd yahan filter
  useEffect(() => {
    if (!open || !A.can('catalog', 'view')) return;
    const ws = words(q).sort((a, b) => b.length - a.length);
    if (!ws.length || ws[0].length < 3) {
      setFiles([]);
      return;
    }
    let live = true;
    setFileBusy(true);
    const h = setTimeout(() => {
      searchIndex(ws[0], 30)
        .then((r) => live && setFiles(r))
        .catch(() => live && setFiles([]))
        .finally(() => live && setFileBusy(false));
    }, 260);
    return () => {
      live = false;
      clearTimeout(h);
    };
  }, [q, open, A]);

  const hits = useMemo<Hit[]>(() => {
    const go = (href: string) => () => {
      onClose();
      router.push(href);
    };
    const out: Hit[] = [];
    const s = q.trim();
    for (const n of ALL_NAV) {
      if (n.need && !A.can(n.need[0], n.need[1])) continue;
      if (!s || matches(t(n.label) + ' ' + n.label + ' ' + n.group, s))
        out.push({ key: 'p' + n.href, sec: 'Pages', icon: n.icon, title: t(n.label), sub: n.group, go: go(n.href) });
    }
    if (!s) return out.slice(0, 12);

    for (const d of A.drives.filter((d) => matches([d.displayName, d.assetId, d.brand, d.model, d.serial, d.holder?.name, d.dept, d.type].join(' '), s)).slice(0, 8)) {
      out.push({
        key: 'd' + d.id,
        sec: 'Hard Disks',
        icon: HardDrive,
        title: d.displayName + ' · ' + d.assetId,
        sub: [d.brand, gb(d.capacityGB), whereIs(d, A.locMap)].filter(Boolean).join(' · '),
        go: go('/drives/' + d.id),
      });
    }
    for (const c of A.catalog.filter((c) => matches([c.project, c.title, c.episode, c.eventName, c.year, c.folderPath, c.tags.join(' '), c.category, c.owner].join(' '), s)).slice(0, 10)) {
      const d = A.driveMap.get(c.driveId);
      const cs = copyState(c, A.backups);
      out.push({
        key: 'c' + c.id,
        sec: 'Data catalogue',
        icon: Database,
        title: [c.project, c.title, c.episode && 'Ep ' + c.episode].filter(Boolean).join(' · '),
        sub: [d ? d.displayName : 'Unknown drive', d ? whereIs(d, A.locMap) : '', c.folderPath, c.sizeGB ? gb(c.sizeGB) : '', cs.copies + ' backup copy'].filter(Boolean).join(' · '),
        go: go('/catalog?open=' + c.id),
      });
    }
    for (const it of items.filter((it) => matches([it.item, it.category, it.vendor, it.billNo, it.serials, it.note, String(it.total), ...it.issues.flatMap((i) => [i.person, i.dept, i.location, i.purpose])].join(' '), s)).slice(0, 8)) {
      out.push({
        key: 'i' + it.id,
        sec: 'Items',
        icon: Package,
        title: it.item,
        sub: [it.vendor, inr(it.total), it.orderDate].filter(Boolean).join(' · '),
        go: () => {
          onClose();
          openEntry(it.id);
        },
      });
    }
    if (A.can('persons', 'view') || A.can('inventory', 'view')) {
      const sum = summarize(src.ledger);
      const people = allPeople({ persons: A.persons, rows: src.ledger, drives: A.drives, transfers: A.transfers, catalog: A.catalog, events: A.events, am });
      for (const p of people.filter((p) => matches(p.name + ' ' + (p.person?.aliases.join(' ') || '') + ' ' + p.depts.join(' '), s)).slice(0, 6)) {
        const x = sum.get(p.key);
        const dr = A.drives.filter((d) => d.holder && canon(d.holder.name, am).key === p.key).length;
        out.push({ key: 'u' + p.key, sec: 'People', icon: User, title: p.name, sub: [p.depts.join(', '), x ? x.current + ' items with them' : '', dr ? dr + ' drive' : ''].filter(Boolean).join(' · '), go: go('/persons/' + encodeURIComponent(p.key)) });
      }
    }
    for (const e of A.events.filter((e) => matches([e.eventNo, e.title, e.type, e.date, e.location, e.description, e.project, e.episode, ...e.participants, ...e.mainPersons, ...e.recordingTeam, e.submittedBy, e.receivedBy, e.responsible, ...e.tags].join(' '), s)).slice(0, 6)) {
      out.push({ key: 'e' + e.id, sec: 'Events', icon: CalendarDays, title: e.type + ': ' + e.title, sub: [e.date, e.location, A.catalog.filter((c) => c.eventId === e.id).length + ' data'].filter(Boolean).join(' · '), go: go('/events/' + e.id) });
    }
    for (const l of A.locs.filter((l) => matches(l.name, s)).slice(0, 5)) {
      out.push({ key: 'l' + l.id, sec: 'Locations', icon: MapPin, title: l.name, sub: locLabel(A.locMap, l.id), go: go('/locations?open=' + l.id) });
    }
    const ws = words(s);
    for (const ch of files) {
      const d = A.driveMap.get(ch.driveId);
      const folderHit = matches(ch.folder, s);
      const fs = ch.files.filter((f) => matches(ch.folder + '/' + f.n, s)).slice(0, folderHit ? 1 : 4);
      if (folderHit && !fs.length)
        out.push({
          key: 'f' + ch.id,
          sec: 'Files & folders',
          icon: FolderOpen,
          title: ch.folder || '/',
          sub: [d?.displayName, d?.holder?.name ? 'with ' + d.holder.name : 'in store', ch.count + ' files', bytes(ch.bytes)].filter(Boolean).join(' · '),
          go: go('/drives/' + ch.driveId + '?tab=files&path=' + encodeURIComponent(ch.folder)),
        });
      for (const f of fs)
        out.push({
          key: 'f' + ch.id + f.n,
          sec: 'Files & folders',
          icon: FileSearch,
          title: f.n,
          sub: [d?.displayName, d ? whereIs(d, A.locMap) : '', ch.folder, bytes(f.s)].filter(Boolean).join(' · '),
          go: go('/drives/' + ch.driveId + '?tab=files&path=' + encodeURIComponent(ch.folder)),
        });
      if (ws.length === 0) break;
    }
    return out.slice(0, 60);
  }, [q, items, A, files, router, onClose, openEntry, t, src, am]);

  useEffect(() => setOn(0), [q]);

  const secs: string[] = [];
  for (const h of hits) if (!secs.includes(h.sec)) secs.push(h.sec);

  return (
    <AnimatePresence>
      {open && (
        <motion.div
          className="u-cmd-back"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.15 }}
          onMouseDown={(e) => e.target === e.currentTarget && onClose()}
        >
          <motion.div
            className="u-cmd"
            role="dialog"
            aria-modal="true"
            aria-label="Search"
            initial={reduce ? false : { opacity: 0, y: -12, scale: 0.98 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={reduce ? undefined : { opacity: 0, y: -8, scale: 0.98 }}
            transition={{ type: 'spring', stiffness: 420, damping: 32 }}
            onKeyDown={(e) => {
              if (e.key === 'Escape') onClose();
              else if (e.key === 'ArrowDown') {
                e.preventDefault();
                setOn((n) => Math.min(n + 1, hits.length - 1));
              } else if (e.key === 'ArrowUp') {
                e.preventDefault();
                setOn((n) => Math.max(n - 1, 0));
              } else if (e.key === 'Enter' && hits[on]) {
                e.preventDefault();
                hits[on].go();
              }
            }}
          >
            <div className="u-cmd-in">
              <Search aria-hidden />
              <input ref={inRef} autoFocus value={q} onChange={(e) => setQ(e.target.value)} placeholder={t('Search everything…') + ' (drive, project, episode, file, item, person)'} aria-label="Search" />
              <kbd>Esc</kbd>
            </div>
            <div className="u-cmd-list">
              {hits.length === 0 && !fileBusy && <div className="u-empty"><p>&ldquo;{q}&rdquo; ke liye kuch nahi mila.</p></div>}
              {secs.map((sec) => (
                <div key={sec}>
                  <div className="u-cmd-sec">{sec}</div>
                  {hits
                    .filter((h) => h.sec === sec)
                    .map((h) => {
                      const idx = hits.indexOf(h);
                      return (
                        <button type="button" key={h.key} className={'u-cmd-item' + (idx === on ? ' on' : '')} onMouseEnter={() => setOn(idx)} onClick={h.go}>
                          <span className="ico">
                            <h.icon aria-hidden />
                          </span>
                          <span className="t">
                            <b>{h.title}</b>
                            <small>{h.sub}</small>
                          </span>
                        </button>
                      );
                    })}
                </div>
              ))}
              {fileBusy && <div className="u-cmd-sec">Files index me dhundh rahe hai…</div>}
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
