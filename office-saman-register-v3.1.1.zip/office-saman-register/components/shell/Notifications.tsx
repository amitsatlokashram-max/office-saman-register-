'use client';

import { AnimatePresence, motion, useReducedMotion } from 'motion/react';
import Link from 'next/link';
import { useEffect, useRef } from 'react';
import { AlertTriangle, Bell, CalendarClock, CheckCircle2, ClipboardList, HardDrive, ShieldAlert, Wallet, X, type LucideIcon } from 'lucide-react';
import type { AlertKind, AppAlert } from '@/lib/assets/alerts';
import { useLang } from '@/lib/i18n';

const ICON: Record<AlertKind, LucideIcon> = {
  stock: AlertTriangle,
  warranty: CalendarClock,
  overdue: HardDrive,
  full: HardDrive,
  backup: ShieldAlert,
  money: Wallet,
  demand: ClipboardList,
  damaged: AlertTriangle,
};
const TONE = { red: 'tone-red', amber: 'tone-amber', blue: 'tone-blue' } as const;

export function NotificationPanel({ open, onClose, alerts }: { open: boolean; onClose: () => void; alerts: AppAlert[] }) {
  const reduce = useReducedMotion();
  const { t } = useLang();
  const ref = useRef<HTMLDivElement>(null);
  useEffect(() => {
    if (!open) return;
    const k = (e: KeyboardEvent) => e.key === 'Escape' && onClose();
    const c = (e: MouseEvent) => {
      if (ref.current && !ref.current.contains(e.target as Node) && !(e.target as HTMLElement).closest('[data-bell]')) onClose();
    };
    window.addEventListener('keydown', k);
    window.addEventListener('mousedown', c);
    return () => {
      window.removeEventListener('keydown', k);
      window.removeEventListener('mousedown', c);
    };
  }, [open, onClose]);
  return (
    <AnimatePresence>
      {open && (
        <motion.div
          ref={ref}
          className="u-panel"
          role="dialog"
          aria-label={t('Notifications')}
          initial={reduce ? false : { opacity: 0, y: -8, scale: 0.97 }}
          animate={{ opacity: 1, y: 0, scale: 1 }}
          exit={reduce ? undefined : { opacity: 0, y: -6, scale: 0.97 }}
          transition={{ type: 'spring', stiffness: 460, damping: 32 }}
          style={{ transformOrigin: 'top right' }}
        >
          <div className="u-panel-h">
            <b>
              <Bell aria-hidden className="ic" style={{ verticalAlign: -3, marginRight: 8 }} />
              {t('Notifications')} {alerts.length > 0 && <span className="u-faint">({alerts.length})</span>}
            </b>
            <button type="button" className="u-iconbtn" onClick={onClose} aria-label="Close">
              <X aria-hidden />
            </button>
          </div>
          <div className="u-panel-b">
            {alerts.length === 0 ? (
              <div className="u-empty">
                <div className="art">
                  <CheckCircle2 aria-hidden />
                </div>
                <h3>{t('All caught up')}</h3>
                <p>Koi alert nahi: stock, warranty, overdue drive aur backup sab theek.</p>
              </div>
            ) : (
              alerts.map((a) => {
                const I = ICON[a.kind];
                return (
                  <Link key={a.id} href={a.href} className={'u-note ' + TONE[a.level]} onClick={onClose}>
                    <span className="ico">
                      <I aria-hidden />
                    </span>
                    <span>
                      <b>{a.title}</b>
                      <small>{a.detail}</small>
                    </span>
                  </Link>
                );
              })
            )}
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
