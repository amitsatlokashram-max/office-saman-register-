'use client';

// Drive ke andar ki files: scan CSV import (sirf metadata) aur folder explorer.

import { AnimatePresence, motion, useReducedMotion } from 'motion/react';
import { useEffect, useMemo, useState } from 'react';
import { ChevronRight, File, Folder, FolderOpen, Upload } from 'lucide-react';
import { importScan, readDriveIndex, readScans } from '@/lib/assets/db';
import { parseScanCsv } from '@/lib/assets/csv';
import { bytes, gb } from '@/lib/assets/model';
import type { Drive, FileChunk, IndexedFile, Scan } from '@/lib/assets/types';
import { num } from '@/lib/calc';
import { useReg } from '../context';
import { Alert, Empty, Field, Modal, fmtTime, useBusy } from '../ui';
import { Info } from 'lucide-react';

const PS = (letter: string, name: string) =>
  `Get-ChildItem -Path ${letter}:\\ -Recurse -File -ErrorAction SilentlyContinue | Select-Object @{n='path';e={$_.FullName}}, @{n='size';e={$_.Length}}, @{n='modified';e={$_.LastWriteTime.ToString('s')}} | Export-Csv -Path "$HOME\\Desktop\\${name}.csv" -NoTypeInformation -Encoding UTF8`;
const MAC = (vol: string, name: string) =>
  `cd "/Volumes/${vol}" && { echo "path,size,modified"; find . -type f ! -name '._*' ! -name '.DS_Store' -print0 | xargs -0 stat -f '"%N",%z,%Sm' -t '%Y-%m-%dT%H:%M:%S'; } > ~/Desktop/${name}.csv`;

export function ScanImport({ drive, open, onClose, onDone }: { drive: Drive; open: boolean; onClose: () => void; onDone: () => void }) {
  const { me, toast } = useReg();
  const [text, setText] = useState('');
  const [fileName, setFileName] = useState('');
  const [cap, setCap] = useState('');
  const [free, setFree] = useState('');
  const [note, setNote] = useState('');
  const [msg, setMsg] = useState('');
  const [err, setErr] = useState('');
  const [busy, run] = useBusy();
  const safe = drive.displayName.replace(/[^\w-]+/g, '_');

  useEffect(() => {
    if (open) {
      setText('');
      setFileName('');
      setCap(drive.capacityGB ? String(drive.capacityGB) : '');
      setFree('');
      setNote('');
      setMsg('');
      setErr('');
    }
  }, [open, drive.capacityGB]);

  const parsed = useMemo(() => (text ? parseScanCsv(text) : null), [text]);

  const submit = () =>
    run(async () => {
      setErr('');
      if (!parsed || !parsed.files.length) return setErr('CSV me koi file nahi mili.');
      if (parsed.files.length > 200000) return setErr('Ek baar me 2 lakh files tak. Folder ke hisaab se alag-alag CSV banao.');
      try {
        const s = await importScan(
          drive,
          parsed.files,
          { capacityGB: cap.trim() ? num(cap) : null, freeGB: free.trim() ? num(free) : null, note: (fileName ? fileName + ' ' : '') + note },
          me,
          setMsg,
        );
        toast('✓ ' + s.files.toLocaleString('en-IN') + ' files indexed (+' + s.added + ' / −' + s.removed + ')');
        onDone();
        onClose();
      } catch {
        setErr('Import pura nahi hua. Internet / ijaazat check karke dobara karo — purana index pehle hat sakta hai, dobara import se theek ho jayega.');
      }
    });

  return (
    <Modal
      open={open}
      onClose={onClose}
      size="lg"
      title={'Scan import — ' + drive.displayName}
      sub="Drive ki file list (sirf naam, size, tareekh) website pe. Original video / file upload nahi hoti."
      onSubmit={submit}
      foot={
        <>
          <button type="button" className="btn" onClick={onClose}>
            Cancel
          </button>
          <button type="submit" className="btn primary" disabled={busy || !parsed?.files.length}>
            <Upload aria-hidden className="ic" /> {busy ? msg || 'Importing…' : 'Import ' + (parsed?.files.length || 0).toLocaleString('en-IN') + ' files'}
          </button>
        </>
      }
    >
      {err && <div className="ferr">{err}</div>}
      <Alert icon={Info} tone="blue">
        <b>Step 1:</b> Drive computer me lagao. Neeche wali command chalao — Desktop pe <code>{safe}.csv</code> ban jayegi (ye command sirf padhti hai, kuch badalti / delete nahi karti).
        <br />
        <b>Windows (PowerShell)</b> — <code>E</code> ki jagah drive ka letter:
        <pre className="u-code">{PS('E', safe)}</pre>
        <b>Mac (Terminal)</b> — <code>{safe}</code> ki jagah drive ka naam jo Finder me dikhta hai:
        <pre className="u-code">{MAC(drive.displayName, safe)}</pre>
        <b>Step 2:</b> Wo CSV yahan chuno. Pichhla index hat ke naya ban jayega, aur kya jud/hata wo scan history me dikhega.
      </Alert>
      <div className="fgrid g3">
        <Field label="Scan CSV file" span>
          <input
            type="file"
            accept=".csv,text/csv,text/plain"
            onChange={async (e) => {
              const f = e.target.files?.[0];
              if (!f) return;
              if (f.size > 80 * 1024 * 1024) return setErr('CSV 80 MB se badi hai. Folder-wise alag CSV banao.');
              setFileName(f.name);
              setText(await f.text());
            }}
          />
        </Field>
        <Field label="Capacity (GB)" hint="Properties / Get Info me dikhta hai">
          <input type="number" min={0} step="any" value={cap} onChange={(e) => setCap(e.target.value)} />
        </Field>
        <Field label="Free space (GB)" hint="Bharo to used space apne aap update hoga">
          <input type="number" min={0} step="any" value={free} onChange={(e) => setFree(e.target.value)} />
        </Field>
        <Field label="Note">
          <input value={note} onChange={(e) => setNote(e.target.value)} maxLength={200} />
        </Field>
      </div>
      {parsed && (
        <p className="u-sm">
          Mili: <b>{parsed.files.length.toLocaleString('en-IN')}</b> files · {bytes(parsed.files.reduce((s, f) => s + f.size, 0))}
          {parsed.skipped > 0 && <span className="u-muted"> · {parsed.skipped} line chhodi (system files / khaali)</span>}
        </p>
      )}
    </Modal>
  );
}

type Node = { name: string; path: string; kids: Map<string, Node>; files: IndexedFile[]; bytes: number; count: number };

function buildTree(chunks: FileChunk[]): Node {
  const root: Node = { name: '/', path: '', kids: new Map(), files: [], bytes: 0, count: 0 };
  for (const c of chunks) {
    let cur = root;
    const parts = c.folder ? c.folder.split('/') : [];
    root.bytes += c.bytes;
    root.count += c.count;
    let p = '';
    for (const part of parts) {
      p = p ? p + '/' + part : part;
      let n = cur.kids.get(part);
      if (!n) {
        n = { name: part, path: p, kids: new Map(), files: [], bytes: 0, count: 0 };
        cur.kids.set(part, n);
      }
      n.bytes += c.bytes;
      n.count += c.count;
      cur = n;
    }
    cur.files.push(...c.files);
  }
  return root;
}

export function FileExplorer({ drive, canImport, openPath, refreshKey }: { drive: Drive; canImport: boolean; openPath?: string; refreshKey?: number }) {
  const [chunks, setChunks] = useState<FileChunk[] | null>(null);
  const [scans, setScans] = useState<Scan[]>([]);
  const [imp, setImp] = useState(false);
  const [tick, setTick] = useState(0);
  const [err, setErr] = useState('');
  useEffect(() => {
    let live = true;
    setChunks(null);
    Promise.all([readDriveIndex(drive.id), readScans(drive.id)])
      .then(([c, s]) => {
        if (!live) return;
        setChunks(c);
        setScans(s);
      })
      .catch(() => {
        if (live) {
          setChunks([]);
          setErr('File index padh nahi paye (ijaazat ya internet).');
        }
      });
    return () => {
      live = false;
    };
  }, [drive.id, tick, refreshKey]);
  const tree = useMemo(() => (chunks ? buildTree(chunks) : null), [chunks]);

  return (
    <div className="u-stack">
      <div className="u-between">
        <div className="u-sm u-muted">
          {scans[0] ? (
            <>
              Last scan {fmtTime(scans[0].at)} by {scans[0].byName} · {scans[0].files.toLocaleString('en-IN')} files · {bytes(scans[0].bytes)} · +{scans[0].added} / −{scans[0].removed}
            </>
          ) : (
            'Abhi tak scan import nahi hua.'
          )}
        </div>
        {canImport && (
          <button type="button" className="btn sm primary" onClick={() => setImp(true)}>
            <Upload aria-hidden className="ic" /> Import scan (CSV)
          </button>
        )}
      </div>
      {err && <div className="ferr">{err}</div>}
      {!tree ? (
        <p className="u-sm u-muted">Loading files…</p>
      ) : tree.count === 0 ? (
        <Empty icon={FolderOpen} title="File index khaali hai">
          Drive ki file list import karo — phir kisi bhi file / folder ka naam Global search (Ctrl K) me dhoondhne par ye drive dikhegi.
        </Empty>
      ) : (
        <ul className="tree">
          <TreeNode node={tree} depth={0} openPath={openPath || ''} />
        </ul>
      )}
      {scans.length > 1 && (
        <details>
          <summary className="u-sm u-muted" style={{ cursor: 'pointer' }}>
            Scan history ({scans.length})
          </summary>
          <ul className="u-sm" style={{ margin: '8px 0 0', paddingLeft: 18 }}>
            {scans.map((s) => (
              <li key={s.id}>
                {fmtTime(s.at)} · {s.byName} · {s.files.toLocaleString('en-IN')} files · {bytes(s.bytes)} · +{s.added}/−{s.removed}
                {s.freeGB ? ' · free ' + gb(s.freeGB) : ''} {s.note && '· ' + s.note}
              </li>
            ))}
          </ul>
        </details>
      )}
      <ScanImport drive={drive} open={imp} onClose={() => setImp(false)} onDone={() => setTick((t) => t + 1)} />
    </div>
  );
}

function TreeNode({ node, depth, openPath }: { node: Node; depth: number; openPath: string }) {
  const reduce = useReducedMotion();
  const auto = depth === 0 || (!!openPath && (openPath === node.path || openPath.startsWith(node.path + '/')));
  const [open, setOpen] = useState(auto);
  const [more, setMore] = useState(false);
  const kids = Array.from(node.kids.values()).sort((a, b) => a.name.localeCompare(b.name, 'en', { numeric: true }));
  const files = node.files.slice().sort((a, b) => a.n.localeCompare(b.n, 'en', { numeric: true }));
  const shownFiles = more ? files : files.slice(0, 100);
  return (
    <li>
      <div className={'tree-row' + (openPath && openPath === node.path ? ' on' : '')} onClick={() => setOpen((o) => !o)} role="button" tabIndex={0} onKeyDown={(e) => e.key === 'Enter' && setOpen((o) => !o)} aria-expanded={open}>
        <ChevronRight aria-hidden className={'tw' + (open ? ' open' : '')} />
        {open ? <FolderOpen aria-hidden /> : <Folder aria-hidden />}
        <span className="nm">{depth === 0 ? 'Drive root' : node.name}</span>
        <span className="sz">
          {node.count.toLocaleString('en-IN')} files · {bytes(node.bytes)}
        </span>
      </div>
      <AnimatePresence initial={false}>
        {open && (
          <motion.ul initial={reduce ? false : { height: 0, opacity: 0 }} animate={{ height: 'auto', opacity: 1 }} exit={reduce ? undefined : { height: 0, opacity: 0 }} transition={{ duration: 0.2 }} style={{ overflow: 'hidden' }}>
            {kids.map((k) => (
              <TreeNode key={k.path} node={k} depth={depth + 1} openPath={openPath} />
            ))}
            {shownFiles.map((f) => (
              <li key={f.n}>
                <div className="tree-row" style={{ cursor: 'default' }}>
                  <span style={{ width: 16 }} />
                  <File aria-hidden />
                  <span className="nm" title={f.n}>
                    {f.n}
                  </span>
                  <span className="sz">
                    {bytes(f.s)}
                    {f.m ? ' · ' + f.m.slice(0, 10) : ''}
                  </span>
                </div>
              </li>
            ))}
            {files.length > 100 && !more && (
              <li>
                <button type="button" className="u-link u-sm" style={{ padding: '6px 34px' }} onClick={() => setMore(true)}>
                  Show all {files.length.toLocaleString('en-IN')} files
                </button>
              </li>
            )}
          </motion.ul>
        )}
      </AnimatePresence>
    </li>
  );
}
