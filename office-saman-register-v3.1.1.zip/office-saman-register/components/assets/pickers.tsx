'use client';

import { useMemo } from 'react';
import { locLabel } from '@/lib/assets/model';
import { LOCATION_LABEL } from '@/lib/assets/types';
import { inr } from '@/lib/calc';
import { useReg } from '../context';
import { useAssets } from './store';

/** Location chuno (poora path dikhta hai). Bhara hua slot disabled. */
export function LocSelect({
  value,
  onChange,
  forDriveId,
  allowAny = true,
  id,
}: {
  value: string;
  onChange: (v: string) => void;
  forDriveId?: string;
  allowAny?: boolean;
  id?: string;
}) {
  const A = useAssets();
  const opts = useMemo(() => {
    const occ = new Map<string, string>();
    for (const d of A.drives) if (A.slotIds.has(d.locationId)) occ.set(d.locationId, d.id);
    return A.locs
      .filter((l) => allowAny || l.kind === 'slot')
      .map((l) => {
        const by = occ.get(l.id);
        const taken = !!by && by !== forDriveId;
        const holder = by ? A.driveMap.get(by)?.displayName : '';
        return { id: l.id, label: locLabel(A.locMap, l.id), kind: l.kind, taken, holder };
      })
      .sort((a, b) => a.label.localeCompare(b.label, 'en', { numeric: true }));
  }, [A, allowAny, forDriveId]);
  return (
    <select id={id} value={value} onChange={(e) => onChange(e.target.value)}>
      <option value="">— No location —</option>
      {opts.map((o) => (
        <option key={o.id} value={o.id} disabled={o.taken}>
          {o.label} ({LOCATION_LABEL[o.kind]}){o.taken ? ' — occupied by ' + o.holder : ''}
        </option>
      ))}
    </select>
  );
}

/** Purchase entry se jodo (Hard Disk / SSD / Pen Drive wali entries upar). Kharcha dobara nahi judta. */
export function PurchaseSelect({ value, onChange }: { value: string; onChange: (id: string) => void }) {
  const { items } = useReg();
  const A = useAssets();
  const list = useMemo(() => {
    const linked = new Map<string, number>();
    for (const d of A.drives) if (d.purchaseId) linked.set(d.purchaseId, (linked.get(d.purchaseId) || 0) + 1);
    const isStorage = (c: string, n: string) => /hard ?disk|ssd|pen ?drive|nvme|hdd|memory|sd card|storage/i.test(c + ' ' + n);
    return items
      .slice()
      .sort((a, b) => Number(isStorage(b.category, b.item)) - Number(isStorage(a.category, a.item)) || b.orderDate.localeCompare(a.orderDate))
      .map((it) => ({ it, linked: linked.get(it.id) || 0 }));
  }, [items, A.drives]);
  return (
    <select value={value} onChange={(e) => onChange(e.target.value)}>
      <option value="">— Not linked —</option>
      {list.map(({ it, linked }) => (
        <option key={it.id} value={it.id}>
          {it.item} · {it.vendor || '—'} · {it.orderDate} · {it.qty} pcs × {inr(it.rate)} {linked ? '· ' + linked + ' linked' : ''}
        </option>
      ))}
    </select>
  );
}
