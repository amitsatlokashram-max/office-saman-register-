'use client';

import Link from 'next/link';
import { useRouter, useSearchParams } from 'next/navigation';
import { useEffect, useMemo, useState } from 'react';
import {
  ArrowLeftRight,
  CheckCircle2,
  Database,
  HardDrive,
  Pencil,
  Plus,
  Printer,
  QrCode,
  ShieldCheck,
  Trash2,
} from 'lucide-react';
import { confirmTransfer, softDeleteDrive, subscribeDriveTransfers } from '@/lib/assets/db';
import { copyState, freeGB, gb, isOut, locLabel, overdue, usedPct, whereIs } from '@/lib/assets/model';
import { BACKUP_STATUS_LABEL, DRIVE_STATUS_LABEL, DRIVE_STATUS_TONE, DRIVE_TYPE_LABEL, TRANSFER_LABEL, type Transfer, type TransferKind } from '@/lib/assets/types';
import { inr, today } from '@/lib/calc';
import { useReg } from '../context';
import { Badge, Bar, Card, Empty, PageHeader, Tabs, fmtDate, fmtTime } from '../ui';
import { Barcode, QR, assetUrl } from './Codes';
import { CatalogForm } from './CatalogForm';
import { MoveDriveModal, ReceiptPrinter } from './Custody';
import { DriveForm } from './DriveForm';
import { FileExplorer } from './Files';
import { useAssets } from './store';

type TabId = 'overview' | 'custody' | 'data' | 'files' | 'backups' | 'qr';

const KIND_TONE: Partial<Record<TransferKind, 'indigo' | 'green' | 'amber' | 'red' | 'blue' | 'gray'>> = {
  issue: 'indigo',
  temp_issue: 'blue',
  return: 'green',
  restore: 'green',
  repair: 'amber',
  damaged: 'red',
  lost: 'red',
  retire: 'gray',
};

export function DriveProfile({ id }: { id: string }) {
  const A = useAssets();
  const { me, toast, openEntry, getItem } = useReg();
  const router = useRouter();
  const sp = useSearchParams();
  const d = A.driveMap.get(id);
  const [tab, setTab] = useState<TabId>('overview');
  const [edit, setEdit] = useState(false);
  const [move, setMove] = useState<TransferKind | null>(null);
  const [hist, setHist] = useState<Transfer[]>([]);
  const [printT, setPrintT] = useState<Transfer | null>(null);
  const [catOpen, setCatOpen] = useState(false);

  useEffect(() => {
    const t = sp.get('tab');
    if (t === 'files' || t === 'custody' || t === 'data' || t === 'backups' || t === 'qr') setTab(t);
    const a = sp.get('action');
    if (a === 'issue' || a === 'return') setMove(a);
  }, [sp]);
  useEffect(() => subscribeDriveTransfers(id, setHist), [id]);

  const data = useMemo(() => A.catalog.filter((c) => c.driveId === id), [A.catalog, id]);
  const baks = useMemo(() => A.backups.filter((b) => b.sourceDriveId === id || b.copyDriveId === id), [A.backups, id]);

  if (!A.loaded.drives) return <p className="u-muted">Loading…</p>;
  if (!d) {
    return (
      <Card>
        <Empty icon={HardDrive} title="Drive nahi mili" action={<Link href="/drives" className="btn">All drives</Link>}>
          Ye drive delete ho gayi ho sakti hai (Recycle bin dekho) ya aapko ise dekhne ki ijaazat nahi hai.
        </Empty>
      </Card>
    );
  }

  const purchase = d.purchaseId ? getItem(d.purchaseId) : undefined;
  const od = overdue(d, today());
  const loc = whereIs(d, A.locMap);
  const canMove = A.can('drives', 'transfer') && !d.deletedAt;

  return (
    <>
      <PageHeader
        title={
          <span className="u-row" style={{ gap: 12 }}>
            {d.displayName}
            <Badge tone={od ? 'red' : DRIVE_STATUS_TONE[d.status]}>{od ? 'Overdue return' : DRIVE_STATUS_LABEL[d.status]}</Badge>
            {d.deletedAt && <Badge tone="red">In recycle bin</Badge>}
          </span>
        }
        sub={[d.assetId, DRIVE_TYPE_LABEL[d.type], d.brand, d.model, gb(d.capacityGB)].filter(Boolean).join(' · ')}
        actions={
          <>
            {canMove && d.status === 'in_store' && (
              <button type="button" className="btn primary" onClick={() => setMove('issue')}>
                <ArrowLeftRight aria-hidden className="ic" /> Issue
              </button>
            )}
            {canMove && isOut(d.status) && (
              <button type="button" className="btn primary" onClick={() => setMove('return')}>
                <ArrowLeftRight aria-hidden className="ic" /> Return
              </button>
            )}
            {canMove && (
              <button type="button" className="btn" onClick={() => setMove('location_transfer')}>
                Transfer / status
              </button>
            )}
            {A.can('drives', 'edit') && !d.deletedAt && (
              <button type="button" className="btn" onClick={() => setEdit(true)}>
                <Pencil aria-hidden className="ic" /> Edit
              </button>
            )}
            {A.can('stickers', 'view') && (
              <Link className="btn" href={'/stickers?ids=' + d.id}>
                <QrCode aria-hidden className="ic" /> Sticker
              </Link>
            )}
            {A.can('drives', 'delete') && !d.deletedAt && (
              <button
                type="button"
                className="btn quiet-danger"
                onClick={async () => {
                  if (!window.confirm(d.displayName + ' recycle bin me bhejni hai? (Baad me wapas la sakte ho)')) return;
                  try {
                    await softDeleteDrive(d, me);
                    toast('✓ Moved to recycle bin');
                    router.push('/drives');
                  } catch (e) {
                    toast(e instanceof Error ? e.message : 'Nahi hua');
                  }
                }}
                aria-label="Move to recycle bin"
              >
                <Trash2 aria-hidden className="ic" />
              </button>
            )}
          </>
        }
      />

      <Tabs
        value={tab}
        onChange={setTab}
        tabs={[
          { value: 'overview', label: 'Overview' },
          { value: 'custody', label: 'Custody history (' + hist.length + ')' },
          ...(A.can('catalog', 'view') ? [{ value: 'data' as const, label: 'Data (' + data.length + ')' }, { value: 'files' as const, label: 'Files' }] : []),
          ...(A.can('backups', 'view') ? [{ value: 'backups' as const, label: 'Backups (' + baks.length + ')' }] : []),
          { value: 'qr', label: 'QR / barcode' },
        ]}
      />

      {tab === 'overview' && (
        <div className="u-grid span-2-1">
          <div className="u-stack">
            <Card title="Storage">
              <div className="u-between" style={{ marginBottom: 8 }}>
                <span className="u-strong" style={{ fontSize: '1.3rem' }}>
                  {gb(d.usedGB)} <span className="u-muted u-sm">used of {gb(d.capacityGB)}</span>
                </span>
                <span className="u-muted">{gb(freeGB(d))} free</span>
              </div>
              <Bar pct={usedPct(d)} />
              <p className="u-sm u-faint" style={{ marginTop: 8 }}>
                {d.lastScanAt ? 'Last scan: ' + fmtTime(d.lastScanAt) : 'Abhi tak scan nahi hua — used space haath se likha hai.'}
              </p>
            </Card>
            <Card title="Details">
              <dl className="u-kv">
                {(
                  [
                    ['Asset ID', d.assetId],
                    ['Mark number', String(d.markNo)],
                    ['Type', DRIVE_TYPE_LABEL[d.type] + ' · ' + (d.form === 'internal' ? 'Internal' : 'External')],
                    ['Brand / model', [d.brand, d.model].filter(Boolean).join(' ')],
                    ['Serial no.', d.serial],
                    ['Interface', d.iface],
                    ['File system', d.fileSystem],
                    ['Condition', d.condition],
                    ['Health', d.health],
                    ['Department', d.dept],
                    ['Purchase date', fmtDate(d.purchaseDate)],
                    ['Price', d.price ? inr(d.price) : ''],
                    ['Bill / order', d.billNo],
                    ['Warranty till', fmtDate(d.warrantyTill)],
                    ['Registered', fmtTime(d.createdAt) + (d.createdByName ? ' · ' + d.createdByName : '')],
                    ['Last change', fmtTime(d.updatedAt) + (d.updatedByName ? ' · ' + d.updatedByName : '')],
                    ...Object.entries(d.custom),
                  ] as [string, string][]
                )
                  .filter(([, x]) => x)
                  .map(([k, x]) => (
                    <div key={k}>
                      <dt>{k}</dt>
                      <dd>{x}</dd>
                    </div>
                  ))}
              </dl>
              {d.description && <p style={{ marginTop: 12 }}>{d.description}</p>}
            </Card>
          </div>
          <div className="u-stack">
            {A.can('catalog', 'view') && (
              <Card title={'Is drive me data (' + data.length + ')'} action={data.length > 0 ? <button type="button" className="btn sm ghost" onClick={() => setTab('data')}>All</button> : undefined}>
                {data.length === 0 ? (
                  <p className="u-muted u-sm">Abhi koi data record nahi. &ldquo;Data&rdquo; tab se jodo.</p>
                ) : (
                  <ul style={{ listStyle: 'none', margin: 0, padding: 0, display: 'grid', gap: 8 }}>
                    {data.slice(0, 6).map((c) => (
                      <li key={c.id}>
                        <Link className="u-link" href={'/catalog?open=' + c.id}>
                          {[c.project, c.title].filter(Boolean).join(' · ')}
                        </Link>
                        <div className="u-sm u-muted">
                          {[c.eventName, c.eventDate && fmtDate(c.eventDate), c.sizeGB ? gb(c.sizeGB) : '', c.folderPath].filter(Boolean).join(' · ')}
                        </div>
                      </li>
                    ))}
                    {data.length > 6 && <li className="u-sm u-faint">+{data.length - 6} more</li>}
                  </ul>
                )}
              </Card>
            )}
            <Card title="Custody">
              {d.holder ? (
                <div className="u-stack" style={{ gap: 6 }}>
                  <b style={{ fontSize: '1.1rem' }}>{d.holder.name}</b>
                  <span className="u-muted">{d.holder.dept || '—'}</span>
                  <span className="u-sm">Since {fmtDate(d.holder.since)}</span>
                  {d.holder.expectedReturn && <span className={'u-sm' + (od ? ' err' : '')}>Return by {fmtDate(d.holder.expectedReturn)}</span>}
                </div>
              ) : (
                <p className="u-muted">{d.status === 'in_store' ? 'Store me hai (kisi ke paas nahi).' : DRIVE_STATUS_LABEL[d.status]}</p>
              )}
            </Card>
            <Card title="Location">
              <p>{loc || <span className="u-muted">Location set nahi hai.</span>}</p>
              {isOut(d.status) && loc && <p className="u-sm u-muted">Abhi bahar hai — wapsi pe isi jagah rakhni hai.</p>}
            </Card>
            <Card title="Purchase">
              {purchase ? (
                <div className="u-stack" style={{ gap: 4 }}>
                  <button type="button" className="u-link" style={{ textAlign: 'left' }} onClick={() => openEntry(purchase.id)}>
                    {purchase.item}
                  </button>
                  <span className="u-sm u-muted">
                    {purchase.vendor} · {fmtDate(purchase.orderDate)} · {purchase.qty} pcs × {inr(purchase.rate)}
                  </span>
                  <span className="u-sm u-faint">Kharcha isi purchase entry me gina jata hai.</span>
                </div>
              ) : (
                <p className="u-muted u-sm">Kisi purchase entry se nahi judi.</p>
              )}
            </Card>
          </div>
        </div>
      )}

      {tab === 'custody' && (
        <Card>
          {hist.length === 0 ? (
            <Empty icon={ArrowLeftRight} title="Abhi tak koi issue / return nahi" />
          ) : (
            <div className="u-card-b">
              <ul className="u-tl">
                {hist.map((t) => (
                  <li key={t.id} className={'tone-' + (KIND_TONE[t.kind] || 'indigo')}>
                    <span className="dot" />
                    <div className="u-between">
                      <b>{TRANSFER_LABEL[t.kind]}</b>
                      <span className="u-sm u-faint">{fmtTime(t.at)}</span>
                    </div>
                    <p>
                      {t.kind === 'location_transfer'
                        ? ([t.from.place, locLabel(A.locMap, t.from.locationId)].filter(Boolean).join(' · ') || '—') + ' → ' + ([t.to.place, locLabel(A.locMap, t.to.locationId)].filter(Boolean).join(' · ') || '—')
                        : ([t.from.name, t.from.dept].filter(Boolean).join(' / ') || '—') + ' → ' + ([t.to.name, t.to.dept].filter(Boolean).join(' / ') || '—')}
                    </p>
                    <p>
                      {fmtDate(t.date)}
                      {t.expectedReturn && ' · return by ' + fmtDate(t.expectedReturn)}
                      {t.actualReturn && t.kind !== 'return' && ' · returned ' + fmtDate(t.actualReturn)}
                      {t.purpose && ' · ' + t.purpose}
                      {t.condition && ' · ' + t.condition}
                      {t.usedGB ? ' · ' + gb(t.usedGB) + ' used' : ''}
                      {' · by ' + t.byName}
                    </p>
                    {t.notes && <p>{t.notes}</p>}
                    <div className="u-row" style={{ marginTop: 6 }}>
                      <button type="button" className="btn sm" onClick={() => setPrintT(t)}>
                        <Printer aria-hidden className="ic" /> Receipt
                      </button>
                      {t.confirmed ? (
                        <Badge tone="green">Confirmed by {t.confirmedBy}</Badge>
                      ) : (
                        canMove && (
                          <button
                            type="button"
                            className="btn sm ghost"
                            onClick={() =>
                              confirmTransfer(t, me).then(
                                () => toast('✓ Confirmed'),
                                () => toast('Confirm nahi hua'),
                              )
                            }
                          >
                            <CheckCircle2 aria-hidden className="ic" /> Mark confirmed
                          </button>
                        )
                      )}
                    </div>
                  </li>
                ))}
              </ul>
            </div>
          )}
        </Card>
      )}

      {tab === 'data' && (
        <Card
          title="Is drive me kya data hai"
          action={
            A.can('catalog', 'create') && (
              <button type="button" className="btn sm primary" onClick={() => setCatOpen(true)}>
                <Plus aria-hidden className="ic" /> Add data
              </button>
            )
          }
        >
          {data.length === 0 ? (
            <Empty icon={Database} title="Catalogue khaali">
              Project, episode, event — jo bhi data is drive me hai, yahan likho.
            </Empty>
          ) : (
            <div className="u-table-wrap" style={{ maxHeight: 'none' }}>
              <table className="u-table">
                <thead>
                  <tr>
                    <th>Project / title</th>
                    <th>Category</th>
                    <th>Folder</th>
                    <th className="num">Size</th>
                    <th>Backup</th>
                  </tr>
                </thead>
                <tbody>
                  {data.map((c) => {
                    const s = copyState(c, A.backups);
                    return (
                      <tr key={c.id} className="click" onClick={() => router.push('/catalog?open=' + c.id)}>
                        <td>
                          <b>{[c.project, c.title].filter(Boolean).join(' · ')}</b>
                          {c.episode && <div className="u-sm u-muted">Ep {c.episode}</div>}
                        </td>
                        <td>{c.category}</td>
                        <td className="u-mono u-sm">{c.folderPath || '—'}</td>
                        <td className="num">{c.sizeGB ? gb(c.sizeGB) : '—'}</td>
                        <td>
                          <Badge tone={s.state === 'verified' ? 'green' : s.state === 'none' ? 'red' : 'amber'}>
                            {s.state === 'none' ? 'Single copy' : s.state === 'verified' ? s.verified + ' verified' : s.state === 'outdated' ? 'Outdated' : s.copies + ' unverified'}
                          </Badge>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          )}
        </Card>
      )}

      {tab === 'files' && (
        <Card title="Files & folders" sub="Scan se aayi file list (sirf metadata)">
          <FileExplorer drive={d} canImport={A.can('catalog', 'create')} openPath={sp.get('path') || ''} />
        </Card>
      )}

      {tab === 'backups' && (
        <Card title="Backups" action={<Link href="/backups" className="btn sm">Backup management</Link>}>
          {baks.length === 0 ? (
            <Empty icon={ShieldCheck} title="Is drive se juda koi backup record nahi" />
          ) : (
            <ul className="u-stack" style={{ listStyle: 'none', margin: 0, padding: 0 }}>
              {baks.map((b) => {
                const c = A.catalog.find((x) => x.id === b.catalogId);
                const other = A.driveMap.get(b.sourceDriveId === id ? b.copyDriveId : b.sourceDriveId);
                return (
                  <li key={b.id} className="u-between">
                    <span>
                      <b>{c ? c.title || c.project : 'Catalogue entry'}</b>{' '}
                      <span className="u-muted u-sm">
                        {b.sourceDriveId === id ? 'copy on ' : 'original on '}
                        {other?.displayName || '—'}
                      </span>
                    </span>
                    <Badge tone={b.status === 'verified' ? 'green' : b.status === 'failed' ? 'red' : b.status === 'completed' ? 'amber' : 'gray'}>{BACKUP_STATUS_LABEL[b.status]}</Badge>
                  </li>
                );
              })}
            </ul>
          )}
        </Card>
      )}

      {tab === 'qr' && (
        <Card title="QR code & barcode" sub="QR scan karne par login ke baad yahi page khulta hai">
          <div className="u-row" style={{ gap: 32, alignItems: 'flex-start' }}>
            <div style={{ background: '#fff', padding: 14, borderRadius: 14, border: '1px solid var(--line)' }}>
              <QR text={assetUrl(d.assetId)} size={180} />
            </div>
            <div className="u-stack">
              <div style={{ background: '#fff', padding: 12, borderRadius: 12, border: '1px solid var(--line)', width: 280 }}>
                <Barcode text={d.assetId} height={70} showText />
              </div>
              <span className="u-mono u-sm">{assetUrl(d.assetId)}</span>
              {A.can('stickers', 'view') && (
                <Link className="btn primary" href={'/stickers?ids=' + d.id}>
                  <Printer aria-hidden className="ic" /> Print sticker
                </Link>
              )}
            </div>
          </div>
        </Card>
      )}

      <DriveForm open={edit} onClose={() => setEdit(false)} drive={d} />
      {move && <MoveDriveModal drive={d} initialKind={move} onClose={() => setMove(null)} />}
      {printT && <ReceiptPrinter t={printT} drive={d} locs={A.locMap} onDone={() => setPrintT(null)} />}
      <CatalogForm open={catOpen} onClose={() => setCatOpen(false)} entry={null} driveId={d.id} />
    </>
  );
}
