'use client';

// Nayi drive (ek ya bulk me kai) ya purani drive edit. Mark number apne aap agla, duplicate ki rok transaction me.

import { useEffect, useMemo, useState } from 'react';
import Link from 'next/link';
import { motion } from 'motion/react';
import { CheckCircle2, HardDrive, Info, Plus, Printer, Trash2 } from 'lucide-react';
import { createDrives, updateDrive, type DriveInput } from '@/lib/assets/db';
import { nextMarkIn, seriesName } from '@/lib/assets/model';
import { CONDITIONS, DRIVE_FORMS, DRIVE_TYPES, DRIVE_TYPE_LABEL, HEALTH, SERIES, SERIES_LABEL, SERIES_OF, type Drive, type DriveType, type SeriesKey } from '@/lib/assets/types';
import { QR, assetUrl } from './Codes';
import { num } from '@/lib/calc';
import { useReg } from '../context';
import { Alert, Field, Modal, useBusy } from '../ui';
import { LocSelect, PurchaseSelect } from './pickers';
import { useAssets } from './store';

type V = {
  series: SeriesKey;
  place: string;
  customName: string;
  type: DriveType;
  form: 'external' | 'internal';
  brand: string;
  model: string;
  serial: string;
  cap: string;
  capUnit: 'GB' | 'TB';
  used: string;
  iface: string;
  fileSystem: string;
  purchaseDate: string;
  price: string;
  purchaseId: string;
  billNo: string;
  warrantyTill: string;
  condition: string;
  health: string;
  dept: string;
  locationId: string;
  description: string;
  custom: [string, string][];
  // bulk
  count: string;
  start: string;
  serials: string;
  fillShelf: string;
  markNo: string;
};

const IFACES = ['USB 3.0', 'USB 3.2', 'USB-C', 'Thunderbolt', 'SATA', 'NVMe (PCIe)', 'SAS', 'SD', 'microSD', 'Other'];
const FS = ['exFAT', 'NTFS', 'APFS', 'HFS+', 'FAT32', 'ext4', 'Other'];

function init(d: Drive | null, next: number, type: DriveType = 'HDD'): V {
  const capTB = d && d.capacityGB >= 1000 && d.capacityGB % 1000 === 0;
  return {
    series: d?.series || SERIES_OF[type],
    place: d?.place || '',
    customName: '',
    type: d?.type || type,
    form: d?.form || 'external',
    brand: d?.brand || '',
    model: d?.model || '',
    serial: d?.serial || '',
    cap: d ? String(capTB ? d.capacityGB / 1000 : d.capacityGB || '') : '',
    capUnit: d ? (capTB ? 'TB' : 'GB') : 'TB',
    used: d ? String(d.usedGB || '') : '',
    iface: d?.iface || '',
    fileSystem: d?.fileSystem || '',
    purchaseDate: d?.purchaseDate || '',
    price: d ? String(d.price || '') : '',
    purchaseId: d?.purchaseId || '',
    billNo: d?.billNo || '',
    warrantyTill: d?.warrantyTill || '',
    condition: d?.condition || 'New',
    health: d?.health || 'Unknown',
    dept: d?.dept || '',
    locationId: d?.locationId || '',
    description: d?.description || '',
    custom: d ? Object.entries(d.custom) : [],
    count: '1',
    start: String(next),
    serials: '',
    fillShelf: '',
    markNo: d ? String(d.markNo) : String(next),
  };
}

export function DriveForm({ open, onClose, drive, onSaved }: { open: boolean; onClose: () => void; drive: Drive | null; onSaved?: (ids: string[]) => void }) {
  const A = useAssets();
  const { me, toast, getItem } = useReg();
  const [v, setV] = useState<V>(() => init(drive, 1));
  const [created, setCreated] = useState<string[] | null>(null);
  const next = useMemo(() => nextMarkIn(A.allDrives, v.series, A.naming), [A.allDrives, v.series, A.naming]);
  const naming = A.naming[v.series];
  const [err, setErr] = useState('');
  const [busy, run] = useBusy();
  useEffect(() => {
    if (open) {
      const t: DriveType = drive?.type || 'HDD';
      setV(init(drive, nextMarkIn(A.allDrives, drive?.series || SERIES_OF[t], A.naming), t));
      setErr('');
      setCreated(null);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [open, drive?.id]);

  const set = <K extends keyof V>(k: K, val: V[K]) => setV((p) => ({ ...p, [k]: val }));
  // Drives / naming der se load ho to "shuruaati number" agle khaali number ke saath chalta rahe (jab tak haath se na badla)
  const [startTouched, setStartTouched] = useState(false);
  useEffect(() => {
    if (open && !drive && !startTouched) setV((p) => (p.start === String(next) ? p : { ...p, start: String(next) }));
  }, [next, open, drive, startTouched]);
  useEffect(() => {
    if (open) setStartTouched(false);
  }, [open]);
  const count = drive ? 1 : Math.max(1, Math.min(100, Math.round(num(v.count)) || 1));
  const start = Math.round(num(v.start)) || next;

  const shelves = A.locs.filter((l) => A.locs.some((c) => c.parentId === l.id && c.kind === 'slot'));
  const freeSlots = useMemo(() => {
    if (!v.fillShelf) return [];
    const occ = new Set(A.drives.map((d) => d.locationId));
    return A.locs.filter((l) => l.parentId === v.fillShelf && l.kind === 'slot' && !occ.has(l.id));
  }, [v.fillShelf, A.locs, A.drives]);

  // Type badle to series aur agla number bhi badlo (nayi drive me)
  const setType = (t: DriveType) =>
    setV((p) => {
      const series = SERIES_OF[t];
      return drive ? { ...p, type: t } : { ...p, type: t, series, start: String(nextMarkIn(A.allDrives, series, A.naming)) };
    });
  const setSeries = (series: SeriesKey) => setV((p) => (drive ? { ...p, series } : { ...p, series, start: String(nextMarkIn(A.allDrives, series, A.naming)) }));

  const marksUsed = useMemo(() => {
    const s = new Set(A.allDrives.filter((d) => d.series === v.series && d.id !== drive?.id).map((d) => d.markNo));
    const clash: number[] = [];
    for (let i = 0; i < count; i++) if (s.has(start + i)) clash.push(start + i);
    return clash;
  }, [A.allDrives, count, start, v.series, drive?.id]);

  const linked = v.purchaseId ? getItem(v.purchaseId) : undefined;
  const linkedCount = v.purchaseId ? A.drives.filter((d) => d.purchaseId === v.purchaseId && d.id !== drive?.id).length + (drive ? 1 : count) : 0;

  const pickPurchase = (id: string) => {
    const it = getItem(id);
    setV((p) => ({
      ...p,
      purchaseId: id,
      ...(it
        ? {
            purchaseDate: p.purchaseDate || it.receivedDate || it.orderDate,
            price: p.price || (it.rate ? String(it.rate) : ''),
            billNo: p.billNo || it.billNo,
            warrantyTill: p.warrantyTill || it.warrantyTill,
            serial: p.serial || (drive ? '' : ''),
            serials: !drive && !p.serials && it.serials ? it.serials : p.serials,
          }
        : {}),
    }));
  };

  const input = (): DriveInput => ({
    series: v.series,
    place: v.place.trim(),
    markNo: Math.round(num(v.markNo)) || start,
    displayName: '',
    type: v.type,
    form: v.form,
    brand: v.brand.trim(),
    model: v.model.trim(),
    serial: v.serial.trim(),
    capacityGB: Math.round(num(v.cap) * (v.capUnit === 'TB' ? 1000 : 1) * 100) / 100,
    usedGB: Math.max(0, num(v.used)),
    iface: v.iface,
    fileSystem: v.fileSystem,
    purchaseDate: v.purchaseDate,
    price: Math.max(0, num(v.price)),
    purchaseId: v.purchaseId,
    billNo: v.billNo.trim(),
    warrantyTill: v.warrantyTill,
    photos: drive?.photos || [],
    condition: v.condition,
    health: v.health,
    dept: v.dept.trim(),
    locationId: v.locationId,
    lastScanAt: drive?.lastScanAt || '',
    lastBackupAt: drive?.lastBackupAt || '',
    description: v.description.trim(),
    custom: Object.fromEntries(v.custom.filter(([k]) => k.trim()).map(([k, x]) => [k.trim().slice(0, 60), x.trim().slice(0, 300)])),
  });

  const submit = () =>
    run(async () => {
      setErr('');
      const base = input();
      if (!(base.capacityGB > 0)) return setErr('Capacity likho (jaise 2 TB).');
      if (base.usedGB > base.capacityGB) return setErr('Used space capacity se zyada nahi ho sakta.');
      try {
        if (drive) {
          if (!(base.markNo > 0)) return setErr('Mark number 1 ya usse bada likho.');
          const clash = A.allDrives.find((d) => d.id !== drive.id && d.series === base.series && d.markNo === base.markNo);
          if (clash) return setErr('Ye number ' + clash.displayName + ' ka hai.');
          const displayName = v.customName.trim() || (base.markNo === drive.markNo && base.series === drive.series ? drive.displayName : seriesName(naming, base.markNo));
          await updateDrive(drive.id, { ...base, displayName }, me, A.slotIds);
          toast('✓ ' + displayName + ' saved');
          onSaved?.([drive.id]);
          onClose();
          return;
        } else {
          if (marksUsed.length) return setErr('Ye pehle se hai: ' + marksUsed.map((m) => seriesName(naming, m)).join(', '));
          const serials = v.serials.split(/[\n,;]+/).map((s) => s.trim()).filter(Boolean);
          if (count === 1 && v.serial.trim()) serials.unshift(v.serial.trim());
          if (serials.length > count) return setErr(serials.length + ' serial number diye, par drives ' + count + ' hai.');
          const slots = v.fillShelf ? freeSlots.slice(0, count).map((s) => s.id) : [];
          if (v.fillShelf && slots.length < count) return setErr('Is shelf me sirf ' + slots.length + ' khaali slot hai.');
          const ids = await createDrives({ series: v.series, naming, start, count, base, serials, slots, customName: v.customName }, me, A.slotIds);
          toast('✓ ' + count + ' drive' + (count > 1 ? 's' : '') + ' registered');
          onSaved?.(ids);
          setCreated(ids);
        }
      } catch (e) {
        setErr(e instanceof Error ? e.message : 'Save nahi hua. Net check karke dobara try karo.');
      }
    });

  if (created) {
    const made = created.map((id) => A.driveMap.get(id)).filter((d): d is Drive => !!d);
    return (
      <Modal
        open={open}
        onClose={onClose}
        size="lg"
        title={'✓ ' + created.length + ' drive registered'}
        sub="Har drive ka QR ban gaya. Scan karne par uska data, holder aur jagah dikhegi. Naam badle tab bhi QR wahi rahega."
        foot={
          <>
            <button type="button" className="btn" onClick={onClose}>
              Done
            </button>
            <Link className="btn primary" href={'/stickers?ids=' + created.join(',')} onClick={onClose}>
              <Printer aria-hidden className="ic" /> Print stickers
            </Link>
          </>
        }
      >
        <div className="u-grid auto">
          {(made.length ? made : []).map((d, i) => (
            <motion.div key={d.id} className="u-card pad" style={{ textAlign: 'center' }} initial={{ opacity: 0, scale: 0.85, rotateX: 25 }} animate={{ opacity: 1, scale: 1, rotateX: 0 }} transition={{ delay: i * 0.08, type: 'spring', stiffness: 260, damping: 20 }}>
              <div style={{ background: '#fff', padding: 10, borderRadius: 12, display: 'inline-block' }}>
                <QR text={assetUrl(d.assetId)} size={120} />
              </div>
              <div className="d-name" style={{ marginTop: 8 }}>{d.displayName}</div>
              <div className="u-sm u-muted">{d.assetId}</div>
            </motion.div>
          ))}
          {!made.length && (
            <div className="u-empty">
              <CheckCircle2 aria-hidden /> Saved
            </div>
          )}
        </div>
      </Modal>
    );
  }

  return (
    <Modal
      open={open}
      onClose={onClose}
      size="lg"
      title={drive ? 'Edit ' + drive.displayName : 'Register Hard Disk / SSD'}
      sub={drive ? drive.assetId : 'Ek ya ek saath kai drives. Mark number apne aap agla milta hai.'}
      onSubmit={submit}
      foot={
        <>
          <button type="button" className="btn" onClick={onClose}>
            Cancel
          </button>
          <button type="submit" className="btn primary" disabled={busy}>
            <HardDrive aria-hidden className="ic" /> {busy ? 'Saving…' : drive ? 'Save changes' : count > 1 ? 'Register ' + count + ' drives' : 'Register drive'}
          </button>
        </>
      }
    >
      {err && <div className="ferr">{err}</div>}

      <div className="fsec">
        <h3 className="fsh">Naam (apne aap)</h3>
        <div className="fgrid g3">
          <Field label="Type">
            <select value={v.type} onChange={(e) => setType(e.target.value as DriveType)}>
              {DRIVE_TYPES.map((t) => (
                <option key={t} value={t}>
                  {DRIVE_TYPE_LABEL[t]}
                </option>
              ))}
            </select>
          </Field>
          <Field label="Naam ki series" hint={'Settings → Naming series se badal sakte ho'}>
            <select value={v.series} onChange={(e) => setSeries(e.target.value as SeriesKey)}>
              {SERIES.map((k) => (
                <option key={k} value={k}>
                  {SERIES_LABEL[k]} — {seriesName(A.naming[k], 1).replace(/1$/, '…')}
                </option>
              ))}
            </select>
          </Field>
          {drive ? (
            <Field label="Number">
              <input type="number" min={1} value={v.markNo} onChange={(e) => set('markNo', e.target.value)} required />
            </Field>
          ) : (
            <Field label="Kitni drives" hint="1–100 ek saath">
              <input type="number" min={1} max={100} value={v.count} onChange={(e) => set('count', e.target.value)} />
            </Field>
          )}
          {!drive && (
            <Field label="Shuruaati number" hint={'Agla khaali: ' + next}>
              <input
                type="number"
                min={1}
                value={v.start}
                onChange={(e) => {
                  setStartTouched(true);
                  set('start', e.target.value);
                }}
              />
            </Field>
          )}
          {(drive || count === 1) && (
            <Field label="Apna naam (purani drive ho to)" hint="Khaali = series wala naam" span={!drive}>
              <input value={v.customName} onChange={(e) => set('customName', e.target.value)} maxLength={80} placeholder={drive ? drive.displayName : ''} />
            </Field>
          )}
        </div>
        {!drive && (
          <motion.p className="hint" key={v.series + start + count} initial={{ opacity: 0.3 }} animate={{ opacity: 1 }}>
            Banenge: <b style={{ color: 'var(--accent-text)', fontSize: '1rem' }}>{v.customName.trim() && count === 1 ? v.customName : seriesName(naming, start)}</b>
            {count > 1 && (
              <>
                {' '}
                se <b style={{ color: 'var(--accent-text)', fontSize: '1rem' }}>{seriesName(naming, start + count - 1)}</b> ({count})
              </>
            )}
            {marksUsed.length > 0 && <span className="err"> — {marksUsed.map((m) => seriesName(naming, m)).join(', ')} pehle se hai</span>}
          </motion.p>
        )}
      </div>

      <div className="fsec">
        <h3 className="fsh">Drive ki jaankari</h3>
        <div className="fgrid g3">
          <Field label="Internal / External">
            <select value={v.form} onChange={(e) => set('form', e.target.value as V['form'])}>
              {DRIVE_FORMS.map((t) => (
                <option key={t} value={t}>
                  {t === 'external' ? 'External' : 'Internal'}
                </option>
              ))}
            </select>
          </Field>
          <Field label="Brand">
            <input value={v.brand} onChange={(e) => set('brand', e.target.value)} list="dl-brands" maxLength={60} />
          </Field>
          <Field label="Model">
            <input value={v.model} onChange={(e) => set('model', e.target.value)} maxLength={80} />
          </Field>
          <Field label="Capacity">
            <div className="u-row" style={{ flexWrap: 'nowrap' }}>
              <input type="number" min={0} step="any" value={v.cap} onChange={(e) => set('cap', e.target.value)} required />
              <select value={v.capUnit} onChange={(e) => set('capUnit', e.target.value as 'GB' | 'TB')} style={{ width: 82 }}>
                <option>TB</option>
                <option>GB</option>
              </select>
            </div>
          </Field>
          <Field label="Used space (GB)" hint="Scan import se apne aap bhi aata hai">
            <input type="number" min={0} step="any" value={v.used} onChange={(e) => set('used', e.target.value)} />
          </Field>
          <Field label="Interface">
            <select value={v.iface} onChange={(e) => set('iface', e.target.value)}>
              <option value="">—</option>
              {IFACES.map((x) => (
                <option key={x}>{x}</option>
              ))}
            </select>
          </Field>
          <Field label="File system">
            <select value={v.fileSystem} onChange={(e) => set('fileSystem', e.target.value)}>
              <option value="">—</option>
              {FS.map((x) => (
                <option key={x}>{x}</option>
              ))}
            </select>
          </Field>
          {(drive || count === 1) && (
            <Field label="Serial number">
              <input value={v.serial} onChange={(e) => set('serial', e.target.value)} maxLength={120} autoComplete="off" />
            </Field>
          )}
          <Field label="Condition">
            <select value={v.condition} onChange={(e) => set('condition', e.target.value)}>
              {CONDITIONS.map((x) => (
                <option key={x}>{x}</option>
              ))}
            </select>
          </Field>
          <Field label="Health" hint="SMART ho to wahi">
            <select value={v.health} onChange={(e) => set('health', e.target.value)}>
              {HEALTH.map((x) => (
                <option key={x}>{x}</option>
              ))}
            </select>
          </Field>
          <Field label="Department">
            <input value={v.dept} onChange={(e) => set('dept', e.target.value)} list="dl-depts" maxLength={60} />
          </Field>
        </div>
        {!drive && count > 1 && (
          <Field label="Serial numbers (optional)" hint="Har line me ek, usi order me jo Mark number ka hai">
            <textarea value={v.serials} onChange={(e) => set('serials', e.target.value)} rows={3} />
          </Field>
        )}
      </div>

      <div className="fsec">
        <h3 className="fsh">Kahan rakhi hai</h3>
        <Field label="Jagah" hint="Jaise: Main Media Office, Computer Room, Delhi Office, Almari 2 — jo aap bolte ho wahi likho">
          <input value={v.place} onChange={(e) => set('place', e.target.value)} list="dl-places" maxLength={120} />
        </Field>
        <details>
          <summary className="u-sm u-muted" style={{ cursor: 'pointer' }}>Rack / slot bhi chahiye? (optional)</summary>
        <div className="fgrid" style={{ marginTop: 10 }}>
          {(drive || !v.fillShelf) && (
            <Field label="Location / slot">
              <LocSelect value={v.locationId} onChange={(x) => set('locationId', x)} forDriveId={drive?.id} />
            </Field>
          )}
          {!drive && shelves.length > 0 && (
            <Field label="Ya shelf ke khaali slots me ek-ek karke" hint={v.fillShelf ? freeSlots.length + ' khaali slot' : undefined}>
              <select value={v.fillShelf} onChange={(e) => set('fillShelf', e.target.value)}>
                <option value="">—</option>
                {shelves.map((s) => (
                  <option key={s.id} value={s.id}>
                    {s.name}
                  </option>
                ))}
              </select>
            </Field>
          )}
        </div>
        </details>
      </div>

      <div className="fsec">
        <h3 className="fsh">Purchase &amp; warranty</h3>
        <div className="fgrid">
          <Field label="Purchase entry se jodo" span hint="Kharcha sirf purchase entry me ginta hai — drive jodne se dobara nahi judta.">
            <PurchaseSelect value={v.purchaseId} onChange={pickPurchase} />
          </Field>
        </div>
        {linked && linkedCount > linked.qty && (
          <Alert tone="amber" icon={Info}>
            Is purchase me {linked.qty} piece hai, par ab {linkedCount} drives judi hongi. Check karo ki sahi entry chuni hai.
          </Alert>
        )}
        <div className="fgrid g3">
          <Field label="Purchase date">
            <input type="date" value={v.purchaseDate} onChange={(e) => set('purchaseDate', e.target.value)} />
          </Field>
          <Field label="Price per drive (₹)">
            <input type="number" min={0} step="any" value={v.price} onChange={(e) => set('price', e.target.value)} />
          </Field>
          <Field label="Bill / order no.">
            <input value={v.billNo} onChange={(e) => set('billNo', e.target.value)} maxLength={80} />
          </Field>
          <Field label="Warranty till">
            <input type="date" value={v.warrantyTill} onChange={(e) => set('warrantyTill', e.target.value)} />
          </Field>
        </div>
      </div>

      <div className="fsec">
        <h3 className="fsh">Description &amp; custom fields</h3>
        <Field label="Description">
          <textarea value={v.description} onChange={(e) => set('description', e.target.value)} rows={2} maxLength={4000} />
        </Field>
        {v.custom.map(([k, x], i) => (
          <div className="u-row" key={i} style={{ flexWrap: 'nowrap' }}>
            <input placeholder="Field" value={k} onChange={(e) => set('custom', v.custom.map((c, j) => (j === i ? [e.target.value, c[1]] : c)))} />
            <input placeholder="Value" value={x} onChange={(e) => set('custom', v.custom.map((c, j) => (j === i ? [c[0], e.target.value] : c)))} />
            <button type="button" className="u-iconbtn" aria-label="Remove field" onClick={() => set('custom', v.custom.filter((_, j) => j !== i))}>
              <Trash2 aria-hidden />
            </button>
          </div>
        ))}
        <div>
          <button type="button" className="btn sm" onClick={() => set('custom', [...v.custom, ['', '']])} disabled={v.custom.length >= 20}>
            <Plus aria-hidden className="ic" /> Add field
          </button>
        </div>
      </div>
    </Modal>
  );
}
