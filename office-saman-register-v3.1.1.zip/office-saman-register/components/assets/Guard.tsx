'use client';

import type { ReactNode } from 'react';
import { Lock } from 'lucide-react';
import type { Action, Module } from '@/lib/perm';
import { Card, Empty } from '../ui';
import { useAssets } from './store';

/** Page tabhi dikhao jab role ko ijaazat ho (asli rok Firestore Rules me bhi hai). */
export function Guard({ m, a = 'view', children }: { m: Module; a?: Action; children: ReactNode }) {
  const A = useAssets();
  if (!A.access) return <p className="u-muted">Loading…</p>;
  if (!A.can(m, a))
    return (
      <Card>
        <Empty icon={Lock} title="Is page ki ijaazat nahi hai">
          Aapke role ko ye module dekhne ki permission nahi hai. Zaroorat ho to Super Admin se Roles page me ijaazat maango.
        </Empty>
      </Card>
    );
  return <>{children}</>;
}
