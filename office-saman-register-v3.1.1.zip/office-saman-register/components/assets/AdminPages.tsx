'use client';

import Link from 'next/link';
import { useEffect, useMemo, useState } from 'react';
import { Archive, Info, KeyRound, RotateCcw, ScrollText, ShieldAlert, Trash2, UserPlus } from 'lucide-react';
import { purgeCatalog, purgeDrive, readAudit, restoreDrive, saveAccess, setCatalogDeleted, setEventDeleted } from '@/lib/assets/db';
import type { Audit } from '@/lib/assets/types';
import { ACTIONS, ACTION_LABEL, MODULES, MODULE_LABEL, ROLES, ROLE_HINT, ROLE_LABEL, defaultPermMap, type PermMap, type Role } from '@/lib/perm';
import { useReg } from '../context';
import { DataTable, type Col } from '../ui/DataTable';
import { Alert, Badge, Card, Empty, PageHeader, Segmented, fmtTime, useBusy } from '../ui';
import { useAssets } from './store';

/* ---------------- ROLES ---------------- */
export function RolesPage() {
  const A = useAssets();
  const { me, toast } = useReg();
  const d = A.accessDoc;
  const canEdit = A.access?.isOwner || A.access?.role === 'superadmin';
  const [emails, setEmails] = useState<string[]>([]);
  const [roles, setRoles] = useState<Record<string, Role>>({});
  const [perms, setPerms] = useState<PermMap>(defaultPermMap());
  const [role, setRole] = useState<Role>('store');
  const [add, setAdd] = useState('');
  const [busy, run] = useBusy();
  const [dirty, setDirty] = useState(false);

  useEffect(() => {
    if (!d || dirty) return;
    setEmails(d.emails.map((e) => e.toLowerCase()));
    const r: Record<string, Role> = {};
    for (const e of d.emails) r[e.toLowerCase()] = d.roles[e.toLowerCase()] || 'admin';
    setRoles(r);
    const base = defaultPermMap();
    if (d.perms) for (const ro of ROLES) for (const m of MODULES) if (d.perms[ro]?.[m]) base[ro][m] = d.perms[ro][m];
    setPerms(base);
  }, [d, dirty]);

  const toggle = (m: string, a: string, on: boolean) => {
    setDirty(true);
    setPerms((p) => {
      const n: PermMap = JSON.parse(JSON.stringify(p));
      const cur = new Set(n[role][m] || []);
      if (on) {
        cur.add(a);
        if (a !== 'view') cur.add('view');
      } else {
        cur.delete(a);
        if (a === 'view') cur.clear();
      }
      n[role][m] = ACTIONS.filter((x) => cur.has(x));
      return n;
    });
  };

  const save = () =>
    run(async () => {
      try {
        await saveAccess({ emails, roles: Object.fromEntries(emails.map((e) => [e, roles[e] || 'viewer'])), perms }, me);
        setDirty(false);
        toast('✓ Roles & permissions saved — ab Firestore Rules inhe lagu karenge');
      } catch {
        toast('Save nahi hua. Sirf owner / Super Admin badal sakta hai, aur naya firestore.rules publish hona chahiye.');
      }
    });

  return (
    <>
      <PageHeader
        title="Roles & Permissions"
        sub="Kaun kya dekh / bana / badal / mita / approve / transfer / export kar sakta hai. Ye Firestore Rules me bhi lagu hota hai."
        actions={
          canEdit && (
            <button type="button" className="btn primary" onClick={save} disabled={busy || (!dirty && !!d?.perms)}>
              <KeyRound aria-hidden className="ic" /> {busy ? 'Saving…' : 'Save roles'}
            </button>
          )
        }
      />
      {!d?.perms && (
        <Alert tone="amber" icon={ShieldAlert}>
          Abhi purana tareeka chal raha hai: <b>har team member sab kuch kar sakta hai</b>. Roles chun ke &ldquo;Save roles&rdquo; dabao — tabhi permissions lagu hongi. (Pehle naya <code>firestore.rules</code> Firebase me publish karo.)
        </Alert>
      )}
      {!canEdit && (
        <Alert tone="blue" icon={Info}>
          Aap sirf dekh sakte ho. Roles sirf owner ya Super Admin badal sakta hai.
        </Alert>
      )}
      <div className="u-grid span-2-1">
        <Card title={'Team members (' + emails.length + ')'} sub="Owner (rules wala email) hamesha Super Admin hai">
          <table className="u-table">
            <thead>
              <tr>
                <th>Email</th>
                <th>Role</th>
                {canEdit && <th />}
              </tr>
            </thead>
            <tbody>
              {emails.map((e) => (
                <tr key={e}>
                  <td className="u-mono u-sm">{e}</td>
                  <td>
                    {canEdit ? (
                      <select
                        value={roles[e] || 'admin'}
                        onChange={(x) => {
                          setDirty(true);
                          setRoles((r) => ({ ...r, [e]: x.target.value as Role }));
                        }}
                        aria-label={'Role for ' + e}
                      >
                        {ROLES.map((r) => (
                          <option key={r} value={r}>
                            {ROLE_LABEL[r]}
                          </option>
                        ))}
                      </select>
                    ) : (
                      ROLE_LABEL[roles[e] || 'admin']
                    )}
                  </td>
                  {canEdit && (
                    <td>
                      <button
                        type="button"
                        className="u-iconbtn"
                        aria-label={'Remove ' + e}
                        onClick={() => {
                          if (!window.confirm(e + ' ko team se hatana hai?')) return;
                          setDirty(true);
                          setEmails((l) => l.filter((x) => x !== e));
                        }}
                      >
                        <Trash2 aria-hidden />
                      </button>
                    </td>
                  )}
                </tr>
              ))}
            </tbody>
          </table>
          {canEdit && (
            <form
              className="u-row"
              style={{ marginTop: 12, flexWrap: 'nowrap' }}
              onSubmit={(e) => {
                e.preventDefault();
                const v = add.trim().toLowerCase();
                if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v) || emails.includes(v)) return;
                setDirty(true);
                setEmails((l) => [...l, v]);
                setRoles((r) => ({ ...r, [v]: 'viewer' }));
                setAdd('');
              }}
            >
              <input type="email" value={add} onChange={(e) => setAdd(e.target.value)} placeholder="naya.member@gmail.com" aria-label="New member email" />
              <button type="submit" className="btn">
                <UserPlus aria-hidden className="ic" /> Add
              </button>
            </form>
          )}
        </Card>
        <Card title="Roles">
          <ul style={{ listStyle: 'none', margin: 0, padding: 0, display: 'grid', gap: 8 }}>
            {ROLES.map((r) => (
              <li key={r}>
                <b>{ROLE_LABEL[r]}</b> <span className="u-faint u-sm">({emails.filter((e) => (roles[e] || 'admin') === r).length})</span>
                <div className="u-sm u-muted">{ROLE_HINT[r]}</div>
              </li>
            ))}
          </ul>
        </Card>
      </div>

      <Card
        title="Permission matrix"
        sub="Role chuno, phir har module ke liye ijaazat"
        action={
          canEdit && (
            <button
              type="button"
              className="btn sm ghost"
              onClick={() => {
                setDirty(true);
                setPerms((p) => ({ ...p, [role]: defaultPermMap()[role] }));
              }}
            >
              <RotateCcw aria-hidden className="ic" /> Reset this role
            </button>
          )
        }
      >
        <div style={{ marginBottom: 12, overflowX: 'auto' }}>
          <Segmented label="Role" value={role} onChange={setRole} options={ROLES.filter((r) => r !== 'superadmin').map((r) => ({ value: r, label: ROLE_LABEL[r] }))} />
        </div>
        <div className="u-table-wrap" style={{ maxHeight: 'none' }}>
          <table className="u-table perm-table">
            <thead>
              <tr>
                <th>Module</th>
                {ACTIONS.map((a) => (
                  <th key={a}>{ACTION_LABEL[a]}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {MODULES.map((m) => (
                <tr key={m}>
                  <td>{MODULE_LABEL[m]}</td>
                  {ACTIONS.map((a) => (
                    <td key={a}>
                      <input
                        type="checkbox"
                        checked={(perms[role]?.[m] || []).includes(a)}
                        disabled={!canEdit || (role === 'admin' && m === 'roles' && a !== 'view')}
                        onChange={(e) => toggle(m, a, e.target.checked)}
                        aria-label={ROLE_LABEL[role] + ' ' + MODULE_LABEL[m] + ' ' + a}
                      />
                    </td>
                  ))}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Card>
    </>
  );
}

/* ---------------- AUDIT ---------------- */
export function AuditPage() {
  const [rows, setRows] = useState<Audit[] | null>(null);
  const [mod, setMod] = useState('');
  const [err, setErr] = useState('');
  const [tick, setTick] = useState(0);
  useEffect(() => {
    let live = true;
    setRows(null);
    readAudit(500, mod)
      .then((r) => live && setRows(r))
      .catch(() => {
        if (live) {
          setRows([]);
          setErr('Audit log padh nahi paye. (Module filter ke liye Firestore ek index maang sakta hai — browser console me link milega.)');
        }
      });
    return () => {
      live = false;
    };
  }, [mod, tick]);
  const cols: Col<Audit>[] = [
    { key: 'at', label: 'When', value: (r) => r.at, render: (r) => fmtTime(r.at), card: true },
    { key: 'who', label: 'Who', value: (r) => r.byName, render: (r) => (
      <span>
        {r.byName}
        <div className="u-faint u-sm">{r.email}</div>
      </span>
    ), card: true },
    { key: 'mod', label: 'Module', value: (r) => r.module, render: (r) => <Badge plain tone="indigo">{r.module}</Badge> },
    { key: 'act', label: 'Action', value: (r) => r.action, render: (r) => r.action, card: true },
    { key: 'target', label: 'Item', value: (r) => r.targetLabel, render: (r) => <b>{r.targetLabel}</b> },
    { key: 'sum', label: 'Details', value: (r) => r.summary, render: (r) => <span className="u-sm">{r.summary}</span> },
  ];
  return (
    <>
      <PageHeader
        title="Activity & Audit Log"
        sub="Naye modules ka har badlav: kisne, kab, kya. Ye log koi badal ya mita nahi sakta."
        actions={
          <button type="button" className="btn" onClick={() => setTick((t) => t + 1)}>
            <RotateCcw aria-hidden className="ic" /> Refresh
          </button>
        }
      />
      {err && <div className="ferr">{err}</div>}
      {!rows ? (
        <p className="u-muted">Loading…</p>
      ) : (
        <DataTable
          id="audit"
          rows={rows}
          cols={cols}
          exportName="audit-log"
          searchText={(r) => [r.byName, r.email, r.module, r.action, r.targetLabel, r.summary].join(' ')}
          cardTitle={(r) => <b>{r.targetLabel || r.module}</b>}
          initialSort={{ key: 'at', dir: 'desc' }}
          empty={<Empty icon={ScrollText} title="Abhi koi activity nahi" />}
          toolbar={
            <select value={mod} onChange={(e) => setMod(e.target.value)} aria-label="Module">
              <option value="">All modules</option>
              {['drives', 'locations', 'catalog', 'events', 'persons', 'backups', 'stickers', 'roles'].map((m) => (
                <option key={m}>{m}</option>
              ))}
            </select>
          }
        />
      )}
    </>
  );
}

/* ---------------- RECYCLE BIN ---------------- */
export function RecyclePage() {
  const A = useAssets();
  const { me, toast } = useReg();
  const isSuper = A.access?.isOwner || A.access?.role === 'superadmin';
  const drives = useMemo(() => A.allDrives.filter((d) => d.deletedAt), [A.allDrives]);
  const cats = useMemo(() => A.allCatalog.filter((c) => c.deletedAt), [A.allCatalog]);
  const evs = useMemo(() => A.allEvents.filter((e) => e.deletedAt), [A.allEvents]);
  return (
    <>
      <PageHeader title="Recycle Bin" sub="Delete ki hui drives aur catalogue entries yahan rehti hai. Wapas laa sakte ho." />
      <Card title={'Drives (' + drives.length + ')'}>
        {drives.length === 0 ? (
          <Empty icon={Archive} title="Khaali" />
        ) : (
          <ul style={{ listStyle: 'none', margin: 0, padding: 0 }}>
            {drives.map((d) => (
              <li key={d.id} className="u-between" style={{ padding: '10px 0', borderBottom: '1px solid var(--line)' }}>
                <span>
                  <Link href={'/drives/' + d.id} className="u-link">
                    {d.displayName}
                  </Link>{' '}
                  <span className="u-sm u-muted">
                    {d.assetId} · deleted {fmtTime(d.deletedAt)} by {d.deletedBy}
                  </span>
                </span>
                <span className="u-row">
                  <button
                    type="button"
                    className="btn sm"
                    onClick={() =>
                      restoreDrive(d, me).then(
                        () => toast('✓ Restored'),
                        () => toast('Nahi hua'),
                      )
                    }
                  >
                    <RotateCcw aria-hidden className="ic" /> Restore
                  </button>
                  {isSuper && (
                    <button
                      type="button"
                      className="btn sm quiet-danger"
                      onClick={() => {
                        if (!window.confirm(d.displayName + ' hamesha ke liye delete? Mark number phir se use ho sakega. Custody history rahegi.')) return;
                        purgeDrive(d, me, A.slotIds).then(
                          () => toast('✓ Permanently deleted'),
                          () => toast('Nahi hua'),
                        );
                      }}
                    >
                      <Trash2 aria-hidden className="ic" /> Delete forever
                    </button>
                  )}
                </span>
              </li>
            ))}
          </ul>
        )}
      </Card>
      <Card title={'Catalogue entries (' + cats.length + ')'}>
        {cats.length === 0 ? (
          <Empty icon={Archive} title="Khaali" />
        ) : (
          <ul style={{ listStyle: 'none', margin: 0, padding: 0 }}>
            {cats.map((c) => (
              <li key={c.id} className="u-between" style={{ padding: '10px 0', borderBottom: '1px solid var(--line)' }}>
                <span>
                  <b>{[c.project, c.title].filter(Boolean).join(' · ')}</b> <span className="u-sm u-muted">deleted {fmtTime(c.deletedAt)}</span>
                </span>
                <span className="u-row">
                  <button
                    type="button"
                    className="btn sm"
                    onClick={() =>
                      setCatalogDeleted(c, false, me).then(
                        () => toast('✓ Restored'),
                        () => toast('Nahi hua'),
                      )
                    }
                  >
                    <RotateCcw aria-hidden className="ic" /> Restore
                  </button>
                  {isSuper && (
                    <button
                      type="button"
                      className="btn sm quiet-danger"
                      onClick={() => {
                        if (!window.confirm('Hamesha ke liye delete?')) return;
                        purgeCatalog(c, me).then(
                          () => toast('✓ Deleted'),
                          () => toast('Nahi hua'),
                        );
                      }}
                    >
                      <Trash2 aria-hidden className="ic" />
                    </button>
                  )}
                </span>
              </li>
            ))}
          </ul>
        )}
      </Card>
      {A.can('events', 'delete') && (
        <Card title={'Events (' + evs.length + ')'}>
          {evs.length === 0 ? (
            <Empty icon={Archive} title="Khaali" />
          ) : (
            <ul style={{ listStyle: 'none', margin: 0, padding: 0 }}>
              {evs.map((e) => (
                <li key={e.id} className="u-between" style={{ padding: '10px 0', borderBottom: '1px solid var(--line)' }}>
                  <span>
                    <b>{e.type}: {e.title}</b> <span className="u-sm u-muted">{e.date} · deleted {fmtTime(e.deletedAt)}</span>
                  </span>
                  <button type="button" className="btn sm" onClick={() => setEventDeleted(e, false, me).then(() => toast('✓ Restored'), () => toast('Nahi hua'))}>
                    <RotateCcw aria-hidden className="ic" /> Restore
                  </button>
                </li>
              ))}
            </ul>
          )}
        </Card>
      )}
      <p className="hint">
        Purchases / saman ki entries pehle jaisa seedha delete hoti hai (purana tareeka badla nahi gaya).
      </p>
    </>
  );
}
