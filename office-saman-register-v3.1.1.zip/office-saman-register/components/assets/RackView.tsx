'use client';

// Rack ka digital roop: shelf → slot. Har slot me kaunsi drive hai, khaali hai, ya drive bahar (issue) gayi hai.

import Link from 'next/link';
import { motion, useReducedMotion } from 'motion/react';
import { Server } from 'lucide-react';
import { gb, isOut } from '@/lib/assets/model';
import type { Drive, Loc } from '@/lib/assets/types';
import { useAssets } from './store';

export function RackView({ rack, filter, onEmptySlot }: { rack: Loc; filter?: (d: Drive) => boolean; onEmptySlot?: (slot: Loc) => void }) {
  const A = useAssets();
  const reduce = useReducedMotion();
  const kids = (id: string) => A.locs.filter((l) => l.parentId === id);
  const shelves = kids(rack.id).filter((l) => l.kind === 'shelf');
  const byLoc = new Map<string, Drive[]>();
  for (const d of A.drives) {
    if (!d.locationId) continue;
    const arr = byLoc.get(d.locationId) || [];
    arr.push(d);
    byLoc.set(d.locationId, arr);
  }
  const loose = (byLoc.get(rack.id) || []).filter((d) => !filter || filter(d));
  let total = 0;
  let used = 0;

  const slotCell = (s: Loc, i: number) => {
    const d = (byLoc.get(s.id) || [])[0];
    total++;
    if (d) used++;
    const dim = d && filter && !filter(d);
    const cls = !d ? 'empty' : isOut(d.status) ? 'out' : d.status === 'damaged' || d.status === 'lost' ? 'bad' : 'occ';
    const body = (
      <>
        <span className="u-faint">{s.name}</span>
        {d ? (
          <>
            <b>{d.displayName}</b>
            <span>{isOut(d.status) ? 'Out · ' + (d.holder?.name || '') : gb(d.capacityGB)}</span>
          </>
        ) : (
          <span>Empty</span>
        )}
      </>
    );
    return (
      <motion.div
        key={s.id}
        initial={reduce ? false : { opacity: 0, scale: 0.94 }}
        animate={{ opacity: dim ? 0.35 : 1, scale: 1 }}
        transition={{ delay: Math.min(i, 30) * 0.012, duration: 0.2 }}
        style={{ display: 'grid' }}
      >
        {d ? (
          <Link href={'/drives/' + d.id} className={'slot ' + cls} title={d.displayName + ' — ' + (d.holder?.name || 'in store')}>
            {body}
          </Link>
        ) : (
          <button type="button" className={'slot ' + cls} onClick={() => onEmptySlot?.(s)} disabled={!onEmptySlot} title="Empty slot">
            {body}
          </button>
        )}
      </motion.div>
    );
  };

  const shelfBlocks = shelves.map((sh) => {
    const slots = kids(sh.id).filter((l) => l.kind === 'slot');
    const onShelf = (byLoc.get(sh.id) || []).filter((d) => !filter || filter(d));
    return (
      <div className="shelf" key={sh.id}>
        <div className="shelf-h">{sh.name}</div>
        {slots.length > 0 ? <div className="slots">{slots.map(slotCell)}</div> : <p className="u-sm u-faint">Is shelf me abhi slot nahi bane.</p>}
        {onShelf.length > 0 && (
          <p className="u-sm u-muted" style={{ marginTop: 6 }}>
            Shelf pe (bina slot): {onShelf.map((d) => d.displayName).join(', ')}
          </p>
        )}
      </div>
    );
  });

  return (
    <div className="rack-box">
      <div className="rack-title">
        <b>
          <Server aria-hidden className="ic" style={{ verticalAlign: -3, marginRight: 6 }} />
          {rack.name}
        </b>
        <span className="u-sm u-muted">
          {used}/{total} slots used
        </span>
      </div>
      {shelves.length ? shelfBlocks : <p className="u-sm u-faint">Is rack me shelf nahi hai. Locations page se shelf aur slot banao.</p>}
      {loose.length > 0 && <p className="u-sm u-muted">Rack pe (bina shelf): {loose.map((d) => d.displayName).join(', ')}</p>}
    </div>
  );
}

export function RackLegend() {
  return (
    <div className="legend">
      <span>
        <i style={{ background: 'var(--accent-soft)', borderColor: 'rgba(var(--accent-rgb),.45)' }} />
        In slot
      </span>
      <span>
        <i style={{ background: 'var(--warn-soft)', borderColor: 'var(--warn)' }} />
        Issued out
      </span>
      <span>
        <i style={{ background: 'var(--danger-soft)', borderColor: 'var(--danger)' }} />
        Damaged / lost
      </span>
      <span>
        <i style={{ borderStyle: 'dashed' }} />
        Empty
      </span>
    </div>
  );
}
