'use client';

import Link from 'next/link';
import { useRouter, useSearchParams } from 'next/navigation';
import { useEffect, useMemo, useState } from 'react';
import { Database, FolderOpen, HardDrive, Pencil, Plus, ShieldCheck, Trash2 } from 'lucide-react';
import { setCatalogDeleted } from '@/lib/assets/db';
import { copyState, gb, isOut, locLabel, whereIs } from '@/lib/assets/model';
import { CATALOG_CATEGORIES, PRIORITIES, type CatalogEntry } from '@/lib/assets/types';
import { distinct } from '@/lib/calc';
import { useReg } from '../context';
import { DataTable, type Col } from '../ui/DataTable';
import { Badge, Card, Empty, Modal, PageHeader, Stat, fmtDate, fmtTime } from '../ui';
import { CatalogForm } from './CatalogForm';
import { useAssets } from './store';

export function CatalogPage() {
  const A = useAssets();
  const { me, toast } = useReg();
  const router = useRouter();
  const sp = useSearchParams();
  const [form, setForm] = useState<{ entry: CatalogEntry | null } | null>(null);
  const [view, setView] = useState<CatalogEntry | null>(null);
  const [cat, setCat] = useState('');
  const [year, setYear] = useState('');
  const [prio, setPrio] = useState('');
  const [bk, setBk] = useState('');

  useEffect(() => {
    if (sp.get('new') === '1' && A.can('catalog', 'create')) setForm({ entry: null });
    const o = sp.get('open');
    if (o) {
      const e = A.catalog.find((c) => c.id === o);
      if (e) setView(e);
    }
  }, [sp, A]);

  const rows = useMemo(
    () =>
      A.catalog.filter(
        (c) => (!cat || c.category === cat) && (!year || c.year === year) && (!prio || c.priority === prio) && (!bk || copyState(c, A.backups).state === bk),
      ),
    [A.catalog, A.backups, cat, year, prio, bk],
  );
  const years = distinct(A.catalog.map((c) => c.year)).sort().reverse();
  const totalGB = A.catalog.reduce((s, c) => s + c.sizeGB, 0);
  const single = A.catalog.filter((c) => copyState(c, A.backups).state === 'none').length;
  const verified = A.catalog.filter((c) => copyState(c, A.backups).state === 'verified').length;

  const driveCell = (c: CatalogEntry) => {
    const d = A.driveMap.get(c.driveId);
    if (!d) return <span className="u-muted">—</span>;
    return (
      <Link href={'/drives/' + d.id} className="u-link" onClick={(e) => e.stopPropagation()}>
        {d.displayName}
      </Link>
    );
  };
  const whereCell = (c: CatalogEntry) => {
    const d = A.driveMap.get(c.driveId);
    if (!d) return '—';
    return whereIs(d, A.locMap);
  };
  const bkBadge = (c: CatalogEntry) => {
    const s = copyState(c, A.backups);
    return (
      <Badge tone={s.state === 'verified' ? 'green' : s.state === 'none' ? 'red' : 'amber'}>
        {s.state === 'none' ? 'Single copy' : s.state === 'verified' ? s.verified + ' verified' : s.state === 'outdated' ? 'Outdated' : s.copies + ' unverified'}
      </Badge>
    );
  };

  const cols: Col<CatalogEntry>[] = [
    {
      key: 'title',
      label: 'Project / title',
      value: (c) => c.project + ' ' + c.title,
      render: (c) => (
        <div>
          <b>{c.project || c.title}</b>
          {c.project && c.title && <div className="u-sm u-muted">{c.title}</div>}
        </div>
      ),
    },
    { key: 'ep', label: 'Episode', value: (c) => c.episode, render: (c) => c.episode || '—', card: true },
    { key: 'event', label: 'Event', value: (c) => c.eventName, render: (c) => [c.eventName, c.eventDate && fmtDate(c.eventDate)].filter(Boolean).join(' · ') || '—', hidden: true },
    { key: 'year', label: 'Year', value: (c) => c.year, render: (c) => c.year || '—' },
    { key: 'cat', label: 'Category', value: (c) => c.category, render: (c) => c.category, card: true },
    { key: 'drive', label: 'Drive', value: (c) => A.driveMap.get(c.driveId)?.markNo || 0, render: driveCell, card: true },
    { key: 'where', label: 'Drive is', value: whereCell, render: whereCell, card: true },
    { key: 'path', label: 'Folder path', value: (c) => c.folderPath, render: (c) => <span className="u-mono u-sm">{c.folderPath || '—'}</span> },
    { key: 'size', label: 'Size', num: true, value: (c) => c.sizeGB, render: (c) => (c.sizeGB ? gb(c.sizeGB) : '—') },
    { key: 'files', label: 'Files', num: true, value: (c) => c.fileCount, render: (c) => (c.fileCount ? c.fileCount.toLocaleString('en-IN') : '—'), hidden: true },
    { key: 'owner', label: 'Owner', value: (c) => c.owner, render: (c) => c.owner || '—', hidden: true },
    { key: 'dept', label: 'Department', value: (c) => c.dept, render: (c) => c.dept || '—', hidden: true },
    { key: 'prio', label: 'Priority', value: (c) => PRIORITIES.indexOf(c.priority), render: (c) => <Badge tone={c.priority === 'Critical' ? 'red' : c.priority === 'High' ? 'amber' : 'gray'} plain>{c.priority}</Badge> },
    { key: 'bk', label: 'Backup', value: (c) => copyState(c, A.backups).copies, render: bkBadge, card: true },
    { key: 'tags', label: 'Tags', value: (c) => c.tags.join(', '), render: (c) => c.tags.join(', ') || '—', hidden: true },
  ];

  return (
    <>
      <PageHeader
        title="Digital Data Catalogue"
        sub="Kaunsi drive me kaunsa project, episode, event ya file hai — aur uski backup copies."
        actions={
          A.can('catalog', 'create') && (
            <button type="button" className="btn primary" onClick={() => setForm({ entry: null })} disabled={!A.drives.length}>
              <Plus aria-hidden className="ic" /> Add data
            </button>
          )
        }
      />
      <div className="u-grid c4">
        <Stat index={0} label="Catalogue entries" value={A.catalog.length} icon={Database} />
        <Stat index={1} label="Data size (catalogued)" value={totalGB} format={gb} icon={FolderOpen} tone="violet" />
        <Stat index={2} label="Verified backups" value={verified} icon={ShieldCheck} tone="green" onClick={() => setBk('verified')} />
        <Stat index={3} label="Single copy (risk)" value={single} icon={HardDrive} tone="red" onClick={() => setBk('none')} />
      </div>

      {A.catalog.length === 0 ? (
        <Card>
          <Empty
            icon={Database}
            title="Catalogue khaali hai"
            action={
              A.drives.length === 0 ? (
                <Link href="/drives?new=1" className="btn primary">
                  Pehle drive register karo
                </Link>
              ) : (
                A.can('catalog', 'create') && (
                  <button type="button" className="btn primary" onClick={() => setForm({ entry: null })}>
                    <Plus aria-hidden className="ic" /> Pehla data likho
                  </button>
                )
              )
            }
          >
            Har drive me kya rakha hai likho. Files ka poora index drive ke page pe &ldquo;Import scan&rdquo; se aata hai.
          </Empty>
        </Card>
      ) : (
        <DataTable
          id="catalog"
          rows={rows}
          cols={cols}
          exportName="data-catalogue"
          canExport={A.can('catalog', 'export')}
          searchText={(c) => [c.project, c.title, c.episode, c.eventName, c.year, c.category, c.folderPath, c.owner, c.dept, c.tags.join(' '), c.description, A.driveMap.get(c.driveId)?.displayName].join(' ')}
          onRow={setView}
          cardTitle={(c) => <b>{[c.project, c.title].filter(Boolean).join(' · ')}</b>}
          toolbar={
            <>
              <select value={cat} onChange={(e) => setCat(e.target.value)} aria-label="Category">
                <option value="">All categories</option>
                {distinct([...CATALOG_CATEGORIES, ...A.catalog.map((c) => c.category)]).map((c) => (
                  <option key={c}>{c}</option>
                ))}
              </select>
              {years.length > 0 && (
                <select value={year} onChange={(e) => setYear(e.target.value)} aria-label="Year">
                  <option value="">All years</option>
                  {years.map((y) => (
                    <option key={y}>{y}</option>
                  ))}
                </select>
              )}
              <select value={prio} onChange={(e) => setPrio(e.target.value)} aria-label="Priority">
                <option value="">Any priority</option>
                {PRIORITIES.map((p) => (
                  <option key={p}>{p}</option>
                ))}
              </select>
              <select value={bk} onChange={(e) => setBk(e.target.value)} aria-label="Backup state">
                <option value="">Any backup</option>
                <option value="none">Single copy</option>
                <option value="unverified">Copied, not verified</option>
                <option value="verified">Verified</option>
                <option value="outdated">Outdated</option>
              </select>
            </>
          }
        />
      )}

      {view && (
        <Modal
          open
          onClose={() => {
            setView(null);
            if (sp.get('open')) router.replace('/catalog');
          }}
          title={[view.project, view.title].filter(Boolean).join(' · ')}
          sub={view.category + (view.year ? ' · ' + view.year : '')}
          foot={
            <>
              {A.can('catalog', 'delete') && (
                <button
                  type="button"
                  className="btn quiet-danger"
                  onClick={async () => {
                    if (!window.confirm('Ye entry recycle bin me bhejni hai?')) return;
                    await setCatalogDeleted(view, true, me).then(
                      () => toast('✓ Moved to recycle bin'),
                      () => toast('Nahi hua'),
                    );
                    setView(null);
                  }}
                >
                  <Trash2 aria-hidden className="ic" /> Delete
                </button>
              )}
              {A.can('backups', 'create') && (
                <Link className="btn" href={'/backups?catalog=' + view.id}>
                  <ShieldCheck aria-hidden className="ic" /> Backup
                </Link>
              )}
              {A.can('catalog', 'edit') && (
                <button
                  type="button"
                  className="btn primary"
                  onClick={() => {
                    setForm({ entry: view });
                    setView(null);
                  }}
                >
                  <Pencil aria-hidden className="ic" /> Edit
                </button>
              )}
            </>
          }
        >
          <CatalogDetail c={view} />
        </Modal>
      )}
      <CatalogForm open={!!form} onClose={() => setForm(null)} entry={form?.entry || null} />
    </>
  );
}

function CatalogDetail({ c }: { c: CatalogEntry }) {
  const A = useAssets();
  const d = A.driveMap.get(c.driveId);
  const copies = A.backups.filter((b) => b.catalogId === c.id);
  const s = copyState(c, A.backups);
  return (
    <div className="u-stack">
      <Card pad>
        <div className="u-between">
          <div>
            <div className="u-sm u-muted">Drive</div>
            {d ? (
              <Link href={'/drives/' + d.id} className="u-link" style={{ fontSize: '1.1rem' }}>
                {d.displayName} · {d.assetId}
              </Link>
            ) : (
              '—'
            )}
            <div className="u-sm">{d ? whereIs(d, A.locMap) : ''}</div>
          </div>
          <Badge tone={s.state === 'verified' ? 'green' : s.state === 'none' ? 'red' : 'amber'}>{s.state === 'none' ? 'Single copy' : s.copies + ' backup copy'}</Badge>
        </div>
      </Card>
      <dl className="u-kv">
        {(
          [
            ['Folder path', c.folderPath],
            ['Episode', c.episode],
            ['Event', c.eventName],
            ['Event date', fmtDate(c.eventDate)],
            ['Department', c.dept],
            ['Owner', c.owner],
            ['File type', c.fileType],
            ['Size', c.sizeGB ? gb(c.sizeGB) : ''],
            ['File count', c.fileCount ? c.fileCount.toLocaleString('en-IN') : ''],
            ['Priority', c.priority],
            ['Tags', c.tags.join(', ')],
            ['Added', fmtTime(c.createdAt) + (c.createdByName ? ' · ' + c.createdByName : '')],
            ['Updated', fmtTime(c.updatedAt) + (c.updatedByName ? ' · ' + c.updatedByName : '')],
            ...Object.entries(c.custom),
          ] as [string, string][]
        )
          .filter(([, x]) => x)
          .map(([k, x]) => (
            <div key={k}>
              <dt>{k}</dt>
              <dd>{x}</dd>
            </div>
          ))}
      </dl>
      {c.description && <p>{c.description}</p>}
      {copies.length > 0 && (
        <div>
          <div className="flabel">Backup copies</div>
          <ul style={{ margin: '6px 0 0', paddingLeft: 18 }}>
            {copies.map((b) => (
              <li key={b.id}>
                {A.driveMap.get(b.copyDriveId)?.displayName || '—'} {b.copyPath && <span className="u-mono u-sm">{b.copyPath}</span>} — {b.status}
              </li>
            ))}
          </ul>
        </div>
      )}
    </div>
  );
}
