'use client';

// Naye modules ka live data: drives, locations, catalogue, backups, transfers + role/permission.
// Sirf wahi collection subscribe hoti hai jo user ko dekhne ki ijaazat hai.

import { createContext, useContext, useEffect, useMemo, useState, type ReactNode } from 'react';
import {
  subscribeDepts,
  subscribeEvents,
  subscribeNaming,
  subscribePersons,
  subscribeBackups,
  subscribeCatalog,
  subscribeDemandCount,
  subscribeDrives,
  subscribeLocs,
  subscribeTransfers,
  type AccessDoc,
} from '@/lib/assets/db';
import { normalizeNaming } from '@/lib/assets/model';
import type { AshramEvent, Backup, CatalogEntry, Department, Drive, Loc, NamingSeries, Person, SeriesKey, Transfer } from '@/lib/assets/types';
import { can as canDo, type Access, type Action, type Module } from '@/lib/perm';
import type { Me } from '@/lib/types';

export type Assets = {
  access: Access | null;
  accessDoc: AccessDoc | null;
  can: (m: Module, a: Action) => boolean;
  drives: Drive[];
  allDrives: Drive[];
  driveMap: Map<string, Drive>;
  locs: Loc[];
  locMap: Map<string, Loc>;
  slotIds: Set<string>;
  catalog: CatalogEntry[];
  allCatalog: CatalogEntry[];
  backups: Backup[];
  transfers: Transfer[];
  pendingDemands: number;
  persons: Person[];
  depts: Department[];
  events: AshramEvent[];
  allEvents: AshramEvent[];
  naming: Record<SeriesKey, NamingSeries>;
  loaded: { drives: boolean; locs: boolean; catalog: boolean; backups: boolean; events: boolean };
};

const Ctx = createContext<Assets | null>(null);

export function useAssets(): Assets {
  const a = useContext(Ctx);
  if (!a) throw new Error('AssetsProvider missing');
  return a;
}

export function resolveAccess(me: Me | null, d: AccessDoc | null): Access | null {
  if (!me || !d) return null;
  const email = me.email.toLowerCase();
  const listed = d.emails.map((e) => e.toLowerCase()).includes(email);
  // Rules ne config/access padhne diya aur email team me nahi hai = ye owner hai.
  // NEXT_PUBLIC_OWNER_EMAIL (optional) se bhi owner pehchana jata hai, agar owner ka email Team list me bhi ho.
  const ownerEnv = (process.env.NEXT_PUBLIC_OWNER_EMAIL || '').trim().toLowerCase();
  const isOwner = !listed || (!!ownerEnv && ownerEnv === email);
  const role = isOwner ? 'superadmin' : d.roles[email] || 'admin';
  return { isOwner, role, perms: d.perms };
}

export function AssetsProvider({ me, accessDoc, children }: { me: Me | null; accessDoc: AccessDoc | null; children: ReactNode }) {
  const access = useMemo(() => resolveAccess(me, accessDoc), [me, accessDoc]);
  const can = useMemo(() => (m: Module, a: Action) => canDo(access, m, a), [access]);

  const [allDrives, setDrives] = useState<Drive[]>([]);
  const [locs, setLocs] = useState<Loc[]>([]);
  const [allCatalog, setCatalog] = useState<CatalogEntry[]>([]);
  const [backups, setBackups] = useState<Backup[]>([]);
  const [transfers, setTransfers] = useState<Transfer[]>([]);
  const [pendingDemands, setPending] = useState(-1);
  const [loaded, setLoaded] = useState({ drives: false, locs: false, catalog: false, backups: false, events: false });
  const [persons, setPersons] = useState<Person[]>([]);
  const [depts, setDepts] = useState<Department[]>([]);
  const [allEvents, setEvents] = useState<AshramEvent[]>([]);
  const [naming, setNaming] = useState<Record<SeriesKey, NamingSeries>>(() => normalizeNaming(null));

  const vDrives = can('drives', 'view');
  const vLocs = can('locations', 'view') || vDrives;
  const vCat = can('catalog', 'view');
  const vBak = can('backups', 'view');
  const vDem = can('demands', 'view');
  const vPer = can('persons', 'view');
  const vEv = can('events', 'view');
  const uid = me?.uid || '';

  useEffect(() => {
    if (!uid || !access || !vDrives) return;
    const a = subscribeDrives(
      (r) => {
        setDrives(r);
        setLoaded((l) => ({ ...l, drives: true }));
      },
      () => setLoaded((l) => ({ ...l, drives: true })),
    );
    const b = subscribeTransfers(setTransfers, () => {});
    return () => {
      a();
      b();
    };
  }, [uid, !!access, vDrives]); // eslint-disable-line react-hooks/exhaustive-deps

  useEffect(() => {
    if (!uid || !access || !vLocs) return;
    return subscribeLocs(
      (r) => {
        setLocs(r);
        setLoaded((l) => ({ ...l, locs: true }));
      },
      () => setLoaded((l) => ({ ...l, locs: true })),
    );
  }, [uid, !!access, vLocs]); // eslint-disable-line react-hooks/exhaustive-deps

  useEffect(() => {
    if (!uid || !access || !vCat) return;
    return subscribeCatalog(
      (r) => {
        setCatalog(r);
        setLoaded((l) => ({ ...l, catalog: true }));
      },
      () => setLoaded((l) => ({ ...l, catalog: true })),
    );
  }, [uid, !!access, vCat]); // eslint-disable-line react-hooks/exhaustive-deps

  useEffect(() => {
    if (!uid || !access || !vBak) return;
    return subscribeBackups(
      (r) => {
        setBackups(r);
        setLoaded((l) => ({ ...l, backups: true }));
      },
      () => setLoaded((l) => ({ ...l, backups: true })),
    );
  }, [uid, !!access, vBak]); // eslint-disable-line react-hooks/exhaustive-deps

  useEffect(() => {
    if (!uid || !access) return;
    return subscribeNaming(setNaming);
  }, [uid, !!access]); // eslint-disable-line react-hooks/exhaustive-deps

  useEffect(() => {
    if (!uid || !access || !vPer) return;
    const a = subscribePersons(setPersons, () => {});
    const b = subscribeDepts(setDepts, () => {});
    return () => {
      a();
      b();
    };
  }, [uid, !!access, vPer]); // eslint-disable-line react-hooks/exhaustive-deps

  useEffect(() => {
    if (!uid || !access || !vEv) return;
    return subscribeEvents(
      (r) => {
        setEvents(r);
        setLoaded((l) => ({ ...l, events: true }));
      },
      () => setLoaded((l) => ({ ...l, events: true })),
    );
  }, [uid, !!access, vEv]); // eslint-disable-line react-hooks/exhaustive-deps

  useEffect(() => {
    if (!uid || !access || !vDem) return;
    return subscribeDemandCount(setPending);
  }, [uid, !!access, vDem]); // eslint-disable-line react-hooks/exhaustive-deps

  const value = useMemo<Assets>(() => {
    const drives = allDrives.filter((d) => !d.deletedAt).sort((a, b) => a.markNo - b.markNo);
    const liveLocs = locs.filter((l) => !l.deletedAt).sort((a, b) => a.order - b.order || a.name.localeCompare(b.name, 'en', { numeric: true }));
    const locMap = new Map(liveLocs.map((l) => [l.id, l]));
    const slotIds = new Set(liveLocs.filter((l) => l.kind === 'slot').map((l) => l.id));
    return {
      access,
      accessDoc,
      can,
      drives,
      allDrives,
      driveMap: new Map(allDrives.map((d) => [d.id, d])),
      locs: liveLocs,
      locMap,
      slotIds,
      catalog: allCatalog.filter((c) => !c.deletedAt),
      allCatalog,
      backups: backups.filter((b) => !b.deletedAt),
      transfers,
      pendingDemands,
      persons: persons.slice().sort((a, b) => a.name.localeCompare(b.name)),
      depts: depts.slice().sort((a, b) => a.name.localeCompare(b.name)),
      events: allEvents.filter((e) => !e.deletedAt).sort((a, b) => (b.date || '').localeCompare(a.date || '')),
      allEvents,
      naming,
      loaded: {
        events: loaded.events || !vEv,
        drives: loaded.drives || !vDrives,
        locs: loaded.locs || !vLocs,
        catalog: loaded.catalog || !vCat,
        backups: loaded.backups || !vBak,
      },
    };
  }, [access, accessDoc, can, allDrives, locs, allCatalog, backups, transfers, pendingDemands, loaded, vDrives, vLocs, vCat, vBak, persons, depts, allEvents, naming, vEv]);

  return <Ctx.Provider value={value}>{children}</Ctx.Provider>;
}
