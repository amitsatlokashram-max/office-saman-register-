'use client';

import { useEffect, useState } from 'react';
import { Database, Plus, Trash2 } from 'lucide-react';
import { saveCatalog, type CatalogInput } from '@/lib/assets/db';
import { CATALOG_CATEGORIES, DATA_STATUS, PRIORITIES, type CatalogEntry, type Priority } from '@/lib/assets/types';
import { num } from '@/lib/calc';
import { useReg } from '../context';
import { Field, Modal, useBusy } from '../ui';
import { useAssets } from './store';

const blank = (driveId: string): CatalogInput => ({
  driveId,
  eventId: '',
  recordingDate: '',
  status: 'Registered',
  project: '',
  title: '',
  episode: '',
  eventName: '',
  eventDate: '',
  year: String(new Date().getFullYear()),
  dept: '',
  category: 'Raw Footage',
  fileType: '',
  folderPath: '',
  sizeGB: 0,
  fileCount: 0,
  owner: '',
  priority: 'Normal',
  tags: [],
  description: '',
  custom: {},
});

export function CatalogForm({
  open,
  onClose,
  entry,
  driveId = '',
  preset,
}: {
  open: boolean;
  onClose: () => void;
  entry: CatalogEntry | null;
  driveId?: string;
  preset?: Partial<CatalogInput>;
}) {
  const A = useAssets();
  const { me, toast } = useReg();
  const [v, setV] = useState<CatalogInput>(blank(driveId));
  const [tags, setTags] = useState('');
  const [size, setSize] = useState('');
  const [count, setCount] = useState('');
  const [custom, setCustom] = useState<[string, string][]>([]);
  const [err, setErr] = useState('');
  const [busy, run] = useBusy();

  useEffect(() => {
    if (!open) return;
    const base: CatalogInput = entry ? { ...entry } : { ...blank(driveId), ...preset };
    setV(base);
    setTags(base.tags.join(', '));
    setSize(base.sizeGB ? String(base.sizeGB) : '');
    setCount(base.fileCount ? String(base.fileCount) : '');
    setCustom(Object.entries(base.custom));
    setErr('');
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [open, entry?.id, driveId]);

  const set = <K extends keyof CatalogInput>(k: K, val: CatalogInput[K]) => setV((p) => ({ ...p, [k]: val }));

  const submit = () =>
    run(async () => {
      setErr('');
      if (!v.driveId) return setErr('Kis drive me hai, chuno.');
      if (!v.title.trim() && !v.project.trim()) return setErr('Project ya title likho.');
      const data: CatalogInput = {
        ...v,
        project: v.project.trim(),
        title: v.title.trim(),
        folderPath: v.folderPath.trim().replace(/\\/g, '/'),
        sizeGB: Math.max(0, num(size)),
        fileCount: Math.max(0, Math.round(num(count))),
        tags: tags.split(',').map((t) => t.trim()).filter(Boolean).slice(0, 30),
        custom: Object.fromEntries(custom.filter(([k]) => k.trim()).map(([k, x]) => [k.trim(), x.trim()])),
      };
      try {
        await saveCatalog(data, me, entry?.id);
        toast('✓ Catalogue saved');
        onClose();
      } catch {
        setErr('Save nahi hua. Ijaazat ya internet check karo.');
      }
    });

  return (
    <Modal
      open={open}
      onClose={onClose}
      size="lg"
      title={entry ? 'Edit catalogue entry' : 'Add data to catalogue'}
      sub="Drive ke andar kya data hai — taaki baad me project / episode / event se dhoondh sako."
      onSubmit={submit}
      foot={
        <>
          <button type="button" className="btn" onClick={onClose}>
            Cancel
          </button>
          <button type="submit" className="btn primary" disabled={busy}>
            <Database aria-hidden className="ic" /> {busy ? 'Saving…' : 'Save'}
          </button>
        </>
      }
    >
      {err && <div className="ferr">{err}</div>}
      <div className="fgrid g3">
        <Field label="Drive" span>
          <select value={v.driveId} onChange={(e) => set('driveId', e.target.value)} required>
            <option value="">— Choose drive —</option>
            {A.drives.map((d) => (
              <option key={d.id} value={d.id}>
                {d.displayName} · {d.assetId} {d.brand ? '· ' + d.brand : ''}
              </option>
            ))}
          </select>
        </Field>
        <Field label="Project">
          <input value={v.project} onChange={(e) => set('project', e.target.value)} list="dl-projects" maxLength={200} />
        </Field>
        <Field label="Data title">
          <input value={v.title} onChange={(e) => set('title', e.target.value)} maxLength={300} />
        </Field>
        <Field label="Category">
          <select value={v.category} onChange={(e) => set('category', e.target.value)}>
            {CATALOG_CATEGORIES.map((c) => (
              <option key={c}>{c}</option>
            ))}
            {!CATALOG_CATEGORIES.includes(v.category as (typeof CATALOG_CATEGORIES)[number]) && <option>{v.category}</option>}
          </select>
        </Field>
        <Field label="Episode no.">
          <input value={v.episode} onChange={(e) => set('episode', e.target.value)} maxLength={40} />
        </Field>
        <Field label="Event (Panchayat / Satsang…)" span hint={A.can('events', 'create') ? 'List me na ho to pehle Events page pe event banao' : undefined}>
          <select
            value={v.eventId}
            onChange={(e) => {
              const ev = A.events.find((x) => x.id === e.target.value);
              setV((p) => ({ ...p, eventId: e.target.value, ...(ev ? { eventName: ev.title, eventDate: ev.date, year: ev.date.slice(0, 4) || p.year, recordingDate: p.recordingDate || ev.recordingDate || ev.date } : {}) }));
            }}
          >
            <option value="">— No linked event —</option>
            {A.events.map((ev) => (
              <option key={ev.id} value={ev.id}>
                {ev.date} · {ev.type}: {ev.title}
              </option>
            ))}
          </select>
        </Field>
        <Field label="Event name">
          <input value={v.eventName} onChange={(e) => set('eventName', e.target.value)} maxLength={200} />
        </Field>
        <Field label="Recording date">
          <input type="date" value={v.recordingDate} onChange={(e) => set('recordingDate', e.target.value)} />
        </Field>
        <Field label="Status">
          <select value={v.status} onChange={(e) => set('status', e.target.value)}>
            {DATA_STATUS.map((x) => (
              <option key={x}>{x}</option>
            ))}
          </select>
        </Field>
        <Field label="Event date">
          <input type="date" value={v.eventDate} onChange={(e) => setV((p) => ({ ...p, eventDate: e.target.value, year: e.target.value ? e.target.value.slice(0, 4) : p.year }))} />
        </Field>
        <Field label="Year">
          <input value={v.year} onChange={(e) => set('year', e.target.value)} maxLength={4} inputMode="numeric" />
        </Field>
        <Field label="Department">
          <input value={v.dept} onChange={(e) => set('dept', e.target.value)} list="dl-depts" maxLength={60} />
        </Field>
        <Field label="Zimmedar / data owner">
          <input value={v.owner} onChange={(e) => set('owner', e.target.value)} list="dl-allpeople" maxLength={80} />
        </Field>
        <Field label="Folder path (drive ke andar)" span hint="Jaise: 2026/Satsang/Ep-120/RAW">
          <input value={v.folderPath} onChange={(e) => set('folderPath', e.target.value)} maxLength={1000} />
        </Field>
        <Field label="File type">
          <input value={v.fileType} onChange={(e) => set('fileType', e.target.value)} placeholder="MP4, MOV, PRPROJ…" maxLength={60} />
        </Field>
        <Field label="Size (GB)">
          <input type="number" min={0} step="any" value={size} onChange={(e) => setSize(e.target.value)} />
        </Field>
        <Field label="File count">
          <input type="number" min={0} value={count} onChange={(e) => setCount(e.target.value)} />
        </Field>
        <Field label="Priority" hint="Critical / High data ka backup na ho to alert aata hai">
          <select value={v.priority} onChange={(e) => set('priority', e.target.value as Priority)}>
            {PRIORITIES.map((p) => (
              <option key={p}>{p}</option>
            ))}
          </select>
        </Field>
        <Field label="Tags (comma se alag)" span>
          <input value={tags} onChange={(e) => setTags(e.target.value)} placeholder="satsang, live, 4k" />
        </Field>
        <Field label="Description" span>
          <textarea value={v.description} onChange={(e) => set('description', e.target.value)} rows={2} maxLength={3000} />
        </Field>
      </div>
      <div className="fsec">
        <span className="flabel">Custom metadata</span>
        {custom.map(([k, x], i) => (
          <div className="u-row" key={i} style={{ flexWrap: 'nowrap' }}>
            <input placeholder="Field" value={k} onChange={(e) => setCustom(custom.map((c, j) => (j === i ? [e.target.value, c[1]] : c)))} />
            <input placeholder="Value" value={x} onChange={(e) => setCustom(custom.map((c, j) => (j === i ? [c[0], e.target.value] : c)))} />
            <button type="button" className="u-iconbtn" aria-label="Remove" onClick={() => setCustom(custom.filter((_, j) => j !== i))}>
              <Trash2 aria-hidden />
            </button>
          </div>
        ))}
        <div>
          <button type="button" className="btn sm" onClick={() => setCustom([...custom, ['', '']])} disabled={custom.length >= 20}>
            <Plus aria-hidden className="ic" /> Add field
          </button>
        </div>
      </div>
    </Modal>
  );
}
