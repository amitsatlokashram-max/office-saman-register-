'use client';

// Phone camera se QR / barcode scan: drive kholo, issue / return karo, ya inventory verification (kaunsi drive rack me mili, kaunsi nahi).

import { useRouter } from 'next/navigation';
import { AnimatePresence, motion } from 'motion/react';
import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import jsQR from 'jsqr';
import { Camera, CameraOff, CheckCircle2, ClipboardCheck, Keyboard, ScanLine, XCircle } from 'lucide-react';
import { audit } from '@/lib/assets/db';
import { isOut, locLabel } from '@/lib/assets/model';
import { resolveCode } from '@/lib/assets/resolve';
import { DRIVE_STATUS_LABEL, type Drive, type TransferKind } from '@/lib/assets/types';
import { useReg } from '../context';
import { Alert, Badge, Card, Field, PageHeader, Segmented } from '../ui';
import { MoveDriveModal } from './Custody';
import { LocSelect } from './pickers';
import { useAssets } from './store';

type Mode = 'open' | 'issue' | 'return' | 'verify';

type BD = { detect: (src: CanvasImageSource) => Promise<{ rawValue: string }[]> };
declare global {
  interface Window {
    BarcodeDetector?: new (o?: { formats: string[] }) => BD;
  }
}

export function ScanPage() {
  const A = useAssets();
  const { me, toast } = useReg();
  const router = useRouter();
  const [mode, setMode] = useState<Mode>('open');
  const [on, setOn] = useState(false);
  const [camErr, setCamErr] = useState('');
  const [manual, setManual] = useState('');
  const [last, setLast] = useState<{ code: string; drive?: Drive; at: number } | null>(null);
  const [move, setMove] = useState<{ d: Drive; k: TransferKind } | null>(null);
  const [scope, setScope] = useState('');
  const [seen, setSeen] = useState<Set<string>>(new Set());
  const [unknown, setUnknown] = useState<string[]>([]);
  const video = useRef<HTMLVideoElement>(null);
  const stream = useRef<MediaStream | null>(null);
  const raf = useRef(0);
  const lastCode = useRef({ code: '', t: 0 });
  const modeRef = useRef(mode);
  modeRef.current = mode;
  const drivesRef = useRef(A.allDrives);
  drivesRef.current = A.allDrives;

  const handle = useCallback(
    (raw: string) => {
      const now = Date.now();
      if (raw === lastCode.current.code && now - lastCode.current.t < 2500) return;
      lastCode.current = { code: raw, t: now };
      const d = resolveCode(raw, drivesRef.current);
      setLast({ code: raw, drive: d, at: now });
      try {
        navigator.vibrate?.(d ? 60 : [40, 60, 40]);
      } catch {
        /* ignore */
      }
      if (!d) {
        if (modeRef.current === 'verify') setUnknown((u) => (u.includes(raw) ? u : [...u, raw]));
        return;
      }
      const m = modeRef.current;
      if (m === 'open') {
        stop();
        router.push('/drives/' + d.id);
      } else if (m === 'issue' || m === 'return') {
        stop();
        setMove({ d, k: m });
      } else setSeen((s) => new Set(s).add(d.id));
    },
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [router],
  );

  const stop = useCallback(() => {
    cancelAnimationFrame(raf.current);
    stream.current?.getTracks().forEach((t) => t.stop());
    stream.current = null;
    setOn(false);
  }, []);

  const start = async () => {
    setCamErr('');
    if (!navigator.mediaDevices?.getUserMedia) return setCamErr('Is browser me camera nahi chalta. Code neeche haath se likho.');
    try {
      const s = await navigator.mediaDevices.getUserMedia({ video: { facingMode: { ideal: 'environment' } }, audio: false });
      stream.current = s;
      setOn(true);
      requestAnimationFrame(() => {
        const v = video.current;
        if (!v) return;
        v.srcObject = s;
        v.play().catch(() => {});
        loop();
      });
    } catch {
      setCamErr('Camera ki ijaazat nahi mili. Browser settings me camera allow karo (HTTPS zaroori hai).');
    }
  };

  const loop = () => {
    const v = video.current;
    const det = typeof window !== 'undefined' && window.BarcodeDetector ? new window.BarcodeDetector({ formats: ['qr_code', 'code_128'] }) : null;
    const c = document.createElement('canvas');
    const ctx = c.getContext('2d', { willReadFrequently: true });
    let busy = false;
    const tick = async () => {
      if (!stream.current || !v) return;
      if (!busy && v.readyState >= 2 && v.videoWidth) {
        busy = true;
        try {
          if (det) {
            const r = await det.detect(v);
            if (r[0]?.rawValue) handle(r[0].rawValue);
          } else if (ctx) {
            const w = Math.min(640, v.videoWidth);
            const h = Math.round((v.videoHeight / v.videoWidth) * w);
            c.width = w;
            c.height = h;
            ctx.drawImage(v, 0, 0, w, h);
            const img = ctx.getImageData(0, 0, w, h);
            const r = jsQR(img.data, w, h, { inversionAttempts: 'dontInvert' });
            if (r?.data) handle(r.data);
          }
        } catch {
          /* agla frame */
        }
        busy = false;
      }
      raf.current = requestAnimationFrame(tick);
    };
    raf.current = requestAnimationFrame(tick);
  };

  useEffect(() => stop, [stop]);

  const expected = useMemo(() => {
    if (mode !== 'verify') return [];
    const scopeLabel = scope ? locLabel(A.locMap, scope) : '';
    return A.drives.filter((d) => d.status === 'in_store' && (!scope || d.locationId === scope || locLabel(A.locMap, d.locationId).startsWith(scopeLabel + ' › ')));
  }, [mode, scope, A.drives, A.locMap]);
  const missing = expected.filter((d) => !seen.has(d.id));
  const extra = Array.from(seen)
    .map((id) => A.driveMap.get(id))
    .filter((d): d is Drive => !!d && !expected.some((e) => e.id === d.id));

  return (
    <>
      <PageHeader title="QR Scan" sub="Sticker scan karo: drive kholo, issue / return karo, ya rack ki ginti (verification)." />
      <Segmented
        label="Scan mode"
        value={mode}
        onChange={(m) => {
          setMode(m);
          setLast(null);
        }}
        options={[
          { value: 'open', label: 'Open' },
          { value: 'issue', label: 'Issue' },
          { value: 'return', label: 'Return' },
          { value: 'verify', label: 'Verify stock' },
        ]}
      />
      <div className="u-grid c2">
        <Card pad>
          <div className="u-stack">
            <div className="scan-view">
              {on ? (
                <>
                  <video ref={video} playsInline muted />
                  <div className="scan-frame" />
                  <div className="scan-line" />
                </>
              ) : (
                <div style={{ display: 'grid', placeItems: 'center', height: '100%', color: '#cbd5e1', textAlign: 'center', padding: 20 }}>
                  <div>
                    <ScanLine aria-hidden style={{ width: 54, height: 54, opacity: 0.8 }} />
                    <p style={{ marginTop: 10 }}>Camera band hai</p>
                  </div>
                </div>
              )}
            </div>
            {camErr && <Alert tone="red" icon={CameraOff}>{camErr}</Alert>}
            <div className="u-row">
              {on ? (
                <button type="button" className="btn" onClick={stop}>
                  <CameraOff aria-hidden className="ic" /> Stop camera
                </button>
              ) : (
                <button type="button" className="btn primary" onClick={start}>
                  <Camera aria-hidden className="ic" /> Start camera
                </button>
              )}
            </div>
            <form
              className="u-row"
              style={{ flexWrap: 'nowrap' }}
              onSubmit={(e) => {
                e.preventDefault();
                if (manual.trim()) handle(manual.trim());
                setManual('');
              }}
            >
              <input value={manual} onChange={(e) => setManual(e.target.value)} placeholder="Ya code likho: DRV-0001 / Mark 12 / barcode scanner" aria-label="Code" />
              <button type="submit" className="btn">
                <Keyboard aria-hidden className="ic" /> Go
              </button>
            </form>
            <AnimatePresence>
              {last && (
                <motion.div key={last.at} initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }}>
                  {last.drive ? (
                    <Alert tone="green" icon={CheckCircle2}>
                      <b>{last.drive.displayName}</b> · {DRIVE_STATUS_LABEL[last.drive.status]}
                      {last.drive.holder?.name ? ' · ' + last.drive.holder.name : ''}
                      {mode === 'verify' && ' — counted'}
                    </Alert>
                  ) : (
                    <Alert tone="red" icon={XCircle}>
                      &ldquo;{last.code.slice(0, 80)}&rdquo; kisi registered drive ka code nahi hai.
                    </Alert>
                  )}
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        </Card>

        {mode === 'verify' ? (
          <Card
            title="Inventory verification"
            sub="Store me jo drives honi chahiye, unme se kaunsi scan hui"
            action={
              <button
                type="button"
                className="btn sm primary"
                disabled={!seen.size}
                onClick={() => {
                  audit(
                    me,
                    'drives',
                    'verify',
                    scope,
                    scope ? locLabel(A.locMap, scope) : 'All store',
                    'Expected ' + expected.length + ', found ' + (expected.length - missing.length) + ', missing ' + missing.length + (missing.length ? ': ' + missing.map((d) => d.displayName).join(', ') : '') + (extra.length ? '; extra ' + extra.map((d) => d.displayName).join(', ') : ''),
                  );
                  toast('✓ Verification report audit log me save ho gaya');
                }}
              >
                <ClipboardCheck aria-hidden className="ic" /> Save report
              </button>
            }
          >
            <div className="u-stack">
              <Field label="Kis jagah ki ginti">
                <LocSelect value={scope} onChange={setScope} />
              </Field>
              <div className="u-row">
                <Badge tone="green">{expected.length - missing.length} found</Badge>
                <Badge tone="red">{missing.length} missing</Badge>
                {extra.length > 0 && <Badge tone="amber">{extra.length} not expected here</Badge>}
                {unknown.length > 0 && <Badge tone="gray">{unknown.length} unknown codes</Badge>}
                <button
                  type="button"
                  className="btn sm ghost"
                  onClick={() => {
                    setSeen(new Set());
                    setUnknown([]);
                  }}
                >
                  Reset
                </button>
              </div>
              {missing.length > 0 && (
                <div>
                  <div className="flabel">Abhi tak nahi mili</div>
                  <div className="u-row" style={{ marginTop: 6 }}>
                    {missing.map((d) => (
                      <span key={d.id} className="u-chip">
                        {d.displayName}
                      </span>
                    ))}
                  </div>
                </div>
              )}
              {extra.length > 0 && (
                <div>
                  <div className="flabel">Yahan expected nahi thi</div>
                  <div className="u-row" style={{ marginTop: 6 }}>
                    {extra.map((d) => (
                      <span key={d.id} className="u-chip">
                        {d.displayName} {isOut(d.status) ? '(issued to ' + (d.holder?.name || '?') + ')' : ''}
                      </span>
                    ))}
                  </div>
                </div>
              )}
            </div>
          </Card>
        ) : (
          <Card title="Kaise kaam karta hai">
            <ul className="u-sm" style={{ margin: 0, paddingLeft: 18, display: 'grid', gap: 6 }}>
              <li><b>Open:</b> scan karte hi drive ka profile khulta hai.</li>
              <li><b>Issue:</b> scan → kisko de rahe ho likho → save. Receipt print kar sakte ho.</li>
              <li><b>Return:</b> scan → condition / used space likho → wapas store me.</li>
              <li><b>Verify stock:</b> rack ki saari drives ek-ek scan karo — jo nahi mili wo list me dikhengi.</li>
              <li>USB barcode scanner bhi chalta hai: code wale box me click karke scan karo.</li>
            </ul>
          </Card>
        )}
      </div>
      {move && <MoveDriveModal drive={A.driveMap.get(move.d.id) || move.d} initialKind={move.k} onClose={() => setMove(null)} />}
    </>
  );
}
