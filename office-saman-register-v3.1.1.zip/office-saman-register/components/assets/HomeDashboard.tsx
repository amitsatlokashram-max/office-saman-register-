'use client';

// Premium dashboard: sab number asli records se. Widgets dikhana / chhupana is browser me yaad rehta hai.

import Link from 'next/link';
import { motion, useReducedMotion } from 'motion/react';
import { useEffect, useMemo, useState } from 'react';
import {
  AlertTriangle,
  ArrowLeftRight,
  CalendarDays,
  ClipboardList,
  Database,
  HardDrive,
  IndianRupee,
  LayoutGrid,
  Package,
  Plus,
  ScanLine,
  Server,
  ShieldAlert,
  SlidersHorizontal,
  Truck,
  UserRound,
  Users,
  Wallet,
} from 'lucide-react';
import { buildAlerts } from '@/lib/assets/alerts';
import { almostFull, copyState, gb, isOut, overdue } from '@/lib/assets/model';
import { DRIVE_STATUS, DRIVE_STATUS_LABEL, TRANSFER_LABEL } from '@/lib/assets/types';
import { allIssues, dayLong, inr, inrShort, lastMonths, monShort, myPay, num, sumTotal, today } from '@/lib/calc';
import { useLang } from '@/lib/i18n';
import { useReg } from '../context';
import { summarize } from '@/lib/people';
import { useSources } from '../reports/ReportBuilder';
import { Card, PageHeader, Stat, fmtTime } from '../ui';
import { useAssets } from './store';

const WIDGETS = [
  ['money', 'Purchase & money cards'],
  ['people', 'Stock & people cards'],
  ['storage', 'Storage cards'],
  ['chart', 'Monthly purchase chart'],
  ['dept', 'Department-wise issued value'],
  ['status', 'Drive status'],
  ['alerts', 'Alerts'],
  ['activity', 'Recent activity'],
] as const;
type W = (typeof WIDGETS)[number][0];

const STATUS_COLOR: Record<string, string> = {
  in_store: '#22C55E',
  issued: '#6366F1',
  temp_issued: '#3B82F6',
  repair: '#F59E0B',
  damaged: '#EF4444',
  lost: '#B91C1C',
  retired: '#94A3B8',
};

export function HomeDashboard() {
  const { items, groups, goList, openEntry, newEntry } = useReg();
  const { src } = useSources();
  const A = useAssets();
  const { t } = useLang();
  const reduce = useReducedMotion();
  const [hidden, setHidden] = useState<W[]>([]);
  const [custom, setCustom] = useState(false);
  useEffect(() => {
    try {
      setHidden(JSON.parse(localStorage.getItem('dash-hidden') || '[]'));
    } catch {
      /* ignore */
    }
  }, []);
  const show = (w: W) => !hidden.includes(w);
  const toggleW = (w: W) =>
    setHidden((h) => {
      const n = h.includes(w) ? h.filter((x) => x !== w) : [...h, w];
      try {
        localStorage.setItem('dash-hidden', JSON.stringify(n));
      } catch {
        /* ignore */
      }
      return n;
    });

  const canInv = A.can('inventory', 'view');
  const canDr = A.can('drives', 'view');
  const canCat = A.can('catalog', 'view');

  /* ---- money ---- */
  const mk = today().slice(0, 7);
  const months = lastMonths(6);
  const mTot = useMemo(() => {
    const m = new Map<string, number>(months.map((x) => [x, 0]));
    for (const it of items) {
      const k = it.orderDate.slice(0, 7);
      if (m.has(k)) m.set(k, (m.get(k) || 0) + num(it.total));
    }
    return m;
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [items, mk]);
  const cur = mTot.get(mk) || 0;
  const prev = mTot.get(months[months.length - 2]) || 0;
  const maxM = Math.max(1, ...Array.from(mTot.values()));
  const pend = items.filter((i) => !i.receivedDate);
  const myDue = items.reduce((s, i) => s + myPay(i).due, 0);

  const dept = useMemo(() => {
    const m = new Map<string, number>();
    for (const r of allIssues(items)) {
      const k = r.dept || 'No department';
      m.set(k, (m.get(k) || 0) + r.qty * r.rate);
    }
    return Array.from(m.entries())
      .sort((a, b) => b[1] - a[1])
      .slice(0, 7);
  }, [items]);
  const deptMax = Math.max(1, ...dept.map((d) => d[1]));

  /* ---- storage ---- */
  const t0 = today();
  const S = useMemo(() => {
    const d = A.drives.filter((x) => x.status !== 'retired');
    return {
      hdd: d.filter((x) => x.type === 'HDD').length,
      ssd: d.filter((x) => x.type === 'SSD' || x.type === 'NVMe').length,
      other: d.filter((x) => x.type === 'USB' || x.type === 'MemoryCard').length,
      cap: d.reduce((s, x) => s + x.capacityGB, 0),
      used: d.reduce((s, x) => s + x.usedGB, 0),
      issued: d.filter((x) => isOut(x.status)).length,
      avail: d.filter((x) => x.status === 'in_store').length,
      damaged: d.filter((x) => x.status === 'damaged' || x.status === 'lost').length,
      full: d.filter(almostFull).length,
      overdue: d.filter((x) => overdue(x, t0)).length,
      missingBk: A.catalog.filter((c) => (c.priority === 'Critical' || c.priority === 'High') && copyState(c, A.backups).state === 'none').length,
      total: d.length,
    };
  }, [A.drives, A.catalog, A.backups, t0]);

  const alerts = useMemo(
    () => buildAlerts({ items, groups, drives: A.drives, catalog: A.catalog, backups: A.backups, pendingDemands: A.pendingDemands, canDrives: canDr, canCatalog: canCat }),
    [items, groups, A, canDr, canCat],
  );

  const activity = useMemo(() => {
    const a: { at: string; title: string; sub: string; href?: string; onClick?: () => void; icon: typeof Package }[] = [];
    if (canInv)
      for (const it of items.slice().sort((x, y) => (y.createdAt || '').localeCompare(x.createdAt || '')).slice(0, 8))
        a.push({ at: it.createdAt || it.orderDate, title: it.item, sub: [inr(it.total), it.vendor, it.addedByName].filter(Boolean).join(' · '), onClick: () => openEntry(it.id), icon: Package });
    if (canDr)
      for (const tr of A.transfers.slice(0, 8))
        a.push({ at: tr.at, title: tr.mark + ': ' + TRANSFER_LABEL[tr.kind], sub: [tr.to.name !== 'Store' ? tr.to.name : '', tr.to.dept, tr.byName].filter(Boolean).join(' · '), href: '/drives/' + tr.driveId, icon: ArrowLeftRight });
    return a.sort((x, y) => y.at.localeCompare(x.at)).slice(0, 10);
  }, [items, A.transfers, canInv, canDr, openEntry]);

  const statusCounts = DRIVE_STATUS.map((s) => [s, A.drives.filter((d) => d.status === s).length] as const).filter(([, n]) => n > 0);
  const totalSt = statusCounts.reduce((s, [, n]) => s + n, 0);

  const people = useMemo(() => {
    const sum = summarize(src.ledger);
    let withPeople = 0;
    for (const p of sum.values()) withPeople += p.current;
    return { holders: Array.from(sum.values()).filter((p) => p.current > 0).length, withPeople };
  }, [src.ledger]);
  const avail = groups.reduce((a, g) => a + g.bacha, 0);

  return (
    <>
      <PageHeader
        title="Dashboard"
        sub={dayLong()}
        actions={
          <>
            {A.can('inventory', 'create') && (
              <button type="button" className="btn primary" onClick={newEntry}>
                <Plus aria-hidden className="ic" /> {t('New item')}
              </button>
            )}
            {A.can('drives', 'create') && (
              <Link href="/drives?new=1" className="btn">
                <HardDrive aria-hidden className="ic" /> {t('New drive')}
              </Link>
            )}
            {canDr && (
              <Link href="/scan" className="btn">
                <ScanLine aria-hidden className="ic" /> {t('QR scan')}
              </Link>
            )}
            <button type="button" className="u-iconbtn" onClick={() => setCustom((c) => !c)} aria-label="Customize dashboard" title="Customize widgets">
              <SlidersHorizontal aria-hidden />
            </button>
          </>
        }
      />

      {custom && (
        <Card pad>
          <div className="u-row" style={{ gap: 18 }}>
            <b className="u-sm">Widgets:</b>
            {WIDGETS.map(([w, label]) => (
              <label key={w} className="u-check u-sm">
                <input type="checkbox" checked={show(w)} onChange={() => toggleW(w)} /> {label}
              </label>
            ))}
          </div>
        </Card>
      )}

      {canInv && show('money') && (
        <div className="u-grid c4">
          <Stat
            index={0}
            label="This month's purchases"
            value={cur}
            format={inr}
            icon={CalendarDays}
            sub={
              prev || cur
                ? (cur >= prev ? '▲ ' : '▼ ') + inr(Math.abs(cur - prev)) + ' vs ' + monShort(months[months.length - 2])
                : 'No purchases yet'
            }
            onClick={() => goList({ month: mk })}
          />
          <Stat index={1} label="Total purchases" value={sumTotal(items)} format={inr} icon={IndianRupee} tone="violet" sub={items.length + ' entries'} onClick={() => goList({}, '/hisaab')} />
          <Stat index={2} label="Awaiting delivery" value={pend.length} icon={Truck} tone="amber" sub={pend.length ? inr(sumTotal(pend)) : 'All received'} onClick={() => goList({ status: 'pending' })} />
          <Stat index={3} label="My money due" value={myDue} format={inr} icon={Wallet} tone="red" sub={A.pendingDemands > 0 ? A.pendingDemands + ' demands pending' : 'Reimbursement pending'} onClick={() => goList({ pay: 'baaki' })} />
        </div>
      )}

      {canInv && show('people') && (
        <div className="u-grid c4">
          <Stat index={8} label="Items in stock" value={avail} icon={Package} tone="green" sub={groups.length + ' item types'} href="/stock" />
          <Stat index={9} label="With people now" value={people.withPeople} icon={Users} tone="blue" sub={people.holders + ' persons holding'} href="/persons" />
          <Stat index={10} label="Persons" value={A.persons.length || people.holders} icon={UserRound} tone="violet" sub={A.depts.length + ' departments'} href="/persons" />
          <Stat index={11} label="Events" value={A.events.length} icon={CalendarDays} tone="indigo" sub={A.catalog.length + ' data records'} href={A.can('events', 'view') ? '/events' : '/catalog'} />
        </div>
      )}

      {canDr && show('storage') && (
        <div className="u-grid c4">
          <Stat index={4} label="Drives" value={S.total} icon={HardDrive} sub={S.hdd + ' HDD · ' + S.ssd + ' SSD' + (S.other ? ' · ' + S.other + ' other' : '')} href="/drives" />
          <Stat index={5} label="Total capacity" value={S.cap} format={gb} icon={Server} tone="violet" sub={gb(S.used) + ' used · ' + gb(Math.max(0, S.cap - S.used)) + ' free'} href="/drives?view=table" />
          <Stat index={6} label="Available / issued" value={S.avail} icon={LayoutGrid} tone="green" sub={S.issued + ' issued out · ' + S.overdue + ' overdue'} href="/drives?flag=available" />
          <Stat
            index={7}
            label="Storage risks"
            value={S.full + S.damaged + S.overdue + S.missingBk}
            icon={ShieldAlert}
            tone="red"
            sub={S.full + ' almost full · ' + S.damaged + ' damaged · ' + S.missingBk + ' no backup'}
            href={S.missingBk ? '/backups' : '/drives?flag=full'}
          />
        </div>
      )}

      <div className="u-grid span-2-1">
        <div className="u-stack">
          {canInv && show('chart') && (
            <Card title="Monthly purchases" sub="Pichhle 6 mahine (order date se)">
              <div className="u-chart" role="img" aria-label="Monthly purchase chart">
                {months.map((m, i) => {
                  const v = mTot.get(m) || 0;
                  return (
                    <button key={m} type="button" className="col" onClick={() => goList({ month: m })} style={{ background: 'none', border: 0, cursor: 'pointer', font: 'inherit' }} title={inr(v)}>
                      <span className="v">{v ? inrShort(v) : ''}</span>
                      <motion.span
                        className={'bar' + (m === mk ? '' : ' dim')}
                        initial={reduce ? false : { scaleY: 0 }}
                        animate={{ scaleY: 1 }}
                        transition={{ duration: 0.6, delay: i * 0.06, ease: [0.2, 0.8, 0.2, 1] }}
                        style={{ height: Math.max(2, (v / maxM) * 100) + '%' }}
                      />
                      <span className="m">{monShort(m)}</span>
                    </button>
                  );
                })}
              </div>
            </Card>
          )}
          {show('activity') && (
            <Card title="Recent activity">
              {activity.length === 0 ? (
                <p className="u-muted">Abhi koi activity nahi.</p>
              ) : (
                <ul style={{ listStyle: 'none', margin: 0, padding: 0 }}>
                  {activity.map((a, i) => {
                    const inner = (
                      <>
                        <span className="ico">
                          <a.icon aria-hidden />
                        </span>
                        <span style={{ minWidth: 0, flex: 1 }}>
                          <b className="u-ell" style={{ display: 'block' }}>
                            {a.title}
                          </b>
                          <small>{a.sub}</small>
                        </span>
                        <small className="u-faint" style={{ whiteSpace: 'nowrap' }}>
                          {fmtTime(a.at)}
                        </small>
                      </>
                    );
                    return (
                      <motion.li key={i} initial={reduce ? false : { opacity: 0, x: -6 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: i * 0.03 }}>
                        {a.href ? (
                          <Link href={a.href} className="u-note tone-indigo">
                            {inner}
                          </Link>
                        ) : (
                          <button type="button" className="u-note tone-indigo" onClick={a.onClick}>
                            {inner}
                          </button>
                        )}
                      </motion.li>
                    );
                  })}
                </ul>
              )}
            </Card>
          )}
        </div>
        <div className="u-stack">
          {show('alerts') && (
            <Card title={'Alerts (' + alerts.length + ')'} sub="Bell icon me poori list">
              {alerts.length === 0 ? (
                <p className="u-muted">Sab theek hai.</p>
              ) : (
                alerts.slice(0, 6).map((a) => (
                  <Link key={a.id} href={a.href} className={'u-note tone-' + a.level}>
                    <span className="ico">
                      <AlertTriangle aria-hidden />
                    </span>
                    <span>
                      <b>{a.title}</b>
                      <small>{a.detail}</small>
                    </span>
                  </Link>
                ))
              )}
            </Card>
          )}
          {canDr && show('status') && totalSt > 0 && (
            <Card title="Drive status">
              <div className="u-donut">
                <svg viewBox="0 0 42 42" aria-hidden>
                  <circle cx="21" cy="21" r="15.9" fill="none" stroke="var(--surface-2)" strokeWidth="6" />
                  {(() => {
                    let off = 25;
                    return statusCounts.map(([s, n]) => {
                      const p = (n / totalSt) * 100;
                      const el = (
                        <motion.circle
                          key={s}
                          cx="21"
                          cy="21"
                          r="15.9"
                          fill="none"
                          stroke={STATUS_COLOR[s]}
                          strokeWidth="6"
                          strokeDasharray={p + ' ' + (100 - p)}
                          strokeDashoffset={off}
                          initial={reduce ? false : { opacity: 0 }}
                          animate={{ opacity: 1 }}
                          transition={{ duration: 0.5 }}
                        />
                      );
                      off -= p;
                      return el;
                    });
                  })()}
                  <text x="21" y="23.5" textAnchor="middle" fontSize="8" fontWeight="800" fill="var(--ink)">
                    {totalSt}
                  </text>
                </svg>
                <ul>
                  {statusCounts.map(([s, n]) => (
                    <li key={s}>
                      <i style={{ background: STATUS_COLOR[s] }} />
                      <Link href={'/drives?status=' + s} className="u-link" style={{ fontWeight: 500, color: 'var(--ink)' }}>
                        {DRIVE_STATUS_LABEL[s]}
                      </Link>
                      <b style={{ marginLeft: 'auto', paddingLeft: 12 }}>{n}</b>
                    </li>
                  ))}
                </ul>
              </div>
            </Card>
          )}
          {canInv && show('dept') && dept.length > 0 && (
            <Card title="Issued value by department" sub="Diye gaye saman ki keemat (pcs × rate)">
              <div className="u-hbars">
                {dept.map(([k, v], i) => (
                  <div className="u-hbar" key={k}>
                    <div className="top">
                      <span>{k}</span>
                      <b>{inr(v)}</b>
                    </div>
                    <div className="u-bar sm">
                      <motion.i initial={reduce ? false : { width: 0 }} animate={{ width: (v / deptMax) * 100 + '%' }} transition={{ duration: 0.6, delay: i * 0.05 }} />
                    </div>
                  </div>
                ))}
              </div>
            </Card>
          )}
          {(A.can('demands', 'view') || canCat) && (
            <Card title="Shortcuts">
              <div className="u-row">
                {A.can('demands', 'view') && (
                  <Link href="/demand" className="btn sm">
                    <ClipboardList aria-hidden className="ic" /> Demands {A.pendingDemands > 0 ? '(' + A.pendingDemands + ')' : ''}
                  </Link>
                )}
                {canCat && (
                  <Link href="/catalog" className="btn sm">
                    <Database aria-hidden className="ic" /> Catalogue
                  </Link>
                )}
                {A.can('backups', 'view') && (
                  <Link href="/backups" className="btn sm">
                    <ShieldAlert aria-hidden className="ic" /> Backups
                  </Link>
                )}
              </div>
            </Card>
          )}
        </div>
      </div>
    </>
  );
}
