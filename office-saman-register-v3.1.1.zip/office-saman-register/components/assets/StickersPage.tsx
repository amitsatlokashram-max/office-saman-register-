'use client';

// A4 sticker sheet: Mark range / chuni drives, har sticker ki kai copy, size preset ya custom, design, B/W ya color,
// print preview aur print / Save as PDF. Aadhi istemaal hui sheet ke liye "skip first N labels".

import { useSearchParams } from 'next/navigation';
import { useEffect, useMemo, useState } from 'react';
import { createPortal } from 'react-dom';
import { Printer, QrCode } from 'lucide-react';
import { audit } from '@/lib/assets/db';
import { gb } from '@/lib/assets/model';
import { SERIES, SERIES_LABEL, type Drive, type SeriesKey } from '@/lib/assets/types';
import { num } from '@/lib/calc';
import { useReg } from '../context';
import { Card, Empty, Field, PageHeader, Segmented } from '../ui';
import { Barcode, QR, assetUrl } from './Codes';
import { useAssets } from './store';

type Layout = { id: string; label: string; w: number; h: number; cols: number; rows: number; top: number; left: number; gapX: number; gapY: number };
const LAYOUTS: Layout[] = [
  { id: 'a4-65', label: 'A4 · 65 labels (38.1 × 21.2 mm)', w: 38.1, h: 21.2, cols: 5, rows: 13, top: 10.7, left: 4.7, gapX: 2.5, gapY: 0 },
  { id: 'a4-40', label: 'A4 · 40 labels (48.5 × 25.4 mm)', w: 48.5, h: 25.4, cols: 4, rows: 10, top: 21.5, left: 8, gapX: 0, gapY: 0 },
  { id: 'a4-24', label: 'A4 · 24 labels (64 × 33.9 mm)', w: 64, h: 33.9, cols: 3, rows: 8, top: 13.1, left: 9, gapX: 0, gapY: 0 },
  { id: 'a4-21', label: 'A4 · 21 labels (63.5 × 38.1 mm)', w: 63.5, h: 38.1, cols: 3, rows: 7, top: 15.1, left: 7.2, gapX: 2.5, gapY: 0 },
  { id: 'a4-12', label: 'A4 · 12 labels (105 × 48 mm)', w: 105, h: 48, cols: 2, rows: 6, top: 4.5, left: 0, gapX: 0, gapY: 0 },
];
type Design = 'qr-text' | 'qr-big' | 'barcode' | 'qr-barcode';

export function StickersPage() {
  const A = useAssets();
  const { me, toast } = useReg();
  const sp = useSearchParams();
  const [mode, setMode] = useState<'range' | 'selected' | 'all'>('range');
  const [series, setSeries] = useState<SeriesKey>('SSD');
  const [from, setFrom] = useState('1');
  const [to, setTo] = useState('10');
  const [ids, setIds] = useState<string[]>([]);
  const [copies, setCopies] = useState('1');
  const [skip, setSkip] = useState('0');
  const [layoutId, setLayoutId] = useState('a4-40');
  const [custom, setCustom] = useState<Layout>({ ...LAYOUTS[1], id: 'custom', label: 'Custom' });
  const [design, setDesign] = useState<Design>('qr-text');
  const [color, setColor] = useState<'bw' | 'color'>('bw');
  const [accent, setAccent] = useState('#6366F1');
  const [org, setOrg] = useState('Office Saman Register');
  const [showCap, setShowCap] = useState(true);
  const [border, setBorder] = useState(true);
  const [zoom, setZoom] = useState(0.62);

  useEffect(() => {
    const s = sp.get('ids');
    if (s) {
      setIds(s.split(',').filter(Boolean));
      setMode('selected');
    }
  }, [sp]);
  useEffect(() => {
    if (A.drives.length && mode === 'range' && from === '1' && to === '10') {
      const s0 = A.drives.some((d) => d.series === 'SSD') ? 'SSD' : A.drives[0].series;
      const list = A.drives.filter((d) => d.series === s0);
      setSeries(s0);
      setFrom(String(list[0].markNo));
      setTo(String(list[Math.min(list.length - 1, 39)].markNo));
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [A.drives.length]);
  useEffect(() => {
    try {
      const s = JSON.parse(localStorage.getItem('sticker-settings') || 'null');
      if (s) {
        if (s.layoutId) setLayoutId(s.layoutId);
        if (s.custom) setCustom(s.custom);
        if (s.design) setDesign(s.design);
        if (s.color) setColor(s.color);
        if (s.accent) setAccent(s.accent);
        if (typeof s.org === 'string') setOrg(s.org);
      }
    } catch {
      /* ignore */
    }
  }, []);
  useEffect(() => {
    try {
      localStorage.setItem('sticker-settings', JSON.stringify({ layoutId, custom, design, color, accent, org }));
    } catch {
      /* ignore */
    }
  }, [layoutId, custom, design, color, accent, org]);

  const L = layoutId === 'custom' ? custom : LAYOUTS.find((l) => l.id === layoutId) || LAYOUTS[1];
  const perPage = Math.max(1, L.cols * L.rows);

  const chosen: Drive[] = useMemo(() => {
    if (mode === 'all') return A.drives;
    if (mode === 'selected') return ids.map((id) => A.driveMap.get(id)).filter((d): d is Drive => !!d && !d.deletedAt);
    const a = Math.round(num(from));
    const b = Math.round(num(to));
    return A.drives.filter((d) => d.series === series && d.markNo >= Math.min(a, b) && d.markNo <= Math.max(a, b));
  }, [mode, ids, from, to, A.drives, A.driveMap, series]);

  const n = Math.max(1, Math.min(20, Math.round(num(copies)) || 1));
  const sk = Math.max(0, Math.min(perPage - 1, Math.round(num(skip)) || 0));
  const labels: (Drive | null)[] = [...Array(sk).fill(null), ...chosen.flatMap((d) => Array(n).fill(d))];
  const pages: (Drive | null)[][] = [];
  for (let i = 0; i < labels.length; i += perPage) pages.push(labels.slice(i, i + perPage));
  const total = chosen.length * n;

  const [printing, setPrinting] = useState(false);
  useEffect(() => {
    if (!printing) return;
    const html = document.documentElement;
    html.classList.add('print-stickers');
    const done = () => {
      html.classList.remove('print-stickers');
      setPrinting(false);
    };
    window.addEventListener('afterprint', done, { once: true });
    const h = setTimeout(() => window.print(), 350); // QR SVG ban jaye
    return () => {
      clearTimeout(h);
      window.removeEventListener('afterprint', done);
      html.classList.remove('print-stickers');
    };
  }, [printing]);

  const print = () => {
    if (!total) return;
    setPrinting(true);
    audit(me, 'stickers', 'print', '', total + ' stickers', chosen.map((d) => d.displayName).slice(0, 30).join(', ') + (chosen.length > 30 ? '…' : ''));
    toast('Print window me "Save as PDF" chuno to PDF ban jayegi. Scale 100% / "Actual size" rakho.');
  };

  const qrMM = Math.max(8, Math.min(L.h - 3, design === 'qr-big' ? L.h - 9 : L.h - 3));

  const sticker = (d: Drive | null, i: number) => {
    const cls = 'sticker' + (color === 'color' ? ' color' : border ? ' solid' : '') + (design === 'qr-big' ? ' v' : '');
    const style = { width: L.w + 'mm', height: L.h + 'mm', ['--st-c' as string]: accent } as React.CSSProperties;
    if (!d) return <div key={'s' + i} style={{ width: L.w + 'mm', height: L.h + 'mm' }} />;
    const title = <b style={{ fontSize: Math.max(7, Math.min(16, L.h * 0.42)) + 'pt' }}>{color === 'color' ? <span className="band">{d.displayName}</span> : d.displayName}</b>;
    const sub = (
      <small style={{ fontSize: Math.max(5.5, Math.min(9, L.h * 0.22)) + 'pt' }}>
        {d.assetId}
        {showCap && d.capacityGB ? ' · ' + gb(d.capacityGB) + ' ' + d.type : ''}
      </small>
    );
    const orgLine = org && L.h >= 24 ? <small style={{ fontSize: Math.max(5, Math.min(7.5, L.h * 0.17)) + 'pt', opacity: 0.8 }}>{org}</small> : null;
    if (design === 'barcode')
      return (
        <div key={i} className={cls} style={{ ...style, flexDirection: 'column', alignItems: 'stretch', justifyContent: 'center' }}>
          <div className="tx" style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'baseline', gap: '2mm' }}>
            {title}
            {sub}
          </div>
          <Barcode text={d.assetId} height={Math.max(5, L.h - 10) + 'mm'} />
        </div>
      );
    if (design === 'qr-big')
      return (
        <div key={i} className={cls} style={style}>
          <QR text={assetUrl(d.assetId)} size={qrMM + 'mm'} dark={color === 'color' ? '#111' : '#000'} />
          {title}
        </div>
      );
    return (
      <div key={i} className={cls} style={style}>
        <QR text={assetUrl(d.assetId)} size={qrMM + 'mm'} />
        <div className="tx">
          {title}
          {sub}
          {orgLine}
          {design === 'qr-barcode' && L.w - qrMM > 22 && <Barcode text={d.assetId} height={Math.max(4, L.h * 0.28) + 'mm'} width={L.w - qrMM - 6 + 'mm'} />}
        </div>
      </div>
    );
  };

  const sheets = pages.map((pg, pi) => (
    <div
      key={pi}
      className="sticker-sheet"
      style={{ width: '210mm', height: '297mm', padding: L.top + 'mm 0 0 ' + L.left + 'mm', boxSizing: 'border-box', breakAfter: 'page', overflow: 'hidden' }}
    >
      <div className="sticker-grid" style={{ gridTemplateColumns: 'repeat(' + L.cols + ', ' + L.w + 'mm)', columnGap: L.gapX + 'mm', rowGap: L.gapY + 'mm' }}>
        {pg.map(sticker)}
      </div>
    </div>
  ));

  if (!A.drives.length)
    return (
      <>
        <PageHeader title="QR & Barcode Stickers" />
        <Card>
          <Empty icon={QrCode} title="Pehle drives register karo" />
        </Card>
      </>
    );

  return (
    <>
      <PageHeader
        title="QR & Barcode Stickers"
        sub="A4 sheet pe sticker. QR scan karne par login ke baad us drive ka profile khulta hai."
        actions={
          <button type="button" className="btn primary" onClick={print} disabled={!total}>
            <Printer aria-hidden className="ic" /> Print / Save PDF ({total})
          </button>
        }
      />
      <div className="u-grid sidecol">
        <Card title="Settings">
          <div className="u-stack">
            <Segmented
              label="Which drives"
              value={mode}
              onChange={setMode}
              options={[
                { value: 'range', label: 'Mark range' },
                { value: 'selected', label: 'Selected (' + ids.length + ')' },
                { value: 'all', label: 'All' },
              ]}
            />
            {mode === 'range' && (
              <div className="fgrid">
                <Field label="Series" span>
                  <select value={series} onChange={(e) => setSeries(e.target.value as SeriesKey)}>
                    {SERIES.map((k) => (
                      <option key={k} value={k}>
                        {SERIES_LABEL[k]} ({A.drives.filter((d) => d.series === k).length})
                      </option>
                    ))}
                  </select>
                </Field>
                <Field label="From number">
                  <input type="number" value={from} onChange={(e) => setFrom(e.target.value)} />
                </Field>
                <Field label="To number">
                  <input type="number" value={to} onChange={(e) => setTo(e.target.value)} />
                </Field>
              </div>
            )}
            {mode === 'selected' && (
              <select
                multiple
                value={ids}
                onChange={(e) => setIds(Array.from(e.target.selectedOptions).map((o) => o.value))}
                style={{ height: 150, padding: 6 }}
                aria-label="Choose drives"
              >
                {A.drives.map((d) => (
                  <option key={d.id} value={d.id}>
                    {d.displayName} · {d.assetId}
                  </option>
                ))}
              </select>
            )}
            <p className="hint">{chosen.length} drives · {total} stickers · {pages.length} sheet(s)</p>
            <div className="fgrid">
              <Field label="Copies of each">
                <input type="number" min={1} max={20} value={copies} onChange={(e) => setCopies(e.target.value)} />
              </Field>
              <Field label="Skip first labels" hint="Aadhi bachi sheet ke liye">
                <input type="number" min={0} max={perPage - 1} value={skip} onChange={(e) => setSkip(e.target.value)} />
              </Field>
            </div>
            <Field label="Sheet / label size">
              <select value={layoutId} onChange={(e) => setLayoutId(e.target.value)}>
                {LAYOUTS.map((l) => (
                  <option key={l.id} value={l.id}>
                    {l.label}
                  </option>
                ))}
                <option value="custom">Custom size…</option>
              </select>
            </Field>
            {layoutId === 'custom' && (
              <div className="fgrid">
                {(
                  [
                    ['w', 'Width mm'],
                    ['h', 'Height mm'],
                    ['cols', 'Columns'],
                    ['rows', 'Rows'],
                    ['top', 'Top margin mm'],
                    ['left', 'Left margin mm'],
                    ['gapX', 'Gap across mm'],
                    ['gapY', 'Gap down mm'],
                  ] as [keyof Layout, string][]
                ).map(([k, label]) => (
                  <Field key={k} label={label}>
                    <input type="number" step="0.1" min={0} value={String(custom[k])} onChange={(e) => setCustom((c) => ({ ...c, [k]: Math.max(0, num(e.target.value)) }))} />
                  </Field>
                ))}
              </div>
            )}
            <Field label="Design">
              <select value={design} onChange={(e) => setDesign(e.target.value as Design)}>
                <option value="qr-text">QR + Mark name + details</option>
                <option value="qr-big">Big QR + Mark name</option>
                <option value="qr-barcode">QR + barcode</option>
                <option value="barcode">Barcode only</option>
              </select>
            </Field>
            <div className="fgrid">
              <Field label="Print">
                <select value={color} onChange={(e) => setColor(e.target.value as 'bw' | 'color')}>
                  <option value="bw">Black &amp; white</option>
                  <option value="color">Color</option>
                </select>
              </Field>
              {color === 'color' ? (
                <Field label="Color">
                  <input type="color" value={accent} onChange={(e) => setAccent(e.target.value)} style={{ padding: 4 }} />
                </Field>
              ) : (
                <label className="u-check" style={{ marginTop: 24 }}>
                  <input type="checkbox" checked={border} onChange={(e) => setBorder(e.target.checked)} /> Border
                </label>
              )}
            </div>
            <Field label="Office / org line">
              <input value={org} onChange={(e) => setOrg(e.target.value)} maxLength={60} />
            </Field>
            <label className="u-check">
              <input type="checkbox" checked={showCap} onChange={(e) => setShowCap(e.target.checked)} /> Capacity &amp; type dikhao
            </label>
            <Field label={'Preview zoom ' + Math.round(zoom * 100) + '%'}>
              <input type="range" min={0.3} max={1} step={0.02} value={zoom} onChange={(e) => setZoom(Number(e.target.value))} style={{ padding: 0, height: 24 }} />
            </Field>
            <p className="hint">Print karte waqt Scale = 100% (Actual size) aur Margins = None/Default rakho, warna sticker khisak jayenge. Pehle saade kagaz pe test print karo.</p>
          </div>
        </Card>
        <div className="u-card" style={{ background: 'var(--surface-2)', overflow: 'auto', maxHeight: '82vh' }}>
          {total === 0 ? (
            <Empty icon={QrCode} title="Koi drive nahi chuni" />
          ) : (
            <div className="sheets-preview" style={{ zoom }}>
              {sheets}
            </div>
          )}
        </div>
      </div>
      {printing && typeof document !== 'undefined' && createPortal(<div className="sticker-portal">{sheets}</div>, document.body)}
    </>
  );
}
