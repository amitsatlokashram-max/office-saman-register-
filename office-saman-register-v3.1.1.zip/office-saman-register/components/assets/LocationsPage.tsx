'use client';

import Link from 'next/link';
import { useSearchParams } from 'next/navigation';
import { useEffect, useMemo, useState } from 'react';
import { Building2, ChevronRight, DoorOpen, Layers, MapPin, Pencil, Plus, Server, Trash2, Warehouse } from 'lucide-react';
import { createSlots, deleteLoc, moveDrive, saveLoc } from '@/lib/assets/db';
import { gb, locLabel } from '@/lib/assets/model';
import { DRIVE_STATUS_LABEL, LOCATION_KINDS, LOCATION_LABEL, type Loc, type LocationKind } from '@/lib/assets/types';
import { today } from '@/lib/calc';
import { useReg } from '../context';
import { Badge, Card, Empty, Field, Modal, PageHeader, useBusy } from '../ui';
import { RackLegend, RackView } from './RackView';
import { useAssets } from './store';

const ICON: Record<LocationKind, typeof MapPin> = {
  office: Warehouse,
  building: Building2,
  floor: Layers,
  room: DoorOpen,
  rack: Server,
  shelf: Layers,
  slot: MapPin,
};
const childKind = (k: LocationKind | ''): LocationKind => {
  if (!k) return 'office';
  const i = LOCATION_KINDS.indexOf(k);
  return LOCATION_KINDS[Math.min(i + 1, LOCATION_KINDS.length - 1)];
};

export function LocationsPage() {
  const A = useAssets();
  const { me, toast } = useReg();
  const sp = useSearchParams();
  const [sel, setSel] = useState('');
  const [form, setForm] = useState<{ loc: Loc | null; parent: string; kind: LocationKind } | null>(null);
  const [slotsFor, setSlotsFor] = useState<Loc | null>(null);
  const [place, setPlace] = useState<Loc | null>(null);
  const [open, setOpen] = useState<Set<string>>(new Set());

  useEffect(() => {
    const o = sp.get('open');
    if (o && A.locMap.has(o)) setSel(o);
  }, [sp, A.locMap]);
  // Chuni hui location ke saare parent khule rahein
  useEffect(() => {
    if (!sel) return;
    setOpen((prev) => {
      const n = new Set(prev);
      let cur = A.locMap.get(sel);
      let changed = false;
      while (cur) {
        if (!n.has(cur.id)) {
          n.add(cur.id);
          changed = true;
        }
        cur = cur.parentId ? A.locMap.get(cur.parentId) : undefined;
      }
      return changed ? n : prev;
    });
  }, [sel, A.locMap]);

  const kids = (id: string) => A.locs.filter((l) => l.parentId === id);
  const roots = A.locs.filter((l) => !l.parentId || !A.locMap.has(l.parentId));
  const cur = sel ? A.locMap.get(sel) : undefined;
  const canC = A.can('locations', 'create');
  const canE = A.can('locations', 'edit');
  const canD = A.can('locations', 'delete');

  const under = useMemo(() => {
    if (!cur) return [];
    const ids = new Set<string>([cur.id]);
    let grew = true;
    while (grew) {
      grew = false;
      for (const l of A.locs) if (l.parentId && ids.has(l.parentId) && !ids.has(l.id)) {
        ids.add(l.id);
        grew = true;
      }
    }
    return A.drives.filter((d) => ids.has(d.locationId));
  }, [cur, A.locs, A.drives]);

  const tree = (l: Loc, depth: number) => {
    const ks = kids(l.id).filter((k) => k.kind !== 'slot');
    const isOpen = open.has(l.id);
    const I = ICON[l.kind];
    const slotN = kids(l.id).filter((k) => k.kind === 'slot').length;
    return (
      <li key={l.id}>
        <div
          className={'tree-row' + (sel === l.id ? ' on' : '')}
          onClick={() => {
            setSel(l.id);
            setOpen((o) => {
              const n = new Set(o);
              if (n.has(l.id) && sel === l.id) n.delete(l.id);
              else n.add(l.id);
              return n;
            });
          }}
          role="button"
          tabIndex={0}
        >
          {ks.length ? <ChevronRight aria-hidden className={'tw' + (isOpen ? ' open' : '')} /> : <span style={{ width: 16 }} />}
          <I aria-hidden />
          <span className="nm">{l.name}</span>
          <span className="sz">{slotN ? slotN + ' slots' : LOCATION_LABEL[l.kind]}</span>
        </div>
        {isOpen && ks.length > 0 && <ul>{ks.map((k) => tree(k, depth + 1))}</ul>}
      </li>
    );
  };

  return (
    <>
      <PageHeader
        title="Location & Rack Management"
        sub="Office → Building → Floor → Room → Rack → Shelf → Slot"
        actions={
          canC && (
            <button type="button" className="btn primary" onClick={() => setForm({ loc: null, parent: '', kind: 'office' })}>
              <Plus aria-hidden className="ic" /> Add office / place
            </button>
          )
        }
      />
      {A.locs.length === 0 ? (
        <Card>
          <Empty
            icon={MapPin}
            title="Abhi koi location nahi"
            action={
              canC && (
                <button type="button" className="btn primary" onClick={() => setForm({ loc: null, parent: '', kind: 'office' })}>
                  <Plus aria-hidden className="ic" /> Pehla office banao
                </button>
              )
            }
          >
            Office banao, uske andar room, room me rack, rack me shelf aur shelf me slots. Har drive ko slot me rakhoge to rack view me dikhega kaunsa slot khaali hai.
          </Empty>
        </Card>
      ) : (
        <div className="u-grid sidecol">
          <Card title="All locations">
            <ul className="tree">{roots.map((r) => tree(r, 0))}</ul>
          </Card>
          <div className="u-stack">
            {!cur ? (
              <Card>
                <Empty icon={MapPin} title="Baayi taraf se location chuno" />
              </Card>
            ) : (
              <>
                <Card
                  title={
                    <span>
                      {cur.name} <Badge tone="indigo" plain>{LOCATION_LABEL[cur.kind]}</Badge>
                    </span>
                  }
                  sub={locLabel(A.locMap, cur.id)}
                  action={
                    <div className="u-row">
                      {canC && cur.kind !== 'slot' && (
                        <button type="button" className="btn sm" onClick={() => (cur.kind === 'shelf' ? setSlotsFor(cur) : setForm({ loc: null, parent: cur.id, kind: childKind(cur.kind) }))}>
                          <Plus aria-hidden className="ic" /> {cur.kind === 'shelf' ? 'Add slots' : 'Add inside'}
                        </button>
                      )}
                      {canE && (
                        <button type="button" className="u-iconbtn" aria-label="Edit" onClick={() => setForm({ loc: cur, parent: cur.parentId, kind: cur.kind })}>
                          <Pencil aria-hidden />
                        </button>
                      )}
                      {canD && (
                        <button
                          type="button"
                          className="u-iconbtn"
                          aria-label="Delete"
                          onClick={async () => {
                            if (!window.confirm(cur.name + ' delete karna hai?')) return;
                            try {
                              await deleteLoc(cur, kids(cur.id).length, A.drives.some((d) => d.locationId === cur.id), me);
                              toast('✓ Deleted');
                              setSel(cur.parentId);
                            } catch (e) {
                              toast(e instanceof Error ? e.message : 'Nahi hua');
                            }
                          }}
                        >
                          <Trash2 aria-hidden />
                        </button>
                      )}
                    </div>
                  }
                >
                  {cur.note && <p className="u-muted">{cur.note}</p>}
                  {kids(cur.id).length > 0 && cur.kind !== 'rack' && cur.kind !== 'shelf' && (
                    <div className="u-row">
                      {kids(cur.id).map((k) => (
                        <button key={k.id} type="button" className="u-chip" onClick={() => setSel(k.id)} style={{ border: 0, cursor: 'pointer' }}>
                          {k.name}
                        </button>
                      ))}
                    </div>
                  )}
                  {cur.kind === 'shelf' && <p className="u-sm u-muted">{kids(cur.id).filter((k) => k.kind === 'slot').length} slots</p>}
                </Card>
                {(cur.kind === 'rack' || (cur.kind === 'shelf' && A.locMap.get(cur.parentId)?.kind === 'rack')) && (
                  <div className="rack">
                    <RackLegend />
                    <RackView rack={cur.kind === 'rack' ? cur : A.locMap.get(cur.parentId)!} onEmptySlot={A.can('drives', 'transfer') ? setPlace : undefined} />
                  </div>
                )}
                {cur.kind !== 'rack' && A.locs.filter((l) => l.kind === 'rack' && locLabel(A.locMap, l.id).startsWith(locLabel(A.locMap, cur.id) + ' › ')).map((r) => <RackView key={r.id} rack={r} onEmptySlot={A.can('drives', 'transfer') ? setPlace : undefined} />)}
                <Card title={'Drives here (' + under.length + ')'}>
                  {under.length === 0 ? (
                    <p className="u-muted">Is location (aur andar) koi drive nahi.</p>
                  ) : (
                    <ul style={{ listStyle: 'none', margin: 0, padding: 0 }}>
                      {under.map((d) => (
                        <li key={d.id} className="u-between" style={{ padding: '8px 0', borderBottom: '1px solid var(--line)' }}>
                          <Link className="u-link" href={'/drives/' + d.id}>
                            {d.displayName}
                          </Link>
                          <span className="u-sm u-muted">
                            {locLabel(A.locMap, d.locationId).split(' › ').slice(-2).join(' › ')} · {gb(d.capacityGB)} · {DRIVE_STATUS_LABEL[d.status]}
                            {d.holder?.name ? ' (' + d.holder.name + ')' : ''}
                          </span>
                        </li>
                      ))}
                    </ul>
                  )}
                </Card>
              </>
            )}
          </div>
        </div>
      )}

      {form && <LocForm init={form} onClose={() => setForm(null)} onSaved={(id) => setSel(id)} />}
      {slotsFor && <SlotsForm shelf={slotsFor} existing={kids(slotsFor.id).filter((k) => k.kind === 'slot').length} onClose={() => setSlotsFor(null)} />}
      {place && <PlaceForm slot={place} onClose={() => setPlace(null)} />}
    </>
  );
}

function LocForm({ init, onClose, onSaved }: { init: { loc: Loc | null; parent: string; kind: LocationKind }; onClose: () => void; onSaved: (id: string) => void }) {
  const { me, toast } = useReg();
  const A = useAssets();
  const [name, setName] = useState(init.loc?.name || '');
  const [kind, setKind] = useState<LocationKind>(init.kind);
  const [note, setNote] = useState(init.loc?.note || '');
  const [busy, run] = useBusy();
  const parent = init.parent ? A.locMap.get(init.parent) : undefined;
  return (
    <Modal
      open
      size="sm"
      onClose={onClose}
      title={init.loc ? 'Edit location' : 'New location'}
      sub={parent ? 'Inside: ' + locLabel(A.locMap, parent.id) : undefined}
      onSubmit={() =>
        run(async () => {
          if (!name.trim()) return;
          try {
            const id = await saveLoc({ id: init.loc?.id, name: name.trim(), kind, parentId: init.parent, order: init.loc?.order ?? Date.now() % 100000, note: note.trim() }, me);
            toast('✓ Saved');
            onSaved(id);
            onClose();
          } catch {
            toast('Save nahi hua (ijaazat?)');
          }
        })
      }
      foot={
        <>
          <button type="button" className="btn" onClick={onClose}>
            Cancel
          </button>
          <button type="submit" className="btn primary" disabled={busy}>
            Save
          </button>
        </>
      }
    >
      <div className="fgrid">
        <Field label="Type">
          <select value={kind} onChange={(e) => setKind(e.target.value as LocationKind)}>
            {LOCATION_KINDS.map((k) => (
              <option key={k} value={k}>
                {LOCATION_LABEL[k]}
              </option>
            ))}
          </select>
        </Field>
        <Field label="Naam">
          <input value={name} onChange={(e) => setName(e.target.value)} required maxLength={120} autoFocus placeholder={kind === 'rack' ? 'Rack A' : kind === 'shelf' ? 'Shelf 1' : ''} />
        </Field>
        <Field label="Note" span>
          <input value={note} onChange={(e) => setNote(e.target.value)} maxLength={300} />
        </Field>
      </div>
    </Modal>
  );
}

function SlotsForm({ shelf, existing, onClose }: { shelf: Loc; existing: number; onClose: () => void }) {
  const { me, toast } = useReg();
  const [n, setN] = useState('10');
  const [busy, run] = useBusy();
  return (
    <Modal
      open
      size="sm"
      onClose={onClose}
      title={'Add slots to ' + shelf.name}
      onSubmit={() =>
        run(async () => {
          try {
            await createSlots(shelf, Math.round(Number(n)) || 0, existing + 1, me);
            toast('✓ Slots added');
            onClose();
          } catch (e) {
            toast(e instanceof Error ? e.message : 'Nahi hua');
          }
        })
      }
      foot={
        <>
          <button type="button" className="btn" onClick={onClose}>
            Cancel
          </button>
          <button type="submit" className="btn primary" disabled={busy}>
            Add
          </button>
        </>
      }
    >
      <Field label="Kitne slot" hint={'Naam S' + (existing + 1) + ', S' + (existing + 2) + '… se'}>
        <input type="number" min={1} max={200} value={n} onChange={(e) => setN(e.target.value)} />
      </Field>
    </Modal>
  );
}

function PlaceForm({ slot, onClose }: { slot: Loc; onClose: () => void }) {
  const A = useAssets();
  const { me, toast } = useReg();
  const [id, setId] = useState('');
  const [busy, run] = useBusy();
  const choices = A.drives.filter((d) => !A.slotIds.has(d.locationId) || !d.locationId);
  return (
    <Modal
      open
      size="sm"
      onClose={onClose}
      title={'Slot ' + slot.name + ' me drive rakho'}
      sub={locLabel(A.locMap, slot.id)}
      onSubmit={() =>
        run(async () => {
          if (!id) return;
          try {
            await moveDrive(id, { kind: 'location_transfer', to: { name: '', dept: '', locationId: slot.id }, purpose: '', date: today(), expectedReturn: '', condition: '', usedGB: null, notes: 'Placed from rack view' }, me, A.slotIds);
            toast('✓ Placed');
            onClose();
          } catch (e) {
            toast(e instanceof Error ? e.message : 'Nahi hua');
          }
        })
      }
      foot={
        <>
          <button type="button" className="btn" onClick={onClose}>
            Cancel
          </button>
          <button type="submit" className="btn primary" disabled={busy || !id}>
            Place
          </button>
        </>
      }
    >
      <Field label="Drive (jo kisi slot me nahi hai)">
        <select value={id} onChange={(e) => setId(e.target.value)} required>
          <option value="">— Choose —</option>
          {choices.map((d) => (
            <option key={d.id} value={d.id}>
              {d.displayName} · {gb(d.capacityGB)} {d.locationId ? '· ' + locLabel(A.locMap, d.locationId) : ''}
            </option>
          ))}
        </select>
      </Field>
    </Modal>
  );
}
