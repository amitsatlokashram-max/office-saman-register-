'use client';

import Link from 'next/link';
import { useSearchParams } from 'next/navigation';
import { useEffect, useMemo, useState } from 'react';
import { AlertTriangle, CheckCircle2, Copy, Info, Plus, ShieldAlert, ShieldCheck, ShieldQuestion, XCircle } from 'lucide-react';
import { createBackup, updateBackup } from '@/lib/assets/db';
import { copyState, hashVerdict } from '@/lib/assets/model';
import { BACKUP_STATUS_LABEL, type Backup, type BackupStatus, type CatalogEntry } from '@/lib/assets/types';
import { num } from '@/lib/calc';
import { useReg } from '../context';
import { DataTable, type Col } from '../ui/DataTable';
import { Alert, Badge, Card, Empty, Field, Modal, PageHeader, Stat, Tabs, fmtTime, useBusy } from '../ui';
import { useAssets } from './store';

const TONE: Record<BackupStatus, 'green' | 'amber' | 'red' | 'gray'> = { verified: 'green', completed: 'amber', failed: 'red', assigned: 'gray' };

export function BackupsPage() {
  const A = useAssets();
  const sp = useSearchParams();
  const [tab, setTab] = useState<'risk' | 'all'>('risk');
  const [assign, setAssign] = useState<string | null>(null);
  const [work, setWork] = useState<Backup | null>(null);

  useEffect(() => {
    const c = sp.get('catalog');
    if (c && A.can('backups', 'create')) setAssign(c);
  }, [sp, A]);

  const states = useMemo(() => A.catalog.map((c) => ({ c, s: copyState(c, A.backups) })), [A.catalog, A.backups]);
  const single = states.filter((x) => x.s.state === 'none');
  const outdated = states.filter((x) => x.s.state === 'outdated');
  const unverified = states.filter((x) => x.s.state === 'unverified');
  const failed = A.backups.filter((b) => b.status === 'failed');
  const verifiedN = states.filter((x) => x.s.state === 'verified').length;

  const cname = (id: string) => {
    const c = A.catalog.find((x) => x.id === id);
    return c ? [c.project, c.title].filter(Boolean).join(' · ') : '(deleted entry)';
  };
  const dname = (id: string) => A.driveMap.get(id)?.displayName || '—';

  const cols: Col<Backup>[] = [
    { key: 'data', label: 'Data', value: (b) => cname(b.catalogId), render: (b) => <b>{cname(b.catalogId)}</b> },
    { key: 'src', label: 'Original on', value: (b) => dname(b.sourceDriveId), render: (b) => <Link className="u-link" href={'/drives/' + b.sourceDriveId} onClick={(e) => e.stopPropagation()}>{dname(b.sourceDriveId)}</Link>, card: true },
    { key: 'copy', label: 'Copy on', value: (b) => dname(b.copyDriveId), render: (b) => <Link className="u-link" href={'/drives/' + b.copyDriveId} onClick={(e) => e.stopPropagation()}>{dname(b.copyDriveId)}</Link>, card: true },
    { key: 'path', label: 'Copy path', value: (b) => b.copyPath, render: (b) => <span className="u-mono u-sm">{b.copyPath || '—'}</span>, hidden: true },
    { key: 'status', label: 'Status', value: (b) => b.status, render: (b) => <Badge tone={TONE[b.status]}>{BACKUP_STATUS_LABEL[b.status]}</Badge>, card: true },
    { key: 'method', label: 'Method', value: (b) => b.method, render: (b) => b.method || '—', hidden: true },
    { key: 'done', label: 'Copied', value: (b) => b.completedAt, render: (b) => (b.completedAt ? fmtTime(b.completedAt) : '—') },
    { key: 'ver', label: 'Verified', value: (b) => b.verifiedAt, render: (b) => (b.verifiedAt ? fmtTime(b.verifiedAt) + ' · ' + b.verifiedBy : '—') },
  ];

  const riskRow = (x: { c: CatalogEntry; s: ReturnType<typeof copyState> }, why: string) => (
    <li key={x.c.id} className="u-between" style={{ padding: '10px 0', borderBottom: '1px solid var(--line)' }}>
      <span style={{ minWidth: 0 }}>
        <b>{[x.c.project, x.c.title].filter(Boolean).join(' · ')}</b>
        <span className="u-sm u-muted">
          {' '}
          · {dname(x.c.driveId)} · {x.c.priority} · {why}
        </span>
      </span>
      {A.can('backups', 'create') && (
        <button type="button" className="btn sm" onClick={() => setAssign(x.c.id)}>
          <Plus aria-hidden className="ic" /> Assign backup
        </button>
      )}
    </li>
  );

  return (
    <>
      <PageHeader
        title="Backup Management"
        sub="Original data aur uski copies. Verified tabhi likha jata hai jab dono taraf ka hash sach me mila ho."
        actions={
          A.can('backups', 'create') && (
            <button type="button" className="btn primary" onClick={() => setAssign('')} disabled={!A.catalog.length}>
              <Plus aria-hidden className="ic" /> Assign backup
            </button>
          )
        }
      />
      <div className="u-grid c4">
        <Stat index={0} label="Verified" value={verifiedN} icon={ShieldCheck} tone="green" sub="Hash matched" />
        <Stat index={1} label="Copied, not verified" value={unverified.length} icon={ShieldQuestion} tone="amber" />
        <Stat index={2} label="Single copy (no backup)" value={single.length} icon={ShieldAlert} tone="red" sub={single.filter((x) => x.c.priority === 'Critical' || x.c.priority === 'High').length + ' high / critical'} />
        <Stat index={3} label="Outdated / failed" value={outdated.length + failed.length} icon={AlertTriangle} tone="amber" />
      </div>

      {A.catalog.length === 0 ? (
        <Card>
          <Empty icon={ShieldCheck} title="Pehle data catalogue banao" action={<Link className="btn primary" href="/catalog">Data catalogue</Link>}>
            Backup kis data ka hai, ye catalogue entry se judta hai.
          </Empty>
        </Card>
      ) : (
        <>
          <Tabs
            value={tab}
            onChange={setTab}
            tabs={[
              { value: 'risk', label: 'Risks' },
              { value: 'all', label: 'All backup records (' + A.backups.length + ')' },
            ]}
          />
          {tab === 'risk' ? (
            <div className="u-grid c2">
              <Card title="Single copy — no backup" sub="Ye data sirf ek drive pe hai">
                {single.length ? <ul style={{ listStyle: 'none', margin: 0, padding: 0 }}>{single.slice().sort((a, b) => ['Critical', 'High', 'Normal', 'Low'].indexOf(a.c.priority) - ['Critical', 'High', 'Normal', 'Low'].indexOf(b.c.priority)).map((x) => riskRow(x, 'no copy'))}</ul> : <p className="u-muted">Sab data ki kam se kam ek copy hai.</p>}
              </Card>
              <div className="u-stack">
                <Card title="Copied but not verified">
                  {unverified.length ? (
                    <ul style={{ listStyle: 'none', margin: 0, padding: 0 }}>
                      {unverified.map((x) => (
                        <li key={x.c.id} className="u-between" style={{ padding: '8px 0', borderBottom: '1px solid var(--line)' }}>
                          <span>{[x.c.project, x.c.title].filter(Boolean).join(' · ')}</span>
                          <button
                            type="button"
                            className="btn sm"
                            onClick={() => {
                              const b = A.backups.find((y) => y.catalogId === x.c.id && y.status === 'completed');
                              if (b) setWork(b);
                            }}
                          >
                            Verify
                          </button>
                        </li>
                      ))}
                    </ul>
                  ) : (
                    <p className="u-muted">Koi nahi.</p>
                  )}
                </Card>
                <Card title="Outdated (data badla, copy purani)">
                  {outdated.length ? <ul style={{ listStyle: 'none', margin: 0, padding: 0 }}>{outdated.map((x) => riskRow(x, 'changed after last copy'))}</ul> : <p className="u-muted">Koi nahi.</p>}
                </Card>
                {failed.length > 0 && (
                  <Card title="Verification failed">
                    <ul style={{ listStyle: 'none', margin: 0, padding: 0 }}>
                      {failed.map((b) => (
                        <li key={b.id} className="u-between" style={{ padding: '8px 0' }}>
                          <span>
                            {cname(b.catalogId)} → {dname(b.copyDriveId)}
                          </span>
                          <button type="button" className="btn sm" onClick={() => setWork(b)}>
                            Open
                          </button>
                        </li>
                      ))}
                    </ul>
                  </Card>
                )}
              </div>
            </div>
          ) : (
            <DataTable id="backups" rows={A.backups} cols={cols} exportName="backup-report" canExport={A.can('backups', 'export')} searchText={(b) => [cname(b.catalogId), dname(b.sourceDriveId), dname(b.copyDriveId), b.copyPath, b.status].join(' ')} onRow={setWork} cardTitle={(b) => <b>{cname(b.catalogId)}</b>} empty={<Empty icon={Copy} title="Abhi koi backup record nahi" />} />
          )}
        </>
      )}

      {assign !== null && <AssignModal catalogId={assign} onClose={() => setAssign(null)} />}
      {work && <WorkModal b={A.backups.find((x) => x.id === work.id) || work} onClose={() => setWork(null)} />}
    </>
  );
}

function AssignModal({ catalogId, onClose }: { catalogId: string; onClose: () => void }) {
  const A = useAssets();
  const { me, toast } = useReg();
  const [cid, setCid] = useState(catalogId);
  const [copy, setCopy] = useState('');
  const [path, setPath] = useState('');
  const [notes, setNotes] = useState('');
  const [err, setErr] = useState('');
  const [busy, run] = useBusy();
  const c = A.catalog.find((x) => x.id === cid);
  useEffect(() => {
    if (c) setPath(c.folderPath);
  }, [c]);
  const free = (id: string) => {
    const d = A.driveMap.get(id);
    return d ? Math.max(0, d.capacityGB - d.usedGB) : 0;
  };
  return (
    <Modal
      open
      onClose={onClose}
      title="Assign backup copy"
      sub="Kis data ki copy kis doosri drive pe banani hai"
      onSubmit={() =>
        run(async () => {
          setErr('');
          if (!c) return setErr('Data chuno.');
          if (!copy) return setErr('Copy wali drive chuno.');
          try {
            await createBackup({ catalogId: c.id, sourceDriveId: c.driveId, copyDriveId: copy, copyPath: path.trim(), notes: notes.trim() }, me);
            toast('✓ Backup assigned');
            onClose();
          } catch (e) {
            setErr(e instanceof Error ? e.message : 'Nahi hua');
          }
        })
      }
      foot={
        <>
          <button type="button" className="btn" onClick={onClose}>
            Cancel
          </button>
          <button type="submit" className="btn primary" disabled={busy}>
            Assign
          </button>
        </>
      }
    >
      {err && <div className="ferr">{err}</div>}
      <div className="fgrid">
        <Field label="Data (catalogue entry)" span>
          <select value={cid} onChange={(e) => setCid(e.target.value)} required>
            <option value="">— Choose —</option>
            {A.catalog.map((x) => (
              <option key={x.id} value={x.id}>
                {[x.project, x.title].filter(Boolean).join(' · ')} — {A.driveMap.get(x.driveId)?.displayName}
              </option>
            ))}
          </select>
        </Field>
        <Field label="Copy kis drive pe" span hint={c?.sizeGB ? 'Data ka size ' + c.sizeGB + ' GB' : undefined}>
          <select value={copy} onChange={(e) => setCopy(e.target.value)} required>
            <option value="">— Choose drive —</option>
            {A.drives
              .filter((d) => d.id !== c?.driveId && d.status !== 'retired' && d.status !== 'lost' && d.status !== 'damaged')
              .map((d) => (
                <option key={d.id} value={d.id} disabled={!!c?.sizeGB && free(d.id) < c.sizeGB}>
                  {d.displayName} · {Math.round(free(d.id))} GB free {c?.sizeGB && free(d.id) < c.sizeGB ? '(not enough space)' : ''}
                </option>
              ))}
          </select>
        </Field>
        <Field label="Copy ka folder path" span>
          <input value={path} onChange={(e) => setPath(e.target.value)} maxLength={1000} />
        </Field>
        <Field label="Note" span>
          <input value={notes} onChange={(e) => setNotes(e.target.value)} maxLength={300} />
        </Field>
      </div>
    </Modal>
  );
}

function WorkModal({ b, onClose }: { b: Backup; onClose: () => void }) {
  const A = useAssets();
  const { me, toast } = useReg();
  const [sf, setSf] = useState(b.sourceFiles ? String(b.sourceFiles) : '');
  const [cf, setCf] = useState(b.copyFiles ? String(b.copyFiles) : '');
  const [method, setMethod] = useState<Backup['method']>(b.method || 'sha256');
  const [sh, setSh] = useState(b.sourceHash);
  const [ch, setCh] = useState(b.copyHash);
  const [busy, run] = useBusy();
  const verdict = hashVerdict(sh, ch);
  const countMismatch = num(sf) > 0 && num(cf) > 0 && num(sf) !== num(cf);
  const canApprove = A.can('backups', 'approve');
  const canEdit = A.can('backups', 'edit');

  const markCopied = () =>
    run(async () => {
      await updateBackup(b, { status: 'completed', completedAt: new Date().toISOString(), sourceFiles: Math.round(num(sf)), copyFiles: Math.round(num(cf)) }, 'Copy completed', me).then(
        () => toast('✓ Marked copied (not verified)'),
        () => toast('Nahi hua'),
      );
    });
  const verify = () =>
    run(async () => {
      if (!verdict) return;
      const ok = verdict === 'verified' && !countMismatch;
      const status: BackupStatus = ok ? 'verified' : 'failed';
      await updateBackup(
        b,
        {
          status,
          method,
          sourceHash: sh.trim(),
          copyHash: ch.trim(),
          sourceFiles: Math.round(num(sf)),
          copyFiles: Math.round(num(cf)),
          completedAt: b.completedAt || new Date().toISOString(),
          verifiedAt: ok ? new Date().toISOString() : '',
          verifiedBy: ok ? me?.name || '' : '',
        },
        ok ? 'Verified (' + method + ' hash matched)' : 'Verification failed (' + (countMismatch ? 'file count differs' : 'hash differs') + ')',
        me,
      ).then(
        () => toast(ok ? '✓ Verified' : 'Hash / file count match nahi hua — failed likha gaya'),
        () => toast('Nahi hua'),
      );
    });

  const c = A.catalog.find((x) => x.id === b.catalogId);
  return (
    <Modal open onClose={onClose} title={'Backup: ' + (c ? c.title || c.project : '')} sub={(A.driveMap.get(b.sourceDriveId)?.displayName || '—') + ' → ' + (A.driveMap.get(b.copyDriveId)?.displayName || '—')}>
      <div className="u-between">
        <Badge tone={TONE[b.status]}>{BACKUP_STATUS_LABEL[b.status]}</Badge>
        {b.verifiedAt && <span className="u-sm u-muted">Verified {fmtTime(b.verifiedAt)} · {b.verifiedBy}</span>}
      </div>
      {canEdit && (
        <>
          <div className="fgrid">
            <Field label="Original me files">
              <input type="number" min={0} value={sf} onChange={(e) => setSf(e.target.value)} />
            </Field>
            <Field label="Copy me files">
              <input type="number" min={0} value={cf} onChange={(e) => setCf(e.target.value)} />
            </Field>
          </div>
          {b.status === 'assigned' && (
            <button type="button" className="btn" onClick={markCopied} disabled={busy}>
              <Copy aria-hidden className="ic" /> Copy ho gayi (abhi verify nahi)
            </button>
          )}
          <Alert icon={Info} tone="blue">
            Verify karne ke liye dono folders ka hash nikalo aur yahan paste karo. Windows: <code>Get-FileHash -Algorithm SHA256 file.mp4</code> · Mac: <code>shasum -a 256 file.mp4</code>. Poore folder ke liye har file ka hash list bana ke us list ka hash lo (README me tareeka). App khud kuch nahi maanta — dono hash barabar hone par hi &ldquo;Verified&rdquo;.
          </Alert>
          <div className="fgrid">
            <Field label="Hash method">
              <select value={method} onChange={(e) => setMethod(e.target.value as Backup['method'])}>
                <option value="sha256">SHA-256</option>
                <option value="md5">MD5</option>
                <option value="xxhash">xxHash</option>
              </select>
            </Field>
            <span />
            <Field label="Original ka hash" span>
              <input value={sh} onChange={(e) => setSh(e.target.value)} className="u-mono" maxLength={200} />
            </Field>
            <Field label="Copy ka hash" span>
              <input value={ch} onChange={(e) => setCh(e.target.value)} className="u-mono" maxLength={200} />
            </Field>
          </div>
          {verdict && (
            <Alert icon={verdict === 'verified' && !countMismatch ? CheckCircle2 : XCircle} tone={verdict === 'verified' && !countMismatch ? 'green' : 'red'}>
              {verdict === 'verified' && !countMismatch ? 'Dono hash barabar hai.' : countMismatch ? 'File count alag hai.' : 'Hash alag hai — copy sahi nahi hai.'}
            </Alert>
          )}
          <button type="button" className="btn primary" onClick={verify} disabled={busy || !verdict || (verdict === 'verified' && !countMismatch && !canApprove)}>
            <ShieldCheck aria-hidden className="ic" /> Save verification
          </button>
          {verdict === 'verified' && !canApprove && <p className="hint">&ldquo;Verified&rdquo; save karne ke liye Backups → Approve ijaazat chahiye.</p>}
        </>
      )}
      {b.history.length > 0 && (
        <div>
          <div className="flabel">History</div>
          <ul className="u-sm" style={{ margin: '6px 0 0', paddingLeft: 18 }}>
            {b.history
              .slice()
              .reverse()
              .map((h, i) => (
                <li key={i}>
                  {fmtTime(h.at)} · {h.by} · {h.what}
                </li>
              ))}
          </ul>
        </div>
      )}
    </Modal>
  );
}
