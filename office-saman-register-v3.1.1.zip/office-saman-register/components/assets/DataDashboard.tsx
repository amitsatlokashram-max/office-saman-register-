'use client';

// Digital Data Manager ka alag dashboard: HDD / SSD, capacity, khaali / bhari / kharab, bande-wise aur department-wise storage.
// "Last verified" = aakhri scan; haath se likha used-space live/verified nahi maana jata.

import Link from 'next/link';
import { motion, useReducedMotion } from 'motion/react';
import { useMemo } from 'react';
import { AlertTriangle, ArrowLeftRight, CalendarDays, Database, HardDrive, Plus, QrCode, ScanLine, Server, ShieldAlert, Wrench } from 'lucide-react';
import { almostFull, copyState, gb, isOut, overdue, usedPct } from '@/lib/assets/model';
import { TRANSFER_LABEL } from '@/lib/assets/types';
import { today } from '@/lib/calc';
import { Card, PageHeader, Stat, fmtDate, fmtTime } from '../ui';
import { useAssets } from './store';

function Bars({ rows, fmt = gb, href }: { rows: [string, number][]; fmt?: (n: number) => string; href?: (k: string) => string }) {
  const reduce = useReducedMotion();
  const max = Math.max(1, ...rows.map((r) => r[1]));
  if (!rows.length) return <p className="u-muted u-sm">Abhi data nahi.</p>;
  return (
    <div className="u-hbars">
      {rows.map(([k, v], i) => (
        <div className="u-hbar" key={k}>
          <div className="top">
            {href ? (
              <Link href={href(k)} className="u-link" style={{ fontWeight: 500 }}>
                {k}
              </Link>
            ) : (
              <span>{k}</span>
            )}
            <b>{fmt(v)}</b>
          </div>
          <div className="u-bar sm">
            <motion.i initial={reduce ? false : { width: 0 }} animate={{ width: (v / max) * 100 + '%' }} transition={{ duration: 0.6, delay: i * 0.04 }} />
          </div>
        </div>
      ))}
    </div>
  );
}

export function DataDashboard() {
  const A = useAssets();
  const t0 = today();
  const S = useMemo(() => {
    const d = A.drives.filter((x) => x.status !== 'retired');
    const by = (f: (x: (typeof d)[number]) => string) => {
      const m = new Map<string, number>();
      for (const x of d) {
        const k = f(x);
        if (k) m.set(k, (m.get(k) || 0) + x.capacityGB);
      }
      return Array.from(m.entries()).sort((a, b) => b[1] - a[1]).slice(0, 8);
    };
    const cat = new Map<string, number>();
    for (const c of A.catalog) cat.set(c.category, (cat.get(c.category) || 0) + c.sizeGB);
    const lastScan = d.map((x) => x.lastScanAt).filter(Boolean).sort().pop() || '';
    return {
      total: d.length,
      hdd: d.filter((x) => x.type === 'HDD').length,
      ssd: d.filter((x) => x.type === 'SSD' || x.type === 'NVMe').length,
      other: d.filter((x) => x.type === 'USB' || x.type === 'MemoryCard').length,
      cap: d.reduce((a, x) => a + x.capacityGB, 0),
      used: d.reduce((a, x) => a + x.usedGB, 0),
      empty: d.filter((x) => x.usedGB === 0).length,
      avail: d.filter((x) => x.status === 'in_store').length,
      assigned: d.filter((x) => isOut(x.status)).length,
      overdue: d.filter((x) => overdue(x, t0)).length,
      almost: d.filter((x) => almostFull(x) && usedPct(x) < 99).length,
      full: d.filter((x) => x.capacityGB > 0 && usedPct(x) >= 99).length,
      damaged: d.filter((x) => x.status === 'damaged').length,
      lost: d.filter((x) => x.status === 'lost').length,
      repair: d.filter((x) => x.status === 'repair').length,
      unverified: d.filter((x) => !x.lastScanAt).length,
      missingBk: A.catalog.filter((c) => copyState(c, A.backups).state === 'none').length,
      byPerson: by((x) => (isOut(x.status) ? x.holder?.name || '' : '')),
      byDept: by((x) => x.holder?.dept || x.dept),
      byPlace: by((x) => (isOut(x.status) ? '' : x.place || 'Jagah nahi likhi')),
      byCat: Array.from(cat.entries()).sort((a, b) => b[1] - a[1]).slice(0, 8),
      lastScan,
    };
  }, [A.drives, A.catalog, A.backups, t0]);

  return (
    <>
      <PageHeader
        title="Digital Data Manager"
        sub={S.lastScan ? 'Storage figures aakhri baar scan se verify: ' + fmtTime(S.lastScan) + ' · baaki haath se likhe' : 'Storage figures haath se likhe hai — abhi kisi drive ka scan import nahi hua'}
        actions={
          <>
            {A.can('drives', 'create') && (
              <Link href="/drives?new=1" className="btn primary">
                <Plus aria-hidden className="ic" /> Register SSD / HDD
              </Link>
            )}
            {A.can('events', 'create') && (
              <Link href="/events?new=1" className="btn">
                <CalendarDays aria-hidden className="ic" /> New event
              </Link>
            )}
            <Link href="/scan" className="btn">
              <ScanLine aria-hidden className="ic" /> QR scan
            </Link>
            {A.can('stickers', 'view') && (
              <Link href="/stickers" className="btn">
                <QrCode aria-hidden className="ic" /> Stickers
              </Link>
            )}
          </>
        }
      />
      <div className="bento">
        <Stat index={0} label="Total drives" value={S.total} icon={HardDrive} sub={S.hdd + ' HDD · ' + S.ssd + ' SSD' + (S.other ? ' · ' + S.other + ' other' : '')} href="/drives" />
        <Stat index={1} label="Total capacity" value={S.cap} format={gb} icon={Server} tone="violet" sub={gb(S.used) + ' used · ' + gb(Math.max(0, S.cap - S.used)) + ' free'} href="/drives?view=table" />
        <Stat index={2} label="Available in office" value={S.avail} icon={HardDrive} tone="green" sub={S.empty + ' bilkul khaali'} href="/drives?flag=available" />
        <Stat index={3} label="With people" value={S.assigned} icon={ArrowLeftRight} tone="blue" sub={S.overdue + ' overdue'} href="/drives?flag=out" />
        <Stat index={4} label="Almost full / full" value={S.almost + S.full} icon={AlertTriangle} tone="amber" sub={S.almost + ' 90%+ · ' + S.full + ' full'} href="/drives?flag=full" />
        <Stat index={5} label="Damaged / lost / repair" value={S.damaged + S.lost + S.repair} icon={Wrench} tone="red" sub={S.damaged + ' damaged · ' + S.lost + ' lost · ' + S.repair + ' repair'} href="/drives?status=damaged" />
        <Stat index={6} label="Never scanned" value={S.unverified} icon={ScanLine} tone="gray" sub="Used space verify nahi" href="/drives?flag=unscanned" />
        <Stat index={7} label="Data records" value={A.catalog.length} icon={Database} tone="indigo" sub={A.events.length + ' events'} href="/catalog" />
        <Stat index={8} label="Single copy (no backup)" value={S.missingBk} icon={ShieldAlert} tone="red" href="/backups" />
      </div>
      <div className="u-grid c2">
        <Card title="Storage kiske paas (bande)" sub="Jo drives abhi logo ko di hui hai">
          <Bars rows={S.byPerson} href={(k) => '/drives?holder=' + encodeURIComponent(k)} />
        </Card>
        <Card title="Storage department-wise">
          <Bars rows={S.byDept} />
        </Card>
        <Card title="Office me kahan (jagah-wise)">
          <Bars rows={S.byPlace} />
        </Card>
        <Card title="Data category-wise (catalogued size)">
          <Bars rows={S.byCat} />
        </Card>
      </div>
      <div className="u-grid c2">
        <Card title="Haal ki drive movement" action={<Link className="btn sm ghost" href="/reports?dataset=transfers">Report</Link>}>
          {A.transfers.length === 0 ? (
            <p className="u-muted">—</p>
          ) : (
            <ul style={{ listStyle: 'none', margin: 0, padding: 0 }}>
              {A.transfers.slice(0, 8).map((t) => (
                <li key={t.id} className="u-between" style={{ padding: '6px 0', borderBottom: '1px solid var(--line)' }}>
                  <Link className="u-link" href={'/drives/' + t.driveId}>
                    {t.mark}: {TRANSFER_LABEL[t.kind]}
                  </Link>
                  <span className="u-sm u-muted">
                    {[t.to.name !== 'Store' ? t.to.name : '', t.to.place].filter(Boolean).join(' · ')} · {fmtDate(t.date)}
                  </span>
                </li>
              ))}
            </ul>
          )}
        </Card>
        <Card title="Haal ke events" action={<Link className="btn sm ghost" href="/events">All</Link>}>
          {A.events.length === 0 ? (
            <p className="u-muted">—</p>
          ) : (
            <ul style={{ listStyle: 'none', margin: 0, padding: 0 }}>
              {A.events.slice(0, 8).map((e) => (
                <li key={e.id} className="u-between" style={{ padding: '6px 0', borderBottom: '1px solid var(--line)' }}>
                  <Link className="u-link" href={'/events/' + e.id}>
                    {e.type}: {e.title}
                  </Link>
                  <span className="u-sm u-muted">
                    {fmtDate(e.date)} · {A.catalog.filter((c) => c.eventId === e.id).length} data
                  </span>
                </li>
              ))}
            </ul>
          )}
        </Card>
      </div>
    </>
  );
}
