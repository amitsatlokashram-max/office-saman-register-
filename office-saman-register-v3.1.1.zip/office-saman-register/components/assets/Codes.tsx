'use client';

// QR code (SVG) aur Code128 barcode. QR kholne pe asset ka profile khulta hai (login ke baad, sirf authorized log).

import { useEffect, useRef, useState } from 'react';
import QRCode from 'qrcode';
import JsBarcode from 'jsbarcode';

export function appBase(): string {
  const env = (process.env.NEXT_PUBLIC_APP_URL || '').trim().replace(/\/+$/, '');
  if (env) return env;
  return typeof window !== 'undefined' ? window.location.origin : '';
}
export const assetUrl = (assetId: string) => appBase() + '/a/' + encodeURIComponent(assetId);

const cache = new Map<string, string>();
export async function qrSvg(text: string, dark = '#000000'): Promise<string> {
  const k = dark + '|' + text;
  const c = cache.get(k);
  if (c) return c;
  const s = await QRCode.toString(text, { type: 'svg', margin: 0, errorCorrectionLevel: 'M', color: { dark, light: '#ffffff' } });
  cache.set(k, s);
  return s;
}

export function QR({ text, size, dark }: { text: string; size: string | number; dark?: string }) {
  const [svg, setSvg] = useState('');
  useEffect(() => {
    let live = true;
    qrSvg(text, dark).then((s) => live && setSvg(s));
    return () => {
      live = false;
    };
  }, [text, dark]);
  return <span className="qr" style={{ width: size, height: size, display: 'inline-block' }} dangerouslySetInnerHTML={{ __html: svg }} aria-label={'QR code ' + text} role="img" />;
}

export function Barcode({ text, height, width = '100%', showText = false }: { text: string; height: string | number; width?: string | number; showText?: boolean }) {
  const ref = useRef<SVGSVGElement>(null);
  useEffect(() => {
    if (!ref.current) return;
    try {
      JsBarcode(ref.current, text, { format: 'CODE128', displayValue: showText, margin: 0, height: 60, width: 2, fontSize: 18, background: '#ffffff', lineColor: '#000000' });
      ref.current.setAttribute('preserveAspectRatio', 'none');
    } catch {
      /* text me galat character */
    }
  }, [text, showText]);
  return (
    <span className="bc" style={{ width, height }}>
      <svg ref={ref} role="img" aria-label={'Barcode ' + text} />
    </span>
  );
}
