'use client';

// Drive issue / return / transfer form (transaction se) aur chhapne layak parchi (receipt).

import { useEffect, useMemo, useState } from 'react';
import { createPortal } from 'react-dom';
import { ArrowLeftRight, CheckCircle2, Printer } from 'lucide-react';
import { motion } from 'motion/react';
import { allowedKinds, moveDrive } from '@/lib/assets/db';
import { gb, locLabel, whereIs } from '@/lib/assets/model';
import { CONDITIONS, DRIVE_STATUS_LABEL, TRANSFER_LABEL, type Drive, type Loc, type Transfer, type TransferKind } from '@/lib/assets/types';
import { num, today } from '@/lib/calc';
import { useReg } from '../context';
import { Field, Modal, fmtDate, fmtTime, useBusy } from '../ui';
import { LocSelect } from './pickers';
import { useAssets } from './store';

const NEED_PERSON: TransferKind[] = ['issue', 'temp_issue', 'repair'];
const VERB: Record<TransferKind, string> = {
  issue: 'Issue drive',
  temp_issue: 'Issue temporarily',
  return: 'Receive back',
  dept_transfer: 'Transfer department',
  location_transfer: 'Move location',
  repair: 'Send for repair',
  damaged: 'Mark damaged',
  lost: 'Mark lost',
  retire: 'Retire drive',
  restore: 'Back in service',
};

export function MoveDriveModal({
  drive,
  initialKind,
  onClose,
}: {
  drive: Drive | null;
  initialKind?: TransferKind;
  onClose: () => void;
}) {
  const A = useAssets();
  const { me, toast } = useReg();
  const kinds = drive ? allowedKinds(drive.status) : [];
  const [kind, setKind] = useState<TransferKind>('issue');
  const [name, setName] = useState('');
  const [dept, setDept] = useState('');
  const [loc, setLoc] = useState('');
  const [place, setPlace] = useState('');
  const [purpose, setPurpose] = useState('');
  const [date, setDate] = useState(today());
  const [ret, setRet] = useState('');
  const [cond, setCond] = useState('');
  const [used, setUsed] = useState('');
  const [notes, setNotes] = useState('');
  const [err, setErr] = useState('');
  const [doneId, setDoneId] = useState('');
  const [busy, run] = useBusy();
  const [printT, setPrintT] = useState<Transfer | null>(null);

  useEffect(() => {
    if (!drive) return;
    const k = initialKind && kinds.includes(initialKind) ? initialKind : kinds[0] || 'issue';
    setKind(k);
    setName('');
    setDept(k === 'dept_transfer' ? '' : drive.dept);
    setLoc(drive.locationId);
    setPlace(drive.place);
    setPurpose('');
    setDate(today());
    setRet('');
    setCond(drive.condition);
    setUsed(drive.usedGB ? String(drive.usedGB) : '');
    setNotes('');
    setErr('');
    setDoneId('');
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [drive?.id, initialKind]);

  const doneT = useMemo(() => (doneId ? A.transfers.find((t) => t.id === doneId) || null : null), [doneId, A.transfers]);

  if (!drive) return null;

  const submit = () =>
    run(async () => {
      setErr('');
      try {
        const id = await moveDrive(
          drive.id,
          {
            kind,
            to: { name, dept, locationId: loc, place },
            purpose,
            date,
            expectedReturn: kind === 'issue' || kind === 'temp_issue' || kind === 'repair' ? ret : '',
            condition: cond,
            usedGB: used.trim() === '' ? null : Math.max(0, num(used)),
            notes,
          },
          me,
          A.slotIds,
        );
        toast('✓ ' + drive.displayName + ': ' + TRANSFER_LABEL[kind]);
        setDoneId(id);
      } catch (e) {
        setErr(e instanceof Error ? e.message : 'Save nahi hua. Net check karke dobara try karo (custody change ke liye internet zaroori hai).');
      }
    });

  if (doneId) {
    return (
      <Modal
        open
        onClose={onClose}
        size="sm"
        title="Ho gaya"
        foot={
          <>
            <button type="button" className="btn" onClick={() => doneT && setPrintT(doneT)} disabled={!doneT}>
              <Printer aria-hidden className="ic" /> Print receipt
            </button>
            <button type="button" className="btn primary" onClick={onClose}>
              Done
            </button>
          </>
        }
      >
        <div className="u-empty" style={{ padding: 10 }}>
          <motion.div className="art" initial={{ scale: 0.4, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} transition={{ type: 'spring', stiffness: 380, damping: 18 }} style={{ background: 'var(--ok-soft)', color: 'var(--ok)' }}>
            <CheckCircle2 aria-hidden />
          </motion.div>
          <h3>
            {drive.displayName}: {TRANSFER_LABEL[kind]}
          </h3>
          <p>Custody history me record ho gaya. Lene wale ka sign chahiye to receipt print karo.</p>
        </div>
        {printT && <ReceiptPrinter t={printT} drive={drive} locs={A.locMap} onDone={() => setPrintT(null)} />}
      </Modal>
    );
  }

  return (
    <Modal
      open
      onClose={onClose}
      title={drive.displayName + ' — custody'}
      sub={'Abhi: ' + DRIVE_STATUS_LABEL[drive.status] + ' · ' + whereIs(drive, A.locMap)}
      onSubmit={submit}
      foot={
        <>
          <button type="button" className="btn" onClick={onClose}>
            Cancel
          </button>
          <button type="submit" className="btn primary" disabled={busy || !kinds.length}>
            <ArrowLeftRight aria-hidden className="ic" /> {busy ? 'Saving…' : VERB[kind]}
          </button>
        </>
      }
    >
      {err && <div className="ferr">{err}</div>}
      <div className="fgrid">
        <Field label="Kya karna hai" span>
          <select value={kind} onChange={(e) => setKind(e.target.value as TransferKind)}>
            {kinds.map((k) => (
              <option key={k} value={k}>
                {TRANSFER_LABEL[k]}
              </option>
            ))}
          </select>
        </Field>
        {(NEED_PERSON.includes(kind) || kind === 'dept_transfer') && (
          <Field label={kind === 'repair' ? 'Repair kahan / kisko' : kind === 'dept_transfer' ? 'Naya holder (optional)' : 'Kisko de rahe ho'}>
            <input value={name} onChange={(e) => setName(e.target.value)} list="dl-people" required={kind === 'issue' || kind === 'temp_issue'} maxLength={80} autoFocus />
          </Field>
        )}
        {(NEED_PERSON.includes(kind) || kind === 'dept_transfer') && (
          <Field label="Department">
            <input value={dept} onChange={(e) => setDept(e.target.value)} list="dl-depts" required={kind === 'dept_transfer'} maxLength={60} />
          </Field>
        )}
        {(kind === 'location_transfer' || kind === 'return' || kind === 'restore') && (
          <Field label={kind === 'location_transfer' ? 'Nayi jagah' : 'Wapas kahan rakhi (jagah)'} span hint="Jaise: Main Media Office, Delhi Office, Almari 2">
            <input value={place} onChange={(e) => setPlace(e.target.value)} list="dl-places" maxLength={120} />
          </Field>
        )}
        {kind === 'location_transfer' && A.locs.length > 0 && (
          <Field label="Rack / slot (optional)" span>
            <LocSelect value={loc} onChange={setLoc} forDriveId={drive.id} />
          </Field>
        )}
        <Field label="Tareekh">
          <input type="date" value={date} onChange={(e) => setDate(e.target.value)} required />
        </Field>
        {(kind === 'issue' || kind === 'temp_issue' || kind === 'repair') && (
          <Field label={kind === 'temp_issue' ? 'Wapsi ki tareekh (zaroori)' : 'Wapsi ki tareekh (optional)'}>
            <input type="date" value={ret} min={date} onChange={(e) => setRet(e.target.value)} required={kind === 'temp_issue'} />
          </Field>
        )}
        <Field label="Condition">
          <select value={cond} onChange={(e) => setCond(e.target.value)}>
            {CONDITIONS.map((c) => (
              <option key={c}>{c}</option>
            ))}
          </select>
        </Field>
        <Field label="Used space abhi (GB)" hint={'Capacity ' + gb(drive.capacityGB)}>
          <input type="number" min={0} step="any" value={used} onChange={(e) => setUsed(e.target.value)} />
        </Field>
        <Field label="Purpose / kaam" span>
          <input value={purpose} onChange={(e) => setPurpose(e.target.value)} maxLength={200} placeholder="Jaise: Satsang live 12 Dec ki recording" />
        </Field>
        <Field label="Note" span>
          <textarea value={notes} onChange={(e) => setNotes(e.target.value)} rows={2} maxLength={1000} />
        </Field>
      </div>
    </Modal>
  );
}

/** Receipt ko portal me daal ke print karta hai (sirf parchi chhapti hai). */
export function ReceiptPrinter({ t, drive, locs, onDone }: { t: Transfer; drive: Drive; locs: Map<string, Loc>; onDone: () => void }) {
  const [el, setEl] = useState<HTMLElement | null>(null);
  useEffect(() => {
    setEl(document.body);
  }, []);
  useEffect(() => {
    if (!el) return;
    const html = document.documentElement;
    html.classList.add('print-receipt');
    const done = () => {
      html.classList.remove('print-receipt');
      onDone();
    };
    window.addEventListener('afterprint', done, { once: true });
    const h = setTimeout(() => window.print(), 150);
    return () => {
      clearTimeout(h);
      window.removeEventListener('afterprint', done);
      html.classList.remove('print-receipt');
    };
  }, [el, onDone]);
  if (!el) return null;
  return createPortal(
    <div className="receipt-wrap">
      <Receipt t={t} drive={drive} locs={locs} />
    </div>,
    el,
  );
}

export function Receipt({ t, drive, locs }: { t: Transfer; drive: Drive; locs: Map<string, Loc> }) {
  const isReturn = t.kind === 'return' || t.kind === 'restore';
  const row = (k: string, v: string) =>
    v ? (
      <tr>
        <th style={{ textAlign: 'left', padding: '5pt 8pt', width: '34%', background: '#F3F4F8', border: '0.5pt solid #ccc', fontWeight: 600 }}>{k}</th>
        <td style={{ padding: '5pt 8pt', border: '0.5pt solid #ccc' }}>{v}</td>
      </tr>
    ) : null;
  return (
    <div style={{ fontFamily: 'Inter, "Noto Sans Devanagari", sans-serif', color: '#111', fontSize: '10.5pt', padding: '4mm' }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-end', borderBottom: '2pt solid #4F46E5', paddingBottom: '6pt', marginBottom: '10pt' }}>
        <div>
          <div style={{ fontSize: '9pt', color: '#555', fontWeight: 600 }}>Office Saman Register</div>
          <div style={{ fontSize: '18pt', fontWeight: 800 }}>{t.kind === 'issue' ? 'Drive Issue Receipt' : t.kind === 'temp_issue' ? 'Temporary Issue Receipt' : isReturn ? 'Drive Return Receipt' : 'Drive Movement Receipt'}</div>
        </div>
        <div style={{ textAlign: 'right', fontSize: '9pt', color: '#444' }}>
          <div>Receipt: {t.id.slice(0, 8).toUpperCase()}</div>
          <div>{fmtTime(t.at)}</div>
        </div>
      </div>
      <table style={{ width: '100%', borderCollapse: 'collapse', marginBottom: '12pt' }}>
        <tbody>
          {row('Drive', drive.displayName + ' (' + drive.assetId + ')')}
          {row('Type / capacity', [drive.type, drive.brand, drive.model, gb(drive.capacityGB)].filter(Boolean).join(' · '))}
          {row('Serial no.', drive.serial)}
          {row('Action', TRANSFER_LABEL[t.kind])}
          {row('Date', fmtDate(t.date))}
          {row('From', [t.from.name, t.from.dept].filter(Boolean).join(' / '))}
          {row('To', [t.to.name, t.to.dept].filter(Boolean).join(' / '))}
          {row('Place', [t.to.place, locLabel(locs, t.to.locationId)].filter(Boolean).join(' · '))}
          {row('Purpose', t.purpose)}
          {row('Expected return', t.expectedReturn ? fmtDate(t.expectedReturn) : '')}
          {row('Condition', t.condition)}
          {row('Used space', t.usedGB ? gb(t.usedGB) + ' of ' + gb(drive.capacityGB) : '')}
          {row('Note', t.notes)}
          {row('Entry by', t.byName)}
        </tbody>
      </table>
      <p style={{ fontSize: '9pt', color: '#444', marginBottom: '34pt' }}>
        {isReturn
          ? 'Upar likhi drive store me wapas li gayi. Condition aur data check karke sign karein.'
          : 'Upar likhi drive upar likhe kaam ke liye di gayi. Lene wala iski suraksha aur samay par wapsi ka zimmedar hai. Data delete / format karne se pehle store ko batayein.'}
      </p>
      <div style={{ display: 'flex', justifyContent: 'space-between', gap: '24pt' }}>
        {['Dene wale ka sign (Issued by)', 'Lene wale ka sign (Received by)'].map((s) => (
          <div key={s} style={{ flex: 1, borderTop: '0.8pt solid #333', paddingTop: '4pt', fontSize: '9pt', color: '#333' }}>
            {s}
          </div>
        ))}
      </div>
    </div>
  );
}
