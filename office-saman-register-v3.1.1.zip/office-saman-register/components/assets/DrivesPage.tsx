'use client';

import Link from 'next/link';
import { useRouter, useSearchParams } from 'next/navigation';
import { motion, useReducedMotion } from 'motion/react';
import { useEffect, useMemo, useState } from 'react';
import { ArrowLeftRight, HardDrive, LayoutGrid, Plus, QrCode, Server, Table2, Trash2 } from 'lucide-react';
import { softDeleteDrive } from '@/lib/assets/db';
import { almostFull, freeGB, gb, isOut, locLabel, matches, overdue, usedPct, whereIs } from '@/lib/assets/model';
import { DRIVE_STATUS, DRIVE_STATUS_LABEL, DRIVE_STATUS_TONE, DRIVE_TYPES, DRIVE_TYPE_LABEL, type Drive } from '@/lib/assets/types';
import { distinct, today } from '@/lib/calc';
import { useReg } from '../context';
import { DataTable, type Col } from '../ui/DataTable';
import { Badge, Bar, Card, Empty, PageHeader, Segmented, Skeleton, Stat, fmtDate } from '../ui';
import { MoveDriveModal } from './Custody';
import { DriveForm } from './DriveForm';
import { RackLegend, RackView } from './RackView';
import { useAssets } from './store';

type ViewMode = 'grid' | 'table' | 'rack';

export function DrivesPage() {
  const A = useAssets();
  const { me, toast } = useReg();
  const router = useRouter();
  const sp = useSearchParams();
  const reduce = useReducedMotion();

  const [mode, setMode] = useState<ViewMode>('grid');
  const [q, setQ] = useState('');
  const [type, setType] = useState('');
  const [st, setSt] = useState('');
  const [dept, setDept] = useState('');
  const [holder, setHolder] = useState('');
  const [flag, setFlag] = useState('');
  const [formOpen, setFormOpen] = useState(false);
  const [moveFor, setMoveFor] = useState<Drive | null>(null);

  useEffect(() => {
    try {
      const m = localStorage.getItem('drives-view') as ViewMode | null;
      if (m === 'grid' || m === 'table' || m === 'rack') setMode(m);
    } catch {
      /* ignore */
    }
  }, []);
  useEffect(() => {
    if (sp.get('new') === '1' && A.can('drives', 'create')) setFormOpen(true);
    const h = sp.get('holder');
    if (h) setHolder(h);
    const f = sp.get('flag');
    if (f) setFlag(f);
    const s = sp.get('status');
    if (s) setSt(s);
    const v = sp.get('view');
    if (v === 'grid' || v === 'table' || v === 'rack') setMode(v);
  }, [sp, A]);
  const setView = (m: ViewMode) => {
    setMode(m);
    try {
      localStorage.setItem('drives-view', m);
    } catch {
      /* ignore */
    }
  };

  const t = today();
  const filterFn = useMemo(
    () => (d: Drive) =>
      (!q || matches([d.displayName, d.assetId, d.brand, d.model, d.serial, d.holder?.name, d.holder?.dept, d.dept, d.description, whereIs(d, A.locMap)].join(' '), q)) &&
      (!type || d.type === type) &&
      (!st || d.status === st) &&
      (!dept || d.dept === dept || d.holder?.dept === dept) &&
      (!holder || (d.holder?.name || '').toLowerCase() === holder.toLowerCase()) &&
      (!flag ||
        (flag === 'full' && almostFull(d)) ||
        (flag === 'overdue' && overdue(d, t)) ||
        (flag === 'out' && isOut(d.status)) ||
        (flag === 'available' && d.status === 'in_store') ||
        (flag === 'noloc' && !d.locationId && !d.place) ||
        (flag === 'unscanned' && !d.lastScanAt)),
    [q, type, st, dept, holder, flag, A.locMap, t],
  );
  const list = useMemo(() => A.drives.filter(filterFn), [A.drives, filterFn]);
  const depts = distinct(A.drives.flatMap((d) => [d.dept, d.holder?.dept]));
  const holders = distinct(A.drives.map((d) => d.holder?.name));
  const racks = A.locs.filter((l) => l.kind === 'rack');

  const tot = A.drives.reduce(
    (s, d) => ({ cap: s.cap + d.capacityGB, used: s.used + d.usedGB, out: s.out + (isOut(d.status) ? 1 : 0), avail: s.avail + (d.status === 'in_store' ? 1 : 0) }),
    { cap: 0, used: 0, out: 0, avail: 0 },
  );

  const cols: Col<Drive>[] = [
    { key: 'name', label: 'Drive', value: (d) => d.markNo, render: (d) => <Link href={'/drives/' + d.id} className="u-link">{d.displayName}</Link>, card: false },
    { key: 'asset', label: 'Asset ID', value: (d) => d.assetId, render: (d) => <span className="u-mono">{d.assetId}</span> },
    { key: 'type', label: 'Type', value: (d) => d.type, render: (d) => d.type + (d.form === 'internal' ? ' · int' : ''), card: true },
    { key: 'brand', label: 'Brand / model', value: (d) => d.brand + ' ' + d.model, render: (d) => [d.brand, d.model].filter(Boolean).join(' ') || '—' },
    { key: 'serial', label: 'Serial', value: (d) => d.serial, render: (d) => <span className="u-mono">{d.serial || '—'}</span>, hidden: true },
    { key: 'cap', label: 'Capacity', num: true, value: (d) => d.capacityGB, render: (d) => gb(d.capacityGB), card: true },
    {
      key: 'used',
      label: 'Used',
      value: (d) => Math.round(usedPct(d)),
      render: (d) => (
        <div style={{ minWidth: 110 }}>
          <Bar pct={usedPct(d)} size="sm" />
          <span className="u-sm u-muted">
            {gb(d.usedGB)} · {Math.round(usedPct(d))}%
          </span>
        </div>
      ),
    },
    { key: 'free', label: 'Free', num: true, value: (d) => freeGB(d), render: (d) => gb(freeGB(d)), hidden: true },
    { key: 'status', label: 'Status', value: (d) => d.status, render: (d) => <Badge tone={DRIVE_STATUS_TONE[d.status]}>{DRIVE_STATUS_LABEL[d.status]}</Badge>, card: true },
    { key: 'holder', label: 'Holder', value: (d) => d.holder?.name || '', render: (d) => (d.holder ? d.holder.name + (d.holder.dept ? ' / ' + d.holder.dept : '') : '—'), card: true },
    { key: 'ret', label: 'Return by', value: (d) => d.holder?.expectedReturn || '', render: (d) => (d.holder?.expectedReturn ? <span className={overdue(d, t) ? 'err' : ''}>{fmtDate(d.holder.expectedReturn)}</span> : '—'), hidden: true },
    { key: 'dept', label: 'Department', value: (d) => d.dept, render: (d) => d.dept || '—', hidden: true },
    { key: 'loc', label: 'Where', value: (d) => whereIs(d, A.locMap), render: (d) => whereIs(d, A.locMap), card: true },
    { key: 'scan', label: 'Last scan', value: (d) => d.lastScanAt, render: (d) => (d.lastScanAt ? fmtDate(d.lastScanAt) : '—'), hidden: true },
    { key: 'warranty', label: 'Warranty', value: (d) => d.warrantyTill, render: (d) => (d.warrantyTill ? fmtDate(d.warrantyTill) : '—'), hidden: true },
    { key: 'price', label: 'Price', num: true, value: (d) => d.price, render: (d) => (d.price ? '₹' + d.price.toLocaleString('en-IN') : '—'), hidden: true },
  ];

  if (!A.loaded.drives) {
    return (
      <>
        <PageHeader title="Hard Disks & SSDs" />
        <div className="u-grid auto">
          {Array.from({ length: 8 }, (_, i) => (
            <div className="u-card pad" key={i}>
              <Skeleton h={44} w={44} r={13} />
              <div style={{ height: 12 }} />
              <Skeleton h={14} w="60%" />
              <div style={{ height: 8 }} />
              <Skeleton h={8} />
            </div>
          ))}
        </div>
      </>
    );
  }

  return (
    <>
      <PageHeader
        title="Hard Disks & SSDs"
        sub="Har physical drive: Mark number, kiske paas hai, kahan rakhi hai, kitna bhara hai."
        actions={
          <>
            {A.can('stickers', 'view') && (
              <Link href="/stickers" className="btn">
                <QrCode aria-hidden className="ic" /> Stickers
              </Link>
            )}
            {A.can('drives', 'create') && (
              <button type="button" className="btn primary" onClick={() => setFormOpen(true)}>
                <Plus aria-hidden className="ic" /> Register drives
              </button>
            )}
          </>
        }
      />

      <div className="u-grid c4">
        <Stat index={0} label="Total drives" value={A.drives.length} icon={HardDrive} sub={DRIVE_TYPES.map((x) => A.drives.filter((d) => d.type === x).length + ' ' + x).filter((s) => !s.startsWith('0 ')).join(' · ') || '—'} onClick={() => setFlag('')} />
        <Stat index={1} label="Total capacity" value={tot.cap} format={gb} icon={Server} tone="violet" sub={gb(tot.used) + ' used · ' + gb(Math.max(0, tot.cap - tot.used)) + ' free'} />
        <Stat index={2} label="Available in store" value={tot.avail} icon={LayoutGrid} tone="green" onClick={() => setFlag('available')} />
        <Stat index={3} label="Issued out" value={tot.out} icon={ArrowLeftRight} tone="amber" sub={A.drives.filter((d) => overdue(d, t)).length + ' overdue'} onClick={() => setFlag('out')} />
      </div>

      <Card>
        <div className="u-toolbar" style={{ padding: 14 }}>
          {mode !== 'table' && (
            <label className="u-search">
              <input type="search" value={q} onChange={(e) => setQ(e.target.value)} placeholder="Mark, serial, brand, holder, location…" aria-label="Search drives" style={{ paddingLeft: 12 }} />
            </label>
          )}
          <select value={type} onChange={(e) => setType(e.target.value)} aria-label="Type" className={type ? 'set' : ''}>
            <option value="">All types</option>
            {DRIVE_TYPES.map((x) => (
              <option key={x} value={x}>
                {DRIVE_TYPE_LABEL[x]}
              </option>
            ))}
          </select>
          <select value={st} onChange={(e) => setSt(e.target.value)} aria-label="Status">
            <option value="">All status</option>
            {DRIVE_STATUS.map((x) => (
              <option key={x} value={x}>
                {DRIVE_STATUS_LABEL[x]}
              </option>
            ))}
          </select>
          {depts.length > 0 && (
            <select value={dept} onChange={(e) => setDept(e.target.value)} aria-label="Department">
              <option value="">All departments</option>
              {depts.map((x) => (
                <option key={x}>{x}</option>
              ))}
            </select>
          )}
          {holders.length > 0 && (
            <select value={holder} onChange={(e) => setHolder(e.target.value)} aria-label="Holder">
              <option value="">Anyone</option>
              {holders.map((x) => (
                <option key={x}>{x}</option>
              ))}
            </select>
          )}
          <select value={flag} onChange={(e) => setFlag(e.target.value)} aria-label="Quick filter">
            <option value="">No quick filter</option>
            <option value="available">Available in store</option>
            <option value="out">Issued out</option>
            <option value="overdue">Overdue return</option>
            <option value="full">Almost full (90%+)</option>
            <option value="noloc">Jagah nahi likhi</option>
            <option value="unscanned">Never scanned</option>
          </select>
          {(q || type || st || dept || holder || flag) && (
            <button
              type="button"
              className="btn sm ghost"
              onClick={() => {
                setQ('');
                setType('');
                setSt('');
                setDept('');
                setHolder('');
                setFlag('');
                router.replace('/drives');
              }}
            >
              Clear
            </button>
          )}
          <span style={{ marginLeft: 'auto' }} />
          <Segmented
            label="View"
            value={mode}
            onChange={setView}
            options={[
              { value: 'grid', label: 'Grid', icon: LayoutGrid },
              { value: 'table', label: 'Table', icon: Table2 },
              { value: 'rack', label: 'Rack', icon: Server },
            ]}
          />
        </div>
      </Card>

      {A.drives.length === 0 ? (
        <Card>
          <Empty
            icon={HardDrive}
            title="Abhi koi drive register nahi hai"
            action={
              A.can('drives', 'create') && (
                <button type="button" className="btn primary" onClick={() => setFormOpen(true)}>
                  <Plus aria-hidden className="ic" /> Pehli drive (ya kai ek saath) register karo
                </button>
              )
            }
          >
            Mark 1, Mark 2… jaise naam se har Hard Disk / SSD register karo. Phir uska sticker, custody aur andar ka data yahin dikhega.
          </Empty>
        </Card>
      ) : mode === 'grid' ? (
        list.length === 0 ? (
          <Card>
            <Empty icon={HardDrive} title="Is filter me koi drive nahi" />
          </Card>
        ) : (
          <div className="u-grid auto">
            {list.map((d, i) => (
              <motion.div key={d.id} initial={reduce ? false : { opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: Math.min(i, 16) * 0.03, duration: 0.3 }} style={{ display: 'grid' }}>
                <DriveCard d={d} onMove={A.can('drives', 'transfer') ? () => setMoveFor(d) : undefined} />
              </motion.div>
            ))}
          </div>
        )
      ) : mode === 'table' ? (
        <DataTable
          id="drives"
          rows={list}
          cols={cols}
          exportName="hard-disks"
          canExport={A.can('drives', 'export')}
          searchText={(d) => [d.displayName, d.assetId, d.brand, d.model, d.serial, d.holder?.name, d.dept, whereIs(d, A.locMap)].join(' ')}
          onRow={(d) => router.push('/drives/' + d.id)}
          initialSort={{ key: 'name', dir: 'asc' }}
          cardTitle={(d) => (
            <>
              <b>{d.displayName}</b> <span className="u-faint u-sm">{d.assetId}</span>
            </>
          )}
          bulk={(sel, clear) => (
            <>
              {A.can('stickers', 'view') && (
                <button type="button" className="btn sm" onClick={() => router.push('/stickers?ids=' + sel.map((d) => d.id).join(','))}>
                  <QrCode aria-hidden className="ic" /> Print stickers
                </button>
              )}
              {A.can('drives', 'delete') && (
                <button
                  type="button"
                  className="btn sm quiet-danger"
                  onClick={async () => {
                    const ok = sel.filter((d) => !isOut(d.status));
                    if (!ok.length) return toast('Issue hui drives recycle bin me nahi ja sakti.');
                    if (!window.confirm(ok.length + ' drive(s) recycle bin me bhejni hai?')) return;
                    for (const d of ok) await softDeleteDrive(d, me).catch(() => {});
                    toast('✓ ' + ok.length + ' moved to recycle bin');
                    clear();
                  }}
                >
                  <Trash2 aria-hidden className="ic" /> Recycle bin
                </button>
              )}
            </>
          )}
        />
      ) : (
        <div className="rack">
          <RackLegend />
          {racks.length === 0 ? (
            <Card>
              <Empty icon={Server} title="Abhi koi rack nahi bana" action={<Link href="/locations" className="btn primary">Locations me rack banao</Link>}>
                Office → Room → Rack → Shelf → Slot banao, phir har drive ko slot me rakho.
              </Empty>
            </Card>
          ) : (
            racks.map((r) => <RackView key={r.id} rack={r} filter={filterFn} />)
          )}
          {list.filter((d) => !d.locationId).length > 0 && (
            <Card title="Bina location wali drives" sub="Inko rack slot me rakho taaki dhoondhna aasaan ho">
              <div className="u-row">
                {list
                  .filter((d) => !d.locationId)
                  .map((d) => (
                    <Link key={d.id} href={'/drives/' + d.id} className="u-chip">
                      {d.displayName}
                    </Link>
                  ))}
              </div>
            </Card>
          )}
        </div>
      )}

      <DriveForm
        open={formOpen}
        drive={null}
        onClose={() => {
          setFormOpen(false);
          if (sp.get('new')) router.replace('/drives');
        }}
      />
      {moveFor && <MoveDriveModal drive={A.driveMap.get(moveFor.id) || moveFor} onClose={() => setMoveFor(null)} />}
    </>
  );
}

export function DriveCard({ d, onMove }: { d: Drive; onMove?: () => void }) {
  const A = useAssets();
  const t = today();
  const od = overdue(d, t);
  return (
    <div className="u-card hover" style={{ position: 'relative', display: 'flex', flexDirection: 'column' }}>
      <Link href={'/drives/' + d.id} className="d-card" style={{ textDecoration: 'none' }}>
        <div className="d-card-top">
          <span className={'d-ic tone-' + DRIVE_STATUS_TONE[d.status]}>
            <HardDrive aria-hidden />
          </span>
          <div style={{ minWidth: 0, flex: 1 }}>
            <div className="d-name">{d.displayName}</div>
            <div className="d-sub u-ell">{[d.assetId, d.brand, d.type].filter(Boolean).join(' · ')}</div>
          </div>
        </div>
        <div>
          <div className="d-meta" style={{ marginBottom: 5 }}>
            <span>{gb(d.usedGB)} used</span>
            <span>
              <b style={{ color: 'var(--ink)' }}>{gb(d.capacityGB)}</b>
            </span>
          </div>
          <Bar pct={usedPct(d)} />
        </div>
        <div className="u-between">
          <Badge tone={od ? 'red' : DRIVE_STATUS_TONE[d.status]}>{od ? 'Overdue' : DRIVE_STATUS_LABEL[d.status]}</Badge>
          <span className="u-sm u-muted u-ell" style={{ maxWidth: '55%' }}>
            {whereIs(d, A.locMap)}
          </span>
        </div>
      </Link>
      {onMove && (
        <button type="button" className="btn sm" onClick={onMove} style={{ margin: '0 16px 16px' }}>
          <ArrowLeftRight aria-hidden className="ic" /> {d.status === 'in_store' ? 'Issue' : isOut(d.status) ? 'Return / transfer' : 'Update status'}
        </button>
      )}
    </div>
  );
}
