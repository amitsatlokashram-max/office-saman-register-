'use client';

// Settings ke naye hisse: Profile (dikhne wala naam), Theme (Aurora…), Naming series (SSD Mark 80…).

import { useEffect, useState } from 'react';
import { Monitor, Moon, Save, Sun } from 'lucide-react';
import { saveNaming, saveProfile } from '@/lib/assets/db';
import { seriesName } from '@/lib/assets/model';
import { SERIES, SERIES_LABEL, type NamingSeries, type SeriesKey } from '@/lib/assets/types';
import { AMBIENT_KEY, COLOR_KEY, DENSITY_KEY, MODE_KEY, PALETTES, readTheme, setThemePref, type Mode } from '@/lib/theme';
import { useAssets } from '../assets/store';
import { useReg } from '../context';
import { Card, Field, Segmented, useBusy } from '../ui';

export function ProfilePanel({ displayName }: { displayName: string }) {
  const { me, toast } = useReg();
  const [name, setName] = useState(displayName);
  const [busy, run] = useBusy();
  useEffect(() => setName(displayName), [displayName]);
  return (
    <Card title="Profile" sub="App me dikhne wala naam. Login (Google account) nahi badalta.">
      <form
        className="u-row"
        style={{ flexWrap: 'nowrap' }}
        onSubmit={(e) => {
          e.preventDefault();
          if (!me?.uid || !name.trim()) return;
          run(() =>
            saveProfile(me.uid, name).then(
              () => toast('✓ Naam saved'),
              () => toast('Save nahi hua'),
            ),
          );
        }}
      >
        <input value={name} onChange={(e) => setName(e.target.value)} maxLength={60} aria-label="Display name" />
        <button type="submit" className="btn primary" disabled={busy}>
          <Save aria-hidden className="ic" /> Save
        </button>
      </form>
      <p className="hint" style={{ marginTop: 8 }}>{me?.email}</p>
    </Card>
  );
}

export function ThemePanel() {
  const [t, setT] = useState(readTheme());
  useEffect(() => setT(readTheme()), []);
  const upd = (k: string, v: string) => {
    setThemePref(k, v);
    setT(readTheme());
  };
  return (
    <Card title="Theme" sub="Is browser me yaad rehta hai">
      <div className="u-stack">
        <Segmented
          label="Mode"
          value={t.mode}
          onChange={(m: Mode) => upd(MODE_KEY, m)}
          options={[
            { value: 'light', label: 'Aurora Light', icon: Sun },
            { value: 'dark', label: 'Midnight', icon: Moon },
            { value: 'system', label: 'System', icon: Monitor },
          ]}
        />
        <div className="theme-cards">
          {PALETTES.map((p) => (
            <button key={p.id} type="button" className="theme-card" aria-pressed={t.color === p.id} onClick={() => upd(COLOR_KEY, p.id)}>
              <span className="sw" style={{ background: 'linear-gradient(135deg,' + p.a + ',' + p.b + ')' }} />
              <span className="u-sm u-strong">{p.label}</span>
            </button>
          ))}
        </div>
        <div className="fgrid">
          <Field label="Density">
            <select value={t.density} onChange={(e) => upd(DENSITY_KEY, e.target.value)}>
              <option value="compact">Compact (zyada data ek screen pe)</option>
              <option value="comfortable">Comfortable</option>
              <option value="spacious">Spacious (bade akshar)</option>
            </select>
          </Field>
          <label className="u-check" style={{ marginTop: 24 }}>
            <input type="checkbox" checked={t.ambient} onChange={(e) => upd(AMBIENT_KEY, e.target.checked ? '1' : '0')} /> Animated background
          </label>
        </div>
      </div>
    </Card>
  );
}

export function NamingPanel() {
  const A = useAssets();
  const { me, toast } = useReg();
  const [v, setV] = useState<Record<SeriesKey, NamingSeries>>(A.naming);
  const [busy, run] = useBusy();
  useEffect(() => setV(A.naming), [A.naming]);
  const can = A.can('drives', 'edit');
  const set = (k: SeriesKey, p: Partial<NamingSeries>) => setV((x) => ({ ...x, [k]: { ...x[k], ...p } }));
  return (
    <Card
      title="Naming series (drive ke naam)"
      sub="Nayi drive aate hi agla number apne aap: SSD Mark 80, 81… Har series ka number alag."
      action={
        can && (
          <button
            type="button"
            className="btn sm primary"
            disabled={busy}
            onClick={() =>
              run(() =>
                saveNaming(v, me).then(
                  () => toast('✓ Naming saved'),
                  () => toast('Save nahi hua'),
                ),
              )
            }
          >
            <Save aria-hidden className="ic" /> Save
          </button>
        )
      }
    >
      <table className="u-table">
        <thead>
          <tr>
            <th>Series</th>
            <th>Prefix</th>
            <th>Suffix</th>
            <th>Digits</th>
            <th>Start</th>
            <th>Next name</th>
          </tr>
        </thead>
        <tbody>
          {SERIES.map((k) => {
            const used = A.allDrives.filter((d) => d.series === k).reduce((m, d) => Math.max(m, d.markNo), 0);
            return (
              <tr key={k}>
                <td>
                  <b>{SERIES_LABEL[k]}</b>
                  <div className="u-faint u-sm">{A.allDrives.filter((d) => d.series === k).length} drives</div>
                </td>
                <td>
                  <input value={v[k].prefix} disabled={!can} onChange={(e) => set(k, { prefix: e.target.value })} style={{ width: 140 }} aria-label={k + ' prefix'} />
                </td>
                <td>
                  <input value={v[k].suffix} disabled={!can} onChange={(e) => set(k, { suffix: e.target.value })} style={{ width: 80 }} aria-label={k + ' suffix'} />
                </td>
                <td>
                  <input type="number" min={0} max={6} value={v[k].pad} disabled={!can} onChange={(e) => set(k, { pad: Math.max(0, Math.min(6, Number(e.target.value) || 0)) })} style={{ width: 70 }} aria-label={k + ' digits'} />
                </td>
                <td>
                  <input type="number" min={1} value={v[k].start} disabled={!can} onChange={(e) => set(k, { start: Math.max(1, Number(e.target.value) || 1) })} style={{ width: 90 }} aria-label={k + ' start'} />
                </td>
                <td>
                  <b style={{ color: 'var(--accent-text)' }}>{seriesName(v[k], Math.max(used + 1, v[k].start))}</b>
                </td>
              </tr>
            );
          })}
        </tbody>
      </table>
      <p className="hint" style={{ marginTop: 8 }}>
        Prefix ke baad space chahiye to prefix me space bhi likho (jaise &ldquo;SSD Mark &rdquo;). Purani drives ka naam nahi badalta. Ek hi series me do drives ka ek number nahi ho sakta (transaction se check).
      </p>
    </Card>
  );
}
