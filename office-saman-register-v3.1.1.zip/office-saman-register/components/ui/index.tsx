'use client';

// Reusable UI parts: Card, Stat (animated counter), Badge, Bar, Empty, Skeleton, Tabs, Segmented, PageHeader, Modal, Confirm.

import { animate, motion, useInView, useReducedMotion } from 'motion/react';
import { useEffect, useId, useRef, useState, type ReactNode } from 'react';
import Link from 'next/link';
import { X, type LucideIcon } from 'lucide-react';
import type { Tone } from '@/lib/assets/types';
import { Dialog } from '../Dialog';

export function PageHeader({ title, sub, actions }: { title: ReactNode; sub?: ReactNode; actions?: ReactNode }) {
  return (
    <header className="u-head">
      <div>
        <h1>{title}</h1>
        {sub && <p>{sub}</p>}
      </div>
      {actions && <div className="u-head-a">{actions}</div>}
    </header>
  );
}

export function Card({
  title,
  sub,
  action,
  children,
  className = '',
  pad,
  hover,
}: {
  title?: ReactNode;
  sub?: ReactNode;
  action?: ReactNode;
  children?: ReactNode;
  className?: string;
  pad?: boolean;
  hover?: boolean;
}) {
  return (
    <section className={'u-card' + (pad ? ' pad' : '') + (hover ? ' hover' : '') + (className ? ' ' + className : '')}>
      {(title || action) && (
        <div className="u-card-h">
          <div>
            {title && <h2>{title}</h2>}
            {sub && <p>{sub}</p>}
          </div>
          {action}
        </div>
      )}
      {title || action ? <div className="u-card-b">{children}</div> : children}
    </section>
  );
}

/** Number jo 0 se upar animate hota hai (reduced-motion me seedha). */
export function Counter({ value, format = (n) => Math.round(n).toLocaleString('en-IN') }: { value: number; format?: (n: number) => string }) {
  const ref = useRef<HTMLSpanElement>(null);
  const inView = useInView(ref, { once: true });
  const reduce = useReducedMotion();
  const last = useRef(0);
  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    if (reduce || !inView) {
      el.textContent = format(value);
      last.current = value;
      return;
    }
    const c = animate(last.current, value, {
      duration: 0.9,
      ease: [0.2, 0.8, 0.2, 1],
      onUpdate: (v) => {
        el.textContent = format(v);
      },
    });
    last.current = value;
    return () => c.stop();
  }, [value, inView, reduce, format]);
  return <span ref={ref}>{format(0)}</span>;
}

export function Stat({
  label,
  value,
  format,
  sub,
  icon: Ico,
  tone = 'indigo',
  href,
  onClick,
  index = 0,
}: {
  label: string;
  value: number;
  format?: (n: number) => string;
  sub?: ReactNode;
  icon: LucideIcon;
  tone?: Tone;
  href?: string;
  onClick?: () => void;
  index?: number;
}) {
  const reduce = useReducedMotion();
  const inner = (
    <>
      <div className="u-stat-top">
        <span className="u-stat-l">{label}</span>
        <span className="u-stat-ic">
          <Ico aria-hidden />
        </span>
      </div>
      <div className="u-stat-v">
        <Counter value={value} format={format} />
      </div>
      {sub && <div className="u-stat-s">{sub}</div>}
    </>
  );
  const cls = 'u-card hover u-stat tone-' + tone;
  return (
    <motion.div
      initial={reduce ? false : { opacity: 0, y: 12 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.4, delay: Math.min(index, 10) * 0.05, ease: [0.2, 0.8, 0.2, 1] }}
      style={{ display: 'grid' }}
    >
      {href ? (
        <Link href={href} className={cls}>
          {inner}
        </Link>
      ) : onClick ? (
        <button type="button" className={cls} onClick={onClick}>
          {inner}
        </button>
      ) : (
        <div className={cls} style={{ cursor: 'default' }}>
          {inner}
        </div>
      )}
    </motion.div>
  );
}

export function Badge({ tone = 'gray', children, plain }: { tone?: Tone; children: ReactNode; plain?: boolean }) {
  return <span className={'u-badge tone-' + tone + (plain ? ' plain' : '')}>{children}</span>;
}

export function Bar({ pct, size }: { pct: number; size?: 'sm' }) {
  const p = Math.max(0, Math.min(100, pct || 0));
  const cls = p >= 90 ? ' bad' : p >= 75 ? ' warn' : '';
  return (
    <div className={'u-bar' + cls + (size ? ' ' + size : '')} role="progressbar" aria-valuenow={Math.round(p)} aria-valuemin={0} aria-valuemax={100}>
      <i style={{ width: p + '%' }} />
    </div>
  );
}

export function Empty({ icon: Ico, title, children, action }: { icon: LucideIcon; title: string; children?: ReactNode; action?: ReactNode }) {
  return (
    <div className="u-empty">
      <div className="art">
        <Ico aria-hidden />
      </div>
      <h3>{title}</h3>
      {children && <p>{children}</p>}
      {action}
    </div>
  );
}

export function Skeleton({ h = 18, w = '100%', r }: { h?: number; w?: number | string; r?: number }) {
  return <div className="u-skel" style={{ height: h, width: w, borderRadius: r }} aria-hidden />;
}

export function Segmented<T extends string>({
  value,
  onChange,
  options,
  label,
}: {
  value: T;
  onChange: (v: T) => void;
  options: { value: T; label: string; icon?: LucideIcon }[];
  label: string;
}) {
  return (
    <div className="u-seg" role="group" aria-label={label}>
      {options.map((o) => (
        <button key={o.value} type="button" aria-pressed={value === o.value} onClick={() => onChange(o.value)} title={o.label}>
          {o.icon && <o.icon aria-hidden />}
          <span className="hide-sm">{o.label}</span>
        </button>
      ))}
    </div>
  );
}

export function Tabs<T extends string>({ value, onChange, tabs }: { value: T; onChange: (v: T) => void; tabs: { value: T; label: ReactNode }[] }) {
  const id = useId();
  const reduce = useReducedMotion();
  return (
    <div className="u-tabs" role="tablist">
      {tabs.map((t) => (
        <button key={t.value} type="button" role="tab" aria-selected={value === t.value} onClick={() => onChange(t.value)}>
          {t.label}
          {value === t.value && <motion.span layoutId={reduce ? undefined : 'tab-' + id} className="ink" />}
        </button>
      ))}
    </div>
  );
}

/** Center modal (browser <dialog>, Esc band karta hai, focus andar). */
export function Modal({
  open,
  onClose,
  title,
  sub,
  children,
  foot,
  size = 'md',
  onSubmit,
}: {
  open: boolean;
  onClose: () => void;
  title: ReactNode;
  sub?: ReactNode;
  children: ReactNode;
  foot?: ReactNode;
  size?: 'sm' | 'md' | 'lg';
  onSubmit?: () => void | Promise<void>;
}) {
  const hid = useId();
  const busy = useRef(false);
  const body = (
    <>
      <div className="mhead">
        <div>
          <h2 id={hid}>{title}</h2>
          {sub && <div className="msub">{sub}</div>}
        </div>
        <button type="button" className="u-iconbtn" onClick={onClose} aria-label="Close">
          <X aria-hidden />
        </button>
      </div>
      <div className="mbody">{children}</div>
      {foot && <div className="mfoot">{foot}</div>}
    </>
  );
  return (
    <Dialog open={open} onClose={onClose} className={'modal u-modal ' + size} labelledBy={hid} backdropClose>
      <div className="u-modal-in">
        {onSubmit ? (
          <form
            onSubmit={async (e) => {
              e.preventDefault();
              if (busy.current) return; // double submit rok
              busy.current = true;
              try {
                await onSubmit();
              } finally {
                busy.current = false;
              }
            }}
          >
            {body}
          </form>
        ) : (
          body
        )}
      </div>
    </Dialog>
  );
}

/** Ek click me do baar submit na ho — button disable + spinner. */
export function useBusy(): [boolean, <T>(fn: () => Promise<T>) => Promise<T | undefined>] {
  const [busy, setBusy] = useState(false);
  const ref = useRef(false);
  const run = async <T,>(fn: () => Promise<T>) => {
    if (ref.current) return undefined;
    ref.current = true;
    setBusy(true);
    try {
      return await fn();
    } finally {
      ref.current = false;
      setBusy(false);
    }
  };
  return [busy, run];
}

export function Field({ label, children, span, hint }: { label: string; children: ReactNode; span?: boolean; hint?: ReactNode }) {
  return (
    <label className={'field' + (span ? ' span2' : '')}>
      <span className="flabel">{label}</span>
      {children}
      {hint && <span className="hint">{hint}</span>}
    </label>
  );
}

export function Alert({ tone = 'blue', icon: Ico, children }: { tone?: Tone; icon: LucideIcon; children: ReactNode }) {
  return (
    <div className={'u-alert tone-' + tone} role="note">
      <Ico aria-hidden />
      <div>{children}</div>
    </div>
  );
}

export function fmtDate(iso: string): string {
  if (!iso) return '';
  const d = new Date(iso.length === 10 ? iso + 'T00:00:00' : iso);
  if (isNaN(d.getTime())) return iso;
  return d.toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' });
}
export function fmtTime(iso: string): string {
  const d = new Date(iso);
  if (isNaN(d.getTime())) return '';
  return d.toLocaleString('en-IN', { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' });
}
