'use client';

// Reusable table: search, sort, filters (bahar se), column dikhana/chhupana, column resize, bulk select + actions,
// sticky header, saved view (is browser me), CSV export, pagination, phone pe cards.

import { useEffect, useMemo, useState, type ReactNode } from 'react';
import { ArrowDown, ArrowUp, ChevronLeft, ChevronRight, Columns3, Download, Search } from 'lucide-react';
import { matches } from '@/lib/assets/model';
import { toCsv } from '@/lib/assets/csv';
import { saveFile } from '@/lib/bills';

export type Col<T> = {
  key: string;
  label: string;
  render: (row: T) => ReactNode;
  /** sort aur CSV ke liye */
  value?: (row: T) => string | number;
  num?: boolean;
  hidden?: boolean;
  width?: number;
  /** phone card me dikhao */
  card?: boolean;
};

type View = { hidden: string[]; sort: string; dir: 'asc' | 'desc'; size: number; widths?: Record<string, number> };

function loadView(id: string, cols: Col<unknown>[]): View {
  const def: View = { hidden: cols.filter((c) => c.hidden).map((c) => c.key), sort: '', dir: 'desc', size: 25 };
  try {
    const v = JSON.parse(localStorage.getItem('tbl-view-' + id) || 'null');
    if (v && Array.isArray(v.hidden)) return { ...def, ...v };
  } catch {
    /* ignore */
  }
  return def;
}

export function DataTable<T extends { id: string }>({
  id,
  rows,
  cols,
  searchText,
  onRow,
  bulk,
  toolbar,
  exportName,
  empty,
  cardTitle,
  canExport = true,
  initialSort,
}: {
  id: string;
  rows: T[];
  cols: Col<T>[];
  searchText: (row: T) => string;
  onRow?: (row: T) => void;
  bulk?: (selected: T[], clear: () => void) => ReactNode;
  toolbar?: ReactNode;
  exportName?: string;
  empty?: ReactNode;
  cardTitle?: (row: T) => ReactNode;
  canExport?: boolean;
  initialSort?: { key: string; dir: 'asc' | 'desc' };
}) {
  const [q, setQ] = useState('');
  const [view, setView] = useState<View>(() => ({
    hidden: cols.filter((c) => c.hidden).map((c) => c.key),
    sort: initialSort?.key || '',
    dir: initialSort?.dir || 'desc',
    size: 25,
  }));
  const [page, setPage] = useState(0);
  const [sel, setSel] = useState<Set<string>>(new Set());
  const [colsOpen, setColsOpen] = useState(false);

  useEffect(() => {
    setView((v) => {
      const l = loadView(id, cols as Col<unknown>[]);
      return { ...l, sort: l.sort || v.sort, dir: l.sort ? l.dir : v.dir };
    });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [id]);
  useEffect(() => {
    try {
      localStorage.setItem('tbl-view-' + id, JSON.stringify(view));
    } catch {
      /* ignore */
    }
  }, [id, view]);
  useEffect(() => setPage(0), [q, rows.length]);

  const shown = cols.filter((c) => !view.hidden.includes(c.key));

  const filtered = useMemo(() => {
    let a = q.trim() ? rows.filter((r) => matches(searchText(r), q)) : rows.slice();
    const sc = cols.find((c) => c.key === view.sort);
    if (sc?.value) {
      const get = sc.value;
      a = a.sort((x, y) => {
        const vx = get(x);
        const vy = get(y);
        const r = typeof vx === 'number' && typeof vy === 'number' ? vx - vy : String(vx).localeCompare(String(vy), 'en', { numeric: true });
        return view.dir === 'asc' ? r : -r;
      });
    }
    return a;
  }, [rows, q, view.sort, view.dir, cols, searchText]);

  const pages = Math.max(1, Math.ceil(filtered.length / view.size));
  const pg = Math.min(page, pages - 1);
  const slice = filtered.slice(pg * view.size, pg * view.size + view.size);
  const selected = rows.filter((r) => sel.has(r.id));
  const allOnPage = slice.length > 0 && slice.every((r) => sel.has(r.id));

  const startResize = (key: string, e: React.PointerEvent<HTMLSpanElement>) => {
    e.preventDefault();
    e.stopPropagation();
    const th = (e.currentTarget.parentElement as HTMLElement) || null;
    const startX = e.clientX;
    const startW = th ? th.getBoundingClientRect().width : 120;
    const move = (ev: PointerEvent) => {
      const w = Math.max(60, Math.min(700, Math.round(startW + ev.clientX - startX)));
      setView((v) => ({ ...v, widths: { ...(v.widths || {}), [key]: w } }));
    };
    const up = () => {
      window.removeEventListener('pointermove', move);
      window.removeEventListener('pointerup', up);
    };
    window.addEventListener('pointermove', move);
    window.addEventListener('pointerup', up);
  };

  const toggleSort = (k: string) =>
    setView((v) => (v.sort === k ? { ...v, dir: v.dir === 'asc' ? 'desc' : 'asc' } : { ...v, sort: k, dir: 'asc' }));

  const exportRows = (list: T[]) => {
    const ex = cols.filter((c) => c.value);
    const text = toCsv(
      ex.map((c) => c.label),
      list.map((r) => ex.map((c) => c.value!(r))),
    );
    saveFile((exportName || id) + '-' + new Date().toISOString().slice(0, 10) + '.csv', new Blob([text], { type: 'text/csv;charset=utf-8' }));
  };

  return (
    <div className="u-card">
      <div className="u-toolbar" style={{ padding: 14 }}>
        <label className="u-search">
          <Search aria-hidden />
          <input type="search" value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search…" aria-label="Search table" />
        </label>
        {toolbar}
        <div className="u-cols">
          <button type="button" className="btn sm" onClick={() => setColsOpen((o) => !o)} aria-expanded={colsOpen}>
            <Columns3 aria-hidden className="ic" /> Columns
          </button>
          {colsOpen && (
            <div className="u-pop" onMouseLeave={() => setColsOpen(false)}>
              {cols.map((c) => (
                <label key={c.key}>
                  <input
                    type="checkbox"
                    checked={!view.hidden.includes(c.key)}
                    onChange={(e) =>
                      setView((v) => ({ ...v, hidden: e.target.checked ? v.hidden.filter((h) => h !== c.key) : [...v.hidden, c.key] }))
                    }
                  />
                  {c.label}
                </label>
              ))}
            </div>
          )}
        </div>
        {canExport && (
          <button type="button" className="btn sm" onClick={() => exportRows(filtered)} disabled={!filtered.length} title="Export filtered rows to CSV / Excel">
            <Download aria-hidden className="ic" /> Export
          </button>
        )}
      </div>

      {selected.length > 0 && (
        <div className="u-bulk">
          <span>{selected.length} selected</span>
          {bulk?.(selected, () => setSel(new Set()))}
          {canExport && (
            <button type="button" className="btn sm" onClick={() => exportRows(selected)}>
              <Download aria-hidden className="ic" /> Export selected
            </button>
          )}
          <button type="button" className="btn sm ghost" onClick={() => setSel(new Set())}>
            Clear
          </button>
        </div>
      )}

      {filtered.length === 0 ? (
        empty || <div className="u-empty"><p>Kuch nahi mila.</p></div>
      ) : (
        <>
          <div className={'u-table-wrap' + (cardTitle ? ' cards' : '')}>
            <table className="u-table">
              <thead>
                <tr>
                  {bulk && (
                    <th className="chk">
                      <input
                        type="checkbox"
                        aria-label="Select page"
                        checked={allOnPage}
                        onChange={(e) =>
                          setSel((s) => {
                            const n = new Set(s);
                            for (const r of slice) e.target.checked ? n.add(r.id) : n.delete(r.id);
                            return n;
                          })
                        }
                      />
                    </th>
                  )}
                  {shown.map((c) => (
                    <th
                      key={c.key}
                      className={(c.num ? 'num ' : '') + 'res'}
                      style={view.widths?.[c.key] ? { width: view.widths[c.key], minWidth: view.widths[c.key] } : c.width ? { width: c.width } : undefined}
                      aria-sort={view.sort === c.key ? (view.dir === 'asc' ? 'ascending' : 'descending') : undefined}
                    >
                      {c.value ? (
                        <button type="button" onClick={() => toggleSort(c.key)}>
                          {c.label}
                          {view.sort === c.key && (view.dir === 'asc' ? <ArrowUp aria-hidden /> : <ArrowDown aria-hidden />)}
                        </button>
                      ) : (
                        c.label
                      )}
                      <span className="col-grip" onPointerDown={(e) => startResize(c.key, e)} onDoubleClick={() => setView((v) => { const w = { ...(v.widths || {}) }; delete w[c.key]; return { ...v, widths: w }; })} aria-hidden title="Drag to resize" />
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {slice.map((r) => (
                  <tr key={r.id} className={(sel.has(r.id) ? 'sel ' : '') + (onRow ? 'click' : '')} onClick={() => onRow?.(r)}>
                    {bulk && (
                      <td className="chk" onClick={(e) => e.stopPropagation()}>
                        <input
                          type="checkbox"
                          aria-label="Select row"
                          checked={sel.has(r.id)}
                          onChange={(e) =>
                            setSel((s) => {
                              const n = new Set(s);
                              e.target.checked ? n.add(r.id) : n.delete(r.id);
                              return n;
                            })
                          }
                        />
                      </td>
                    )}
                    {shown.map((c) => (
                      <td key={c.key} className={c.num ? 'num' : undefined}>
                        {c.render(r)}
                      </td>
                    ))}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          {cardTitle && (
            <div className="u-cards-m">
              {slice.map((r) => (
                <div key={r.id} className="u-mcard" role={onRow ? 'button' : undefined} tabIndex={onRow ? 0 : undefined} onClick={() => onRow?.(r)}>
                  <div className="u-between">
                    <div style={{ minWidth: 0 }}>{cardTitle(r)}</div>
                    {bulk && (
                      <input
                        type="checkbox"
                        aria-label="Select"
                        checked={sel.has(r.id)}
                        onClick={(e) => e.stopPropagation()}
                        onChange={(e) =>
                          setSel((s) => {
                            const n = new Set(s);
                            e.target.checked ? n.add(r.id) : n.delete(r.id);
                            return n;
                          })
                        }
                      />
                    )}
                  </div>
                  {cols
                    .filter((c) => c.card)
                    .map((c) => (
                      <div className="r" key={c.key}>
                        <span>{c.label}</span>
                        <span>{c.render(r)}</span>
                      </div>
                    ))}
                </div>
              ))}
            </div>
          )}
          <div className="u-tfoot">
            <span>
              {filtered.length.toLocaleString('en-IN')} rows{q ? ' (filtered)' : ''}
            </span>
            <div className="u-pager">
              <select value={view.size} onChange={(e) => setView((v) => ({ ...v, size: Number(e.target.value) }))} aria-label="Rows per page" style={{ height: 32 }}>
                {[10, 25, 50, 100, 250].map((n) => (
                  <option key={n} value={n}>
                    {n} / page
                  </option>
                ))}
              </select>
              <button type="button" className="u-iconbtn" onClick={() => setPage(pg - 1)} disabled={pg === 0} aria-label="Previous page">
                <ChevronLeft aria-hidden />
              </button>
              <span>
                {pg + 1} / {pages}
              </span>
              <button type="button" className="u-iconbtn" onClick={() => setPage(pg + 1)} disabled={pg >= pages - 1} aria-label="Next page">
                <ChevronRight aria-hidden />
              </button>
            </div>
          </div>
        </>
      )}
    </div>
  );
}
