'use client';

// Universal Print Designer: paper (A3/A4/A5/A6/Letter/Legal/custom), portrait/landscape, margins, font size 8–72 pt,
// weight, row height, borders, heading, footer, page number, sign ki jagah, checkbox column, copies, live preview.
// Hindi (Noto Sans Devanagari) sahi chhapti hai. Settings is browser me yaad rehti hai.

import { useEffect, useMemo, useState, type CSSProperties } from 'react';
import { createPortal } from 'react-dom';
import { Printer, RotateCcw } from 'lucide-react';
import { Field, Modal } from '../ui';

export type PrintTable = {
  title: string;
  subtitle?: string;
  meta?: string[];
  head: string[];
  align: ('left' | 'right' | 'center')[];
  sections: { heading?: string; rows: string[][]; foot?: string[] }[];
  grandFoot?: string[];
  /** table ke upar extra blocks (jaise person ka summary) */
  blocks?: { label: string; value: string }[];
};

type Paper = 'A3' | 'A4' | 'A5' | 'A6' | 'Letter' | 'Legal' | 'custom';
const SIZES: Record<Exclude<Paper, 'custom'>, [number, number]> = {
  A3: [297, 420],
  A4: [210, 297],
  A5: [148, 210],
  A6: [105, 148],
  Letter: [215.9, 279.4],
  Legal: [215.9, 355.6],
};

export type PrintSettings = {
  paper: Paper;
  cw: number;
  ch: number;
  landscape: boolean;
  margin: number;
  titlePt: number;
  headPt: number;
  bodyPt: number;
  firstColPt: number;
  bodyWeight: 400 | 500 | 700 | 800;
  firstBold: boolean;
  rowPad: number;
  lineHeight: number;
  borders: 'all' | 'rows' | 'none';
  stripe: boolean;
  org: string;
  showDate: boolean;
  pageNo: boolean;
  signs: string;
  checkbox: boolean;
  copies: number;
  color: string;
  headBg: string;
  footer: string;
};

export const DEFAULT_PRINT: PrintSettings = {
  paper: 'A4',
  cw: 210,
  ch: 297,
  landscape: false,
  margin: 12,
  titlePt: 18,
  headPt: 9.5,
  bodyPt: 10,
  firstColPt: 10,
  bodyWeight: 400,
  firstBold: true,
  rowPad: 4,
  lineHeight: 1.3,
  borders: 'all',
  stripe: false,
  org: 'Office Saman Register',
  showDate: true,
  pageNo: true,
  signs: '',
  checkbox: false,
  copies: 1,
  color: '#111111',
  headBg: '#EEF0F8',
  footer: '',
};

const PRESETS: { id: string; label: string; s: Partial<PrintSettings> }[] = [
  { id: 'std', label: 'Standard A4', s: {} },
  { id: 'land', label: 'A4 landscape (bahut column)', s: { landscape: true, bodyPt: 9, headPt: 8.5 } },
  { id: 'big', label: 'Large bold list (shopping)', s: { bodyPt: 16, firstColPt: 20, bodyWeight: 700, rowPad: 8, headPt: 12, titlePt: 26, checkbox: true } },
  { id: 'compact', label: 'Compact', s: { bodyPt: 8, headPt: 8, firstColPt: 8, rowPad: 2, titlePt: 14, margin: 8 } },
  { id: 'slip', label: 'A5 slip with signatures', s: { paper: 'A5', bodyPt: 10, signs: 'Dene wale ka sign, Lene wale ka sign' } },
];

export function usePrintSettings(key: string): [PrintSettings, (p: Partial<PrintSettings>) => void, () => void] {
  const [s, setS] = useState<PrintSettings>(DEFAULT_PRINT);
  useEffect(() => {
    try {
      const v = JSON.parse(localStorage.getItem('print-' + key) || 'null');
      if (v) setS({ ...DEFAULT_PRINT, ...v });
    } catch {
      /* ignore */
    }
  }, [key]);
  const set = (p: Partial<PrintSettings>) =>
    setS((cur) => {
      const n = { ...cur, ...p };
      try {
        localStorage.setItem('print-' + key, JSON.stringify(n));
      } catch {
        /* ignore */
      }
      return n;
    });
  return [s, set, () => set(DEFAULT_PRINT)];
}

function paperMM(s: PrintSettings): [number, number] {
  const [w, h] = s.paper === 'custom' ? [s.cw || 210, s.ch || 297] : SIZES[s.paper];
  return s.landscape ? [h, w] : [w, h];
}

/** Asli printable page (preview aur print dono me yahi). */
export function PrintPage({ doc, s }: { doc: PrintTable; s: PrintSettings }) {
  const [w] = paperMM(s);
  const border = s.borders === 'none' ? 'none' : '0.6pt solid #9aa1b5';
  const cell = (i: number, head = false): CSSProperties => ({
    padding: s.rowPad + 'pt ' + Math.max(3, s.rowPad + 1) + 'pt',
    textAlign: doc.align[i] || 'left',
    border: s.borders === 'all' ? border : 'none',
    borderBottom: s.borders === 'none' ? 'none' : border,
    fontSize: (head ? s.headPt : i === 0 ? s.firstColPt : s.bodyPt) + 'pt',
    fontWeight: head ? 700 : i === 0 && s.firstBold ? Math.max(700, s.bodyWeight) : s.bodyWeight,
    lineHeight: s.lineHeight,
    verticalAlign: 'top',
    wordBreak: doc.align[i] === 'right' ? 'normal' : 'break-word',
    whiteSpace: doc.align[i] === 'right' ? 'nowrap' : undefined,
    background: head ? s.headBg : undefined,
  });
  const now = new Date().toLocaleString('en-IN', { day: '2-digit', month: 'short', year: 'numeric', hour: '2-digit', minute: '2-digit' });
  const copies = Math.max(1, Math.min(10, s.copies || 1));
  const one = (k: number) => (
    <div key={k} className="pd-page" style={{ width: w - 2 * s.margin + 'mm', color: s.color, fontFamily: 'Inter, "Noto Sans Devanagari", sans-serif', breakAfter: k < copies - 1 ? 'page' : undefined }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-end', gap: '12pt', borderBottom: '1.6pt solid #4F46E5', paddingBottom: '5pt', marginBottom: '8pt' }}>
        <div style={{ minWidth: 0 }}>
          {s.org && <div style={{ fontSize: Math.max(8, s.titlePt * 0.45) + 'pt', fontWeight: 600, color: '#555' }}>{s.org}</div>}
          <div style={{ fontSize: s.titlePt + 'pt', fontWeight: 800, lineHeight: 1.15 }}>{doc.title}</div>
          {doc.subtitle && <div style={{ fontSize: Math.max(8, s.bodyPt * 0.9) + 'pt', color: '#444', marginTop: '2pt' }}>{doc.subtitle}</div>}
        </div>
        <div style={{ textAlign: 'right', fontSize: '8.5pt', color: '#444', whiteSpace: 'nowrap' }}>
          {s.showDate && <div>Printed {now}</div>}
          {(doc.meta || []).map((m) => (
            <div key={m}>{m}</div>
          ))}
        </div>
      </div>
      {doc.blocks && doc.blocks.length > 0 && (
        <div style={{ display: 'flex', flexWrap: 'wrap', gap: '6pt 18pt', marginBottom: '8pt', fontSize: s.bodyPt + 'pt' }}>
          {doc.blocks.map((b) => (
            <div key={b.label}>
              <span style={{ color: '#555' }}>{b.label}: </span>
              <b>{b.value}</b>
            </div>
          ))}
        </div>
      )}
      <table style={{ width: '100%', borderCollapse: 'collapse' }}>
        <thead style={{ display: 'table-header-group' }}>
          <tr>
            {s.checkbox && <th style={{ ...cell(-1, true), width: '16pt' }}>✓</th>}
            {doc.head.map((h, i) => (
              <th key={i} style={cell(i, true)}>
                {h}
              </th>
            ))}
          </tr>
        </thead>
        <tbody>
          {doc.sections.map((sec, si) => (
            <SectionRows key={si} sec={sec} s={s} cell={cell} cols={doc.head.length} />
          ))}
        </tbody>
        {doc.grandFoot && (
          <tfoot>
            <tr>
              {s.checkbox && <td style={cell(-1)} />}
              {doc.grandFoot.map((f, i) => (
                <td key={i} style={{ ...cell(i), fontWeight: 800, background: s.headBg }}>
                  {f}
                </td>
              ))}
            </tr>
          </tfoot>
        )}
      </table>
      {s.footer && <p style={{ fontSize: Math.max(8, s.bodyPt * 0.9) + 'pt', marginTop: '10pt', whiteSpace: 'pre-wrap' }}>{s.footer}</p>}
      {s.signs.trim() && (
        <div style={{ display: 'flex', gap: '24pt', marginTop: '36pt', breakInside: 'avoid' }}>
          {s.signs
            .split(',')
            .map((x) => x.trim())
            .filter(Boolean)
            .map((x) => (
              <div key={x} style={{ flex: 1, borderTop: '0.8pt solid #333', paddingTop: '4pt', fontSize: '9pt' }}>
                {x}
              </div>
            ))}
        </div>
      )}
    </div>
  );
  return <>{Array.from({ length: copies }, (_, k) => one(k))}</>;
}

function SectionRows({ sec, s, cell, cols }: { sec: PrintTable['sections'][number]; s: PrintSettings; cell: (i: number, head?: boolean) => CSSProperties; cols: number }) {
  return (
    <>
      {sec.heading && (
        <tr style={{ breakInside: 'avoid', breakAfter: 'avoid' }}>
          <td colSpan={cols + (s.checkbox ? 1 : 0)} style={{ ...cell(0), fontWeight: 800, background: '#F6F7FB', fontSize: s.headPt + 1 + 'pt' }}>
            {sec.heading}
          </td>
        </tr>
      )}
      {sec.rows.map((r, ri) => (
        <tr key={ri} style={{ breakInside: 'avoid', background: s.stripe && ri % 2 ? '#F7F8FC' : undefined }}>
          {s.checkbox && <td style={cell(-1)}>☐</td>}
          {r.map((v, i) => (
            <td key={i} style={cell(i)}>
              {v}
            </td>
          ))}
        </tr>
      ))}
      {sec.foot && (
        <tr>
          {s.checkbox && <td style={cell(-1)} />}
          {sec.foot.map((f, i) => (
            <td key={i} style={{ ...cell(i), fontWeight: 700, background: '#F3F4F8' }}>
              {f}
            </td>
          ))}
        </tr>
      )}
    </>
  );
}

/** Print karo: sirf ye page chhapta hai, @page size / margin / page number settings ke hisaab se. */
export function printDoc(doc: PrintTable, s: PrintSettings, setNode: (n: React.ReactNode) => void) {
  const [w, h] = paperMM(s);
  const style = document.createElement('style');
  style.textContent =
    '@page{size:' + w + 'mm ' + h + 'mm;margin:' + s.margin + 'mm' + (s.pageNo ? ';@bottom-right{content:"Page " counter(page) " / " counter(pages);font:8pt Inter,sans-serif;color:#666}' : '') + '}' +
    '@media print{html.print-report body > *:not(.report-portal){display:none!important}html.print-report .report-portal{display:block!important}}';
  document.head.appendChild(style);
  setNode(
    <div className="report-portal">
      <PrintPage doc={doc} s={s} />
    </div>,
  );
  const html = document.documentElement;
  html.classList.add('print-report');
  const done = () => {
    html.classList.remove('print-report');
    style.remove();
    setNode(null);
  };
  window.addEventListener('afterprint', done, { once: true });
  setTimeout(() => window.print(), 250);
}

export function PrintDesignerModal({ open, onClose, doc, storeKey }: { open: boolean; onClose: () => void; doc: PrintTable; storeKey: string }) {
  const [s, set, reset] = usePrintSettings(storeKey);
  const [node, setNode] = useState<React.ReactNode>(null);
  const [zoom, setZoom] = useState(0.55);
  const [w, h] = paperMM(s);
  const rows = useMemo(() => doc.sections.reduce((a, x) => a + x.rows.length, 0), [doc]);
  const num = (k: keyof PrintSettings, label: string, min: number, max: number, step = 1) => (
    <Field label={label}>
      <input type="number" min={min} max={max} step={step} value={String(s[k])} onChange={(e) => set({ [k]: Math.max(min, Math.min(max, Number(e.target.value) || min)) } as Partial<PrintSettings>)} />
    </Field>
  );
  return (
    <>
      <Modal
        open={open}
        onClose={onClose}
        size="lg"
        title="Print designer"
        sub={rows + ' rows · ' + (s.paper === 'custom' ? w + '×' + h + ' mm' : s.paper) + (s.landscape ? ' landscape' : '')}
        foot={
          <>
            <button type="button" className="btn ghost" onClick={reset}>
              <RotateCcw aria-hidden className="ic" /> Reset
            </button>
            <button type="button" className="btn" onClick={onClose}>
              Close
            </button>
            <button type="button" className="btn primary" onClick={() => printDoc(doc, s, setNode)}>
              <Printer aria-hidden className="ic" /> Print / Save PDF
            </button>
          </>
        }
      >
        <div className="pd-wrap">
          <div className="pd-controls">
            <Field label="Ready template">
              <select value="" onChange={(e) => {
                const p = PRESETS.find((x) => x.id === e.target.value);
                if (p) set({ ...DEFAULT_PRINT, org: s.org, ...p.s });
              }}>
                <option value="">— Choose —</option>
                {PRESETS.map((p) => (
                  <option key={p.id} value={p.id}>
                    {p.label}
                  </option>
                ))}
              </select>
            </Field>
            <div className="fgrid">
              <Field label="Paper">
                <select value={s.paper} onChange={(e) => set({ paper: e.target.value as Paper })}>
                  {(['A3', 'A4', 'A5', 'A6', 'Letter', 'Legal', 'custom'] as Paper[]).map((p) => (
                    <option key={p} value={p}>
                      {p === 'custom' ? 'Custom…' : p}
                    </option>
                  ))}
                </select>
              </Field>
              <Field label="Orientation">
                <select value={s.landscape ? 'l' : 'p'} onChange={(e) => set({ landscape: e.target.value === 'l' })}>
                  <option value="p">Portrait</option>
                  <option value="l">Landscape</option>
                </select>
              </Field>
              {s.paper === 'custom' && (
                <>
                  {num('cw', 'Width mm', 50, 1000)}
                  {num('ch', 'Height mm', 50, 2000)}
                </>
              )}
              {num('margin', 'Margin mm', 0, 40)}
              {num('copies', 'Copies', 1, 10)}
              {num('titlePt', 'Title pt', 8, 72, 0.5)}
              {num('headPt', 'Column heading pt', 8, 72, 0.5)}
              {num('firstColPt', 'First column pt', 8, 72, 0.5)}
              {num('bodyPt', 'Other text pt', 8, 72, 0.5)}
              <Field label="Text weight">
                <select value={s.bodyWeight} onChange={(e) => set({ bodyWeight: Number(e.target.value) as PrintSettings['bodyWeight'] })}>
                  <option value={400}>Normal</option>
                  <option value={500}>Medium</option>
                  <option value={700}>Bold</option>
                  <option value={800}>Extra bold</option>
                </select>
              </Field>
              {num('rowPad', 'Row spacing pt', 0, 30)}
              {num('lineHeight', 'Line height', 1, 3, 0.1)}
              <Field label="Borders">
                <select value={s.borders} onChange={(e) => set({ borders: e.target.value as PrintSettings['borders'] })}>
                  <option value="all">All lines</option>
                  <option value="rows">Row lines</option>
                  <option value="none">No lines</option>
                </select>
              </Field>
              <Field label="Text color">
                <input type="color" value={s.color} onChange={(e) => set({ color: e.target.value })} style={{ padding: 4 }} />
              </Field>
              <Field label="Heading background">
                <input type="color" value={s.headBg} onChange={(e) => set({ headBg: e.target.value })} style={{ padding: 4 }} />
              </Field>
            </div>
            <Field label="Ashram / office name (upar)">
              <input value={s.org} onChange={(e) => set({ org: e.target.value })} maxLength={80} />
            </Field>
            <Field label="Signature boxes (comma se alag)">
              <input value={s.signs} onChange={(e) => set({ signs: e.target.value })} placeholder="Dene wala, Lene wala, Approved by" />
            </Field>
            <Field label="Footer note">
              <textarea rows={2} value={s.footer} onChange={(e) => set({ footer: e.target.value })} maxLength={500} />
            </Field>
            <div className="u-row" style={{ gap: 14 }}>
              <label className="u-check">
                <input type="checkbox" checked={s.firstBold} onChange={(e) => set({ firstBold: e.target.checked })} /> First column bold
              </label>
              <label className="u-check">
                <input type="checkbox" checked={s.checkbox} onChange={(e) => set({ checkbox: e.target.checked })} /> Checkbox column
              </label>
              <label className="u-check">
                <input type="checkbox" checked={s.stripe} onChange={(e) => set({ stripe: e.target.checked })} /> Stripes
              </label>
              <label className="u-check">
                <input type="checkbox" checked={s.showDate} onChange={(e) => set({ showDate: e.target.checked })} /> Print date
              </label>
              <label className="u-check">
                <input type="checkbox" checked={s.pageNo} onChange={(e) => set({ pageNo: e.target.checked })} /> Page numbers
              </label>
            </div>
            <Field label={'Preview zoom ' + Math.round(zoom * 100) + '%'}>
              <input type="range" min={0.25} max={1} step={0.05} value={zoom} onChange={(e) => setZoom(Number(e.target.value))} style={{ padding: 0, height: 24 }} />
            </Field>
          </div>
          <div className="pd-preview">
            <div style={{ zoom }}>
              <div className="pd-sheet" style={{ width: w + 'mm', minHeight: h + 'mm', padding: s.margin + 'mm' }}>
                <PrintPage doc={doc} s={s} />
              </div>
            </div>
          </div>
        </div>
      </Modal>
      {node && createPortal(node, document.body)}
    </>
  );
}
