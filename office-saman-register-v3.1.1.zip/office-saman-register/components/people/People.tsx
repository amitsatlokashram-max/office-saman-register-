'use client';

// Persons & Departments: har bande / department ka poora hisaab — items (kab, kya, kitna, wapas, abhi), drives, data, events.

import Link from 'next/link';
import { useRouter, useSearchParams } from 'next/navigation';
import { useEffect, useMemo, useState } from 'react';
import { Building2, CalendarDays, Database, FileSpreadsheet, HardDrive, Package, Pencil, Plus, Printer, Search, UserRound, Users } from 'lucide-react';
import { saveDept, savePerson } from '@/lib/assets/db';
import { gb, nameKey, whereIs } from '@/lib/assets/model';
import { DRIVE_STATUS_LABEL, TRANSFER_LABEL, type Department, type Person } from '@/lib/assets/types';
import { inr } from '@/lib/calc';
import { allDepts, allPeople, canon, summarize, unattributedReturns, type LedgerRow } from '@/lib/people';
import { useAssets } from '../assets/store';
import { useReg } from '../context';
import { PrintDesignerModal, type PrintTable } from '../print/PrintDesigner';
import { exportXlsx, useSources } from '../reports/ReportBuilder';
import { DataTable, type Col } from '../ui/DataTable';
import { Alert, Badge, Card, Empty, Field, Modal, PageHeader, Stat, Tabs, fmtDate, useBusy } from '../ui';
import { Info } from 'lucide-react';

const fd = (s: string) => (s ? fmtDate(s) : '—');

/* ======================= PERSONS LIST ======================= */
type PRow = { id: string; key: string; name: string; depts: string; issued: number; returned: number; current: number; value: number; drives: number; storage: number; data: number; events: number; last: string; registered: boolean };

export function PersonsPage() {
  const A = useAssets();
  const router = useRouter();
  const sp = useSearchParams();
  const { src, am } = useSources();
  const [form, setForm] = useState<Person | null | 'new'>(null);
  useEffect(() => {
    if (sp.get('new') === '1') setForm('new');
  }, [sp]);

  const rows = useMemo<PRow[]>(() => {
    const sum = summarize(src.ledger);
    const people = allPeople({ persons: A.persons, rows: src.ledger, drives: A.drives, transfers: A.transfers, catalog: A.catalog, events: A.events, am });
    return people.map((p) => {
      const s = sum.get(p.key);
      const dr = A.drives.filter((d) => d.holder && canon(d.holder.name, am).key === p.key);
      return {
        id: p.key,
        key: p.key,
        name: p.name,
        depts: Array.from(new Set([...p.depts, ...(s?.depts || [])])).join(', '),
        issued: s?.issued || 0,
        returned: s?.returned || 0,
        current: s?.current || 0,
        value: s?.currentValue || 0,
        drives: dr.length,
        storage: dr.reduce((a, d) => a + d.capacityGB, 0),
        data: A.catalog.filter((c) => canon(c.owner, am).key === p.key).length,
        events: A.events.filter((e) => [...e.participants, ...e.mainPersons, ...e.recordingTeam, e.submittedBy, e.receivedBy, e.responsible].some((n) => canon(n, am).key === p.key)).length,
        last: s?.last || '',
        registered: !!p.person,
      };
    });
  }, [src, A, am]);

  const cols: Col<PRow>[] = [
    { key: 'name', label: 'Person', value: (r) => r.name, render: (r) => <Link className="u-link" href={'/persons/' + encodeURIComponent(r.key)} onClick={(e) => e.stopPropagation()}>{r.name}</Link> },
    { key: 'depts', label: 'Department', value: (r) => r.depts, render: (r) => r.depts || '—', card: true },
    { key: 'issued', label: 'Total issued', num: true, value: (r) => r.issued, render: (r) => r.issued || '—' },
    { key: 'returned', label: 'Returned', num: true, value: (r) => r.returned, render: (r) => r.returned || '—' },
    { key: 'current', label: 'Holding now', num: true, value: (r) => r.current, render: (r) => (r.current ? <b>{r.current}</b> : '—'), card: true },
    { key: 'value', label: 'Value now', num: true, value: (r) => r.value, render: (r) => (r.value ? inr(r.value) : '—'), hidden: true },
    { key: 'drives', label: 'Drives', num: true, value: (r) => r.drives, render: (r) => (r.drives ? r.drives + ' · ' + gb(r.storage) : '—'), card: true },
    { key: 'data', label: 'Data records', num: true, value: (r) => r.data, render: (r) => r.data || '—', hidden: true },
    { key: 'events', label: 'Events', num: true, value: (r) => r.events, render: (r) => r.events || '—', hidden: true },
    { key: 'last', label: 'Last activity', value: (r) => r.last, render: (r) => fd(r.last) },
  ];

  return (
    <>
      <PageHeader
        title="Persons"
        sub="Har bande ka hisaab: kya diya, kab, kitna, kitna wapas, abhi paas kitna, kaunsi drive aur data uske paas."
        actions={
          A.can('persons', 'create') && (
            <button type="button" className="btn primary" onClick={() => setForm('new')}>
              <Plus aria-hidden className="ic" /> Add person
            </button>
          )
        }
      />
      <div className="u-grid c4">
        <Stat index={0} label="Persons" value={rows.length} icon={Users} sub={rows.filter((r) => r.registered).length + ' with profile'} />
        <Stat index={1} label="Holding items now" value={rows.filter((r) => r.current > 0).length} icon={Package} tone="violet" sub={rows.reduce((a, r) => a + r.current, 0) + ' pcs with people'} />
        <Stat index={2} label="Holding drives" value={rows.filter((r) => r.drives > 0).length} icon={HardDrive} tone="blue" sub={gb(rows.reduce((a, r) => a + r.storage, 0)) + ' storage'} />
        <Stat index={3} label="Departments" value={new Set(rows.flatMap((r) => r.depts.split(', ').filter(Boolean))).size} icon={Building2} tone="green" href="/departments" />
      </div>
      <DataTable
        id="persons"
        rows={rows}
        cols={cols}
        exportName="persons"
        canExport={A.can('persons', 'export')}
        searchText={(r) => r.name + ' ' + r.depts}
        onRow={(r) => router.push('/persons/' + encodeURIComponent(r.key))}
        cardTitle={(r) => <b>{r.name}</b>}
        initialSort={{ key: 'name', dir: 'asc' }}
        empty={<Empty icon={Users} title="Abhi koi bande nahi">Saman issue karte waqt jo naam likhte ho, wo yahan apne aap aa jata hai.</Empty>}
      />
      {form && <PersonForm person={form === 'new' ? null : form} onClose={() => setForm(null)} />}
    </>
  );
}

export function PersonForm({ person, presetName = '', onClose }: { person: Person | null; presetName?: string; onClose: () => void }) {
  const { me, toast } = useReg();
  const [v, setV] = useState({
    name: person?.name || presetName,
    aliases: person?.aliases.join(', ') || '',
    depts: person?.depts.join(', ') || '',
    location: person?.location || '',
    responsibilities: person?.responsibilities || '',
    phone: person?.phone || '',
    status: person?.status || 'active',
    notes: person?.notes || '',
  });
  const [busy, run] = useBusy();
  const set = (k: keyof typeof v, x: string) => setV((p) => ({ ...p, [k]: x }));
  const list = (s: string) => s.split(',').map((x) => x.trim()).filter(Boolean);
  return (
    <Modal
      open
      onClose={onClose}
      title={person ? 'Edit ' + person.name : 'Person profile'}
      sub="Dusre naam (jaise 'Amit ji', 'Amit Kumar') aliases me likho — sab ek hi bande me jud jayenge."
      onSubmit={() =>
        run(async () => {
          if (!v.name.trim()) return;
          try {
            await savePerson({ name: v.name.trim(), aliases: list(v.aliases), depts: list(v.depts), location: v.location.trim(), responsibilities: v.responsibilities.trim(), phone: v.phone.trim(), status: v.status === 'inactive' ? 'inactive' : 'active', notes: v.notes.trim() }, me, person?.id);
            toast('✓ Saved');
            onClose();
          } catch {
            toast('Save nahi hua (ijaazat?)');
          }
        })
      }
      foot={
        <>
          <button type="button" className="btn" onClick={onClose}>
            Cancel
          </button>
          <button type="submit" className="btn primary" disabled={busy}>
            Save
          </button>
        </>
      }
    >
      <div className="fgrid">
        <Field label="Naam">
          <input value={v.name} onChange={(e) => set('name', e.target.value)} required maxLength={80} autoFocus />
        </Field>
        <Field label="Dusre naam / spelling (comma)">
          <input value={v.aliases} onChange={(e) => set('aliases', e.target.value)} />
        </Field>
        <Field label="Departments (comma)">
          <input value={v.depts} onChange={(e) => set('depts', e.target.value)} list="dl-depts" />
        </Field>
        <Field label="Jagah (kahan rehte / baithte hai)">
          <input value={v.location} onChange={(e) => set('location', e.target.value)} list="dl-places" />
        </Field>
        <Field label="Phone (zaroorat ho to)">
          <input value={v.phone} onChange={(e) => set('phone', e.target.value)} inputMode="tel" maxLength={20} />
        </Field>
        <Field label="Status">
          <select value={v.status} onChange={(e) => set('status', e.target.value)}>
            <option value="active">Active</option>
            <option value="inactive">Inactive</option>
          </select>
        </Field>
        <Field label="Zimmedari (responsibilities)" span>
          <input value={v.responsibilities} onChange={(e) => set('responsibilities', e.target.value)} maxLength={300} />
        </Field>
        <Field label="Note" span>
          <textarea rows={2} value={v.notes} onChange={(e) => set('notes', e.target.value)} maxLength={1000} />
        </Field>
      </div>
    </Modal>
  );
}

/* ======================= PERSON PROFILE ======================= */
export function PersonProfile({ pkey }: { pkey: string }) {
  const A = useAssets();
  const { items } = useReg();
  const router = useRouter();
  const { src, am } = useSources();
  const [tab, setTab] = useState<'items' | 'txns' | 'drives' | 'data' | 'events'>('items');
  const [asOf, setAsOf] = useState('');
  const [from, setFrom] = useState('');
  const [to, setTo] = useState('');
  const [itemQ, setItemQ] = useState('');
  const [edit, setEdit] = useState(false);
  const [print, setPrint] = useState<PrintTable | null>(null);

  const person = A.persons.find((p) => nameKey(p.name) === pkey);
  const mine = (n: string) => !!n && canon(n, am).key === pkey;
  const rows = useMemo(() => src.ledger.filter((r) => r.personKey === pkey), [src.ledger, pkey]);
  const sum = useMemo(() => summarize(rows, asOf).get(pkey), [rows, asOf, pkey]);
  const name = person?.name || sum?.name || rows[0]?.person || A.drives.find((d) => mine(d.holder?.name || ''))?.holder?.name || decodeURIComponent(pkey);
  const drivesNow = A.drives.filter((d) => d.holder && mine(d.holder.name));
  const driveHist = A.transfers.filter((t) => mine(t.to.name) || mine(t.from.name));
  const data = A.catalog.filter((c) => mine(c.owner));
  const events = A.events.filter((e) => [...e.participants, ...e.mainPersons, ...e.recordingTeam, e.submittedBy, e.receivedBy, e.responsible].some(mine));
  const unattrib = unattributedReturns(items, am).filter((u) => rows.some((r) => r.itemId === u.itemId));

  const txns = rows.filter((r) => (!from || r.date >= from) && (!to || r.date <= to) && (!asOf || r.date <= asOf) && (!itemQ || r.itemName.toLowerCase().includes(itemQ.toLowerCase())));
  const holdings = (sum?.holdings || []).filter((h) => !itemQ || h.itemName.toLowerCase().includes(itemQ.toLowerCase()));

  const printHoldings = () =>
    setPrint({
      title: name + ' — Items held',
      subtitle: (asOf ? 'As of ' + fd(asOf) : 'As of today') + (sum?.depts.length ? ' · ' + sum.depts.join(', ') : ''),
      blocks: [
        { label: 'Total issued', value: String(sum?.issued || 0) },
        { label: 'Returned', value: String(sum?.returned || 0) },
        { label: 'Holding now', value: String(sum?.current || 0) + ' pcs' },
        { label: 'Value', value: inr(sum?.currentValue || 0) },
        { label: 'Drives', value: drivesNow.map((d) => d.displayName).join(', ') || '—' },
      ],
      head: ['Item', 'Category', 'Issued', 'Returned', 'Damaged', 'Holding now', 'First issue', 'Last'],
      align: ['left', 'left', 'right', 'right', 'right', 'right', 'left', 'left'],
      sections: [{ rows: holdings.map((h) => [h.itemName, h.category, String(h.issued), String(h.returned), String(h.damaged || ''), String(h.current), fd(h.first), fd(h.last)]) }],
      grandFoot: ['Total', '', String(holdings.reduce((a, h) => a + h.issued, 0)), String(holdings.reduce((a, h) => a + h.returned, 0)), String(holdings.reduce((a, h) => a + h.damaged, 0) || ''), String(holdings.reduce((a, h) => a + h.current, 0)), '', ''],
    });
  const printTxns = () =>
    setPrint({
      title: name + ' — Item history',
      subtitle: [from || to ? (from ? fd(from) : '…') + ' → ' + (to ? fd(to) : '…') : 'All dates', itemQ && 'Item: ' + itemQ].filter(Boolean).join(' · '),
      head: ['Date', 'Type', 'Item', 'Qty', 'Department', 'Location', 'Purpose', 'Note'],
      align: ['left', 'left', 'left', 'right', 'left', 'left', 'left', 'left'],
      sections: [{ rows: txns.map((r) => [fd(r.date), kindLabel(r), r.itemName, (r.kind === 'issue' ? '+' : '−') + r.qty, r.dept, r.location, r.purpose, r.note]) }],
    });

  if (!sum && !person && !drivesNow.length && !driveHist.length && !data.length && !events.length) {
    return (
      <Card>
        <Empty icon={UserRound} title="Ye naam kahin nahi mila" action={<Link className="btn" href="/persons">All persons</Link>} />
      </Card>
    );
  }

  return (
    <>
      <PageHeader
        title={
          <span className="u-row" style={{ gap: 10 }}>
            {name}
            {person?.status === 'inactive' && <Badge tone="gray">Inactive</Badge>}
          </span>
        }
        sub={[Array.from(new Set([...(person?.depts || []), ...(sum?.depts || [])])).join(', '), person?.location, person?.responsibilities].filter(Boolean).join(' · ') || 'Person'}
        actions={
          <>
            {A.can('persons', 'edit') && (
              <button type="button" className="btn" onClick={() => setEdit(true)}>
                <Pencil aria-hidden className="ic" /> {person ? 'Edit profile' : 'Create profile'}
              </button>
            )}
            <button type="button" className="btn" onClick={tab === 'txns' ? printTxns : printHoldings}>
              <Printer aria-hidden className="ic" /> Print
            </button>
            <button
              type="button"
              className="btn"
              onClick={() =>
                tab === 'txns'
                  ? exportXlsx(name + ' history', ['Date', 'Type', 'Item', 'Qty', 'Department', 'Location', 'Purpose', 'Note'], txns.map((r) => [r.date, kindLabel(r), r.itemName, r.kind === 'issue' ? r.qty : -r.qty, r.dept, r.location, r.purpose, r.note]), ['date', 'text', 'text', 'number'])
                  : exportXlsx(name + ' holdings', ['Item', 'Category', 'Issued', 'Returned', 'Damaged', 'Holding now', 'First', 'Last'], holdings.map((h) => [h.itemName, h.category, h.issued, h.returned, h.damaged, h.current, h.first, h.last]), ['text', 'text', 'number', 'number', 'number', 'number'])
              }
            >
              <FileSpreadsheet aria-hidden className="ic" /> Excel
            </button>
            {A.can('reports', 'view') && (
              <button type="button" className="btn ghost" onClick={() => router.push('/reports?dataset=ledger&person=' + encodeURIComponent(name))}>
                Report builder
              </button>
            )}
          </>
        }
      />
      <div className="u-grid c4">
        <Stat index={0} label="Total issued (pcs)" value={sum?.issued || 0} icon={Package} sub={(sum?.txns || 0) + ' entries'} />
        <Stat index={1} label="Returned" value={sum?.returned || 0} icon={Package} tone="green" sub={sum?.damaged ? sum.damaged + ' damaged' : undefined} />
        <Stat index={2} label={asOf ? 'Holding on ' + fd(asOf) : 'Holding now'} value={sum?.current || 0} icon={Package} tone="violet" sub={inr(sum?.currentValue || 0)} />
        <Stat index={3} label="Drives with them" value={drivesNow.length} format={(n) => String(Math.round(n))} icon={HardDrive} tone="blue" sub={gb(drivesNow.reduce((a, d) => a + d.capacityGB, 0)) + ' · ' + data.length + ' data · ' + events.length + ' events'} />
      </div>
      {unattrib.length > 0 && (
        <Alert tone="amber" icon={Info}>
          Purani entries me {unattrib.map((u) => u.itemName + ' (' + u.qty + ')').join(', ') + ' '}wapas aaye the par naam nahi likha tha, aur ye item kai logo ko diya gaya tha — isliye wo kisi ke hisaab me nahi jode. Aage se wapsi me naam chuno.
        </Alert>
      )}
      <div className="u-toolbar">
        <label className="u-search">
          <Search aria-hidden />
          <input value={itemQ} onChange={(e) => setItemQ(e.target.value)} placeholder="Item dhoondho (jaise keyboard)" aria-label="Filter items" />
        </label>
        <Field label="As of date">
          <input type="date" value={asOf} onChange={(e) => setAsOf(e.target.value)} />
        </Field>
        {tab === 'txns' && (
          <>
            <Field label="From">
              <input type="date" value={from} onChange={(e) => setFrom(e.target.value)} />
            </Field>
            <Field label="To">
              <input type="date" value={to} onChange={(e) => setTo(e.target.value)} />
            </Field>
          </>
        )}
      </div>
      <Tabs
        value={tab}
        onChange={setTab}
        tabs={[
          { value: 'items', label: 'Items held (' + holdings.length + ')' },
          { value: 'txns', label: 'Date-wise history (' + txns.length + ')' },
          { value: 'drives', label: 'Drives (' + drivesNow.length + ')' },
          { value: 'data', label: 'Data (' + data.length + ')' },
          { value: 'events', label: 'Events (' + events.length + ')' },
        ]}
      />
      {tab === 'items' && (
        <Card>
          {holdings.length === 0 ? (
            <Empty icon={Package} title="Koi item nahi" />
          ) : (
            <div className="u-table-wrap" style={{ maxHeight: 'none' }}>
              <table className="u-table">
                <thead>
                  <tr>
                    <th>Item</th>
                    <th>Category</th>
                    <th className="num">Issued</th>
                    <th className="num">Returned</th>
                    <th className="num">Damaged</th>
                    <th className="num">Holding now</th>
                    <th>First issue</th>
                    <th>Last</th>
                  </tr>
                </thead>
                <tbody>
                  {holdings.map((h) => (
                    <tr key={h.itemKey} className="click" onClick={() => { setItemQ(h.itemName); setTab('txns'); }}>
                      <td>
                        <b>{h.itemName}</b>
                      </td>
                      <td>{h.category}</td>
                      <td className="num">{h.issued}</td>
                      <td className="num">{h.returned || '—'}</td>
                      <td className="num">{h.damaged || '—'}</td>
                      <td className="num">
                        <Badge tone={h.current > 0 ? 'indigo' : 'gray'} plain>
                          {h.current}
                        </Badge>
                      </td>
                      <td>{fd(h.first)}</td>
                      <td>{fd(h.last)}</td>
                    </tr>
                  ))}
                </tbody>
                <tfoot>
                  <tr>
                    <td colSpan={2} style={{ fontWeight: 800 }}>Total</td>
                    <td className="num" style={{ fontWeight: 800 }}>{holdings.reduce((a, h) => a + h.issued, 0)}</td>
                    <td className="num" style={{ fontWeight: 800 }}>{holdings.reduce((a, h) => a + h.returned, 0)}</td>
                    <td className="num" style={{ fontWeight: 800 }}>{holdings.reduce((a, h) => a + h.damaged, 0)}</td>
                    <td className="num" style={{ fontWeight: 800 }}>{holdings.reduce((a, h) => a + h.current, 0)}</td>
                    <td colSpan={2} />
                  </tr>
                </tfoot>
              </table>
            </div>
          )}
          <p className="hint" style={{ padding: '0 18px 14px' }}>Item pe click karo — us item ki har tareekh ki entry dikhegi.</p>
        </Card>
      )}
      {tab === 'txns' && <TxnTable rows={txns} />}
      {tab === 'drives' && (
        <div className="u-stack">
          <Card title="Abhi inke paas">
            {drivesNow.length === 0 ? (
              <p className="u-muted">Koi drive nahi.</p>
            ) : (
              <ul style={{ listStyle: 'none', margin: 0, padding: 0 }}>
                {drivesNow.map((d) => (
                  <li key={d.id} className="u-between" style={{ padding: '8px 0', borderBottom: '1px solid var(--line)' }}>
                    <Link className="u-link" href={'/drives/' + d.id}>
                      {d.displayName}
                    </Link>
                    <span className="u-sm u-muted">
                      {gb(d.capacityGB)} · since {fd(d.holder?.since || '')} {d.holder?.expectedReturn ? '· return by ' + fd(d.holder.expectedReturn) : ''} · {A.catalog.filter((c) => c.driveId === d.id).length} data records
                    </span>
                  </li>
                ))}
              </ul>
            )}
          </Card>
          <Card title="Drive history">
            {driveHist.length === 0 ? (
              <p className="u-muted">Koi history nahi.</p>
            ) : (
              <table className="u-table">
                <thead>
                  <tr>
                    <th>Date</th>
                    <th>Drive</th>
                    <th>Action</th>
                    <th>From → To</th>
                    <th>Purpose</th>
                  </tr>
                </thead>
                <tbody>
                  {driveHist.map((t) => (
                    <tr key={t.id} className="click" onClick={() => router.push('/drives/' + t.driveId)}>
                      <td>{fd(t.date)}</td>
                      <td>{t.mark}</td>
                      <td>{TRANSFER_LABEL[t.kind]}</td>
                      <td>
                        {t.from.name || '—'} → {t.to.name || '—'}
                      </td>
                      <td>{t.purpose}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            )}
          </Card>
        </div>
      )}
      {tab === 'data' && (
        <Card title="Data jiski zimmedari inki hai">
          {data.length === 0 ? (
            <p className="u-muted">Koi data record nahi.</p>
          ) : (
            <table className="u-table">
              <thead>
                <tr>
                  <th>Data</th>
                  <th>Event</th>
                  <th>Drive</th>
                  <th>Drive is</th>
                  <th className="num">Size</th>
                </tr>
              </thead>
              <tbody>
                {data.map((c) => {
                  const d = A.driveMap.get(c.driveId);
                  return (
                    <tr key={c.id} className="click" onClick={() => router.push('/catalog?open=' + c.id)}>
                      <td>
                        <b>{[c.project, c.title].filter(Boolean).join(' · ')}</b>
                      </td>
                      <td>{c.eventName || '—'}</td>
                      <td>{d?.displayName || '—'}</td>
                      <td>{d ? whereIs(d, A.locMap) : '—'}</td>
                      <td className="num">{c.sizeGB ? gb(c.sizeGB) : '—'}</td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          )}
        </Card>
      )}
      {tab === 'events' && (
        <Card title="Events jisme ye the">
          {events.length === 0 ? (
            <p className="u-muted">Koi event nahi.</p>
          ) : (
            <ul style={{ listStyle: 'none', margin: 0, padding: 0 }}>
              {events.map((e) => (
                <li key={e.id} className="u-between" style={{ padding: '8px 0', borderBottom: '1px solid var(--line)' }}>
                  <Link className="u-link" href={'/events/' + e.id}>
                    {e.type}: {e.title}
                  </Link>
                  <span className="u-sm u-muted">
                    <CalendarDays aria-hidden className="ic" style={{ width: 14, height: 14, verticalAlign: -2 }} /> {fd(e.date)} · {e.location} · {roleIn(e, mine)}
                  </span>
                </li>
              ))}
            </ul>
          )}
        </Card>
      )}
      {edit && <PersonForm person={person || null} presetName={name} onClose={() => setEdit(false)} />}
      {print && <PrintDesignerModal open onClose={() => setPrint(null)} doc={print} storeKey="person" />}
    </>
  );
}

function roleIn(e: { participants: string[]; mainPersons: string[]; recordingTeam: string[]; submittedBy: string; receivedBy: string; responsible: string }, mine: (n: string) => boolean) {
  const r: string[] = [];
  if (e.mainPersons.some(mine)) r.push('main person');
  else if (e.participants.some(mine)) r.push('present');
  if (e.recordingTeam.some(mine)) r.push('recording team');
  if (mine(e.submittedBy)) r.push('data submitted');
  if (mine(e.receivedBy)) r.push('data received');
  if (mine(e.responsible)) r.push('responsible');
  return r.join(', ');
}

const kindLabel = (r: LedgerRow) => (r.kind === 'issue' ? 'Issued' : r.kind === 'return' ? 'Returned' + (r.source === 'auto' ? ' (old entry)' : '') : 'Damaged');

function TxnTable({ rows }: { rows: LedgerRow[] }) {
  const { openEntry } = useReg();
  if (!rows.length)
    return (
      <Card>
        <Empty icon={Package} title="Is filter me koi entry nahi" />
      </Card>
    );
  let bal = 0;
  return (
    <Card>
      <div className="u-table-wrap" style={{ maxHeight: 'none' }}>
        <table className="u-table">
          <thead>
            <tr>
              <th>Date</th>
              <th>Type</th>
              <th>Item</th>
              <th className="num">Qty</th>
              <th className="num">Running total</th>
              <th>Department</th>
              <th>Location</th>
              <th>Purpose</th>
              <th>Note</th>
            </tr>
          </thead>
          <tbody>
            {rows.map((r) => {
              bal += r.kind === 'issue' ? r.qty : -r.qty;
              return (
                <tr key={r.id} className="click" onClick={() => openEntry(r.itemId)}>
                  <td className="nowrap">{fd(r.date)}</td>
                  <td>
                    <Badge tone={r.kind === 'issue' ? 'indigo' : r.kind === 'return' ? 'green' : 'red'}>{kindLabel(r)}</Badge>
                  </td>
                  <td>
                    <b>{r.itemName}</b>
                  </td>
                  <td className="num">{(r.kind === 'issue' ? '+' : '−') + r.qty}</td>
                  <td className="num">{bal}</td>
                  <td>{r.dept}</td>
                  <td>{r.location}</td>
                  <td>{r.purpose}</td>
                  <td className="u-sm">{r.note}</td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </Card>
  );
}

/* ======================= DEPARTMENTS ======================= */
export function DepartmentsPage() {
  const A = useAssets();
  const router = useRouter();
  const { src } = useSources();
  const [form, setForm] = useState<Department | null | 'new'>(null);
  const list = useMemo(() => {
    const ds = allDepts({ depts: A.depts, rows: src.ledger, drives: A.drives, catalog: A.catalog, persons: A.persons });
    return ds.map((d) => {
      const k = d.key;
      const match = (s: string) => nameKey(s) === k || (d.dept?.aliases || []).some((a) => nameKey(a) === nameKey(s));
      const rows = src.ledger.filter((r) => match(r.dept));
      const issued = rows.filter((r) => r.kind === 'issue').reduce((a, r) => a + r.qty, 0);
      const back = rows.filter((r) => r.kind !== 'issue').reduce((a, r) => a + r.qty, 0);
      const value = rows.reduce((a, r) => a + (r.kind === 'issue' ? r.value : -r.value), 0);
      const drives = A.drives.filter((x) => match(x.holder?.dept || x.dept));
      const members = new Set(rows.map((r) => r.person).filter(Boolean).concat(A.persons.filter((p) => p.depts.some(match)).map((p) => p.name)));
      return { id: k, key: k, name: d.name, dept: d.dept, issued, current: issued - back, value, drives: drives.length, storage: drives.reduce((a, x) => a + x.capacityGB, 0), data: A.catalog.filter((c) => match(c.dept)).length, members: members.size, archived: !!d.dept?.archived };
    });
  }, [A, src]);
  type DR = (typeof list)[number];
  const cols: Col<DR>[] = [
    { key: 'name', label: 'Department', value: (r) => r.name, render: (r) => <b>{r.name}{r.archived ? ' (archived)' : ''}</b> },
    { key: 'members', label: 'Members', num: true, value: (r) => r.members, render: (r) => r.members || '—', card: true },
    { key: 'issued', label: 'Items issued', num: true, value: (r) => r.issued, render: (r) => r.issued || '—' },
    { key: 'current', label: 'With dept now', num: true, value: (r) => r.current, render: (r) => r.current || '—', card: true },
    { key: 'value', label: 'Value now', num: true, value: (r) => r.value, render: (r) => (r.value ? inr(r.value) : '—') },
    { key: 'drives', label: 'Drives', num: true, value: (r) => r.drives, render: (r) => (r.drives ? r.drives + ' · ' + gb(r.storage) : '—'), card: true },
    { key: 'data', label: 'Data records', num: true, value: (r) => r.data, render: (r) => r.data || '—' },
  ];
  return (
    <>
      <PageHeader
        title="Departments"
        sub="Live Department, Computer Room, Delhi Office… har department me kya gaya, kaun log, kaunsi drives, kaunsa data."
        actions={
          A.can('persons', 'create') && (
            <button type="button" className="btn primary" onClick={() => setForm('new')}>
              <Plus aria-hidden className="ic" /> Add department
            </button>
          )
        }
      />
      <DataTable id="depts" rows={list} cols={cols} exportName="departments" searchText={(r) => r.name} onRow={(r) => router.push('/departments/' + encodeURIComponent(r.key))} cardTitle={(r) => <b>{r.name}</b>} initialSort={{ key: 'name', dir: 'asc' }} empty={<Empty icon={Building2} title="Abhi koi department nahi" />} />
      {form && <DeptForm dept={form === 'new' ? null : form} onClose={() => setForm(null)} />}
    </>
  );
}

export function DeptForm({ dept, presetName = '', onClose }: { dept: Department | null; presetName?: string; onClose: () => void }) {
  const { me, toast } = useReg();
  const [name, setName] = useState(dept?.name || presetName);
  const [aliases, setAliases] = useState(dept?.aliases.join(', ') || '');
  const [head, setHead] = useState(dept?.head || '');
  const [location, setLocation] = useState(dept?.location || '');
  const [notes, setNotes] = useState(dept?.notes || '');
  const [archived, setArchived] = useState(!!dept?.archived);
  const [busy, run] = useBusy();
  return (
    <Modal
      open
      size="sm"
      onClose={onClose}
      title={dept ? 'Edit department' : 'New department'}
      onSubmit={() =>
        run(async () => {
          if (!name.trim()) return;
          try {
            await saveDept({ name: name.trim(), aliases: aliases.split(',').map((x) => x.trim()).filter(Boolean), head: head.trim(), location: location.trim(), notes: notes.trim(), archived }, me, dept?.id);
            toast('✓ Saved');
            onClose();
          } catch {
            toast('Save nahi hua');
          }
        })
      }
      foot={
        <>
          <button type="button" className="btn" onClick={onClose}>
            Cancel
          </button>
          <button type="submit" className="btn primary" disabled={busy}>
            Save
          </button>
        </>
      }
    >
      <div className="fgrid">
        <Field label="Naam" span>
          <input value={name} onChange={(e) => setName(e.target.value)} required autoFocus maxLength={80} />
        </Field>
        <Field label="Dusre naam (comma)" span hint="Jaise 'Live', 'Live Setup' — sab isi department me judenge">
          <input value={aliases} onChange={(e) => setAliases(e.target.value)} />
        </Field>
        <Field label="Head / incharge">
          <input value={head} onChange={(e) => setHead(e.target.value)} list="dl-allpeople" />
        </Field>
        <Field label="Jagah">
          <input value={location} onChange={(e) => setLocation(e.target.value)} list="dl-places" />
        </Field>
        <Field label="Note" span>
          <input value={notes} onChange={(e) => setNotes(e.target.value)} />
        </Field>
        <label className="u-check">
          <input type="checkbox" checked={archived} onChange={(e) => setArchived(e.target.checked)} /> Archived (band)
        </label>
      </div>
    </Modal>
  );
}

export function DeptProfile({ dkey }: { dkey: string }) {
  const A = useAssets();
  const router = useRouter();
  const { src } = useSources();
  const [edit, setEdit] = useState(false);
  const [print, setPrint] = useState<PrintTable | null>(null);
  const dept = A.depts.find((d) => nameKey(d.name) === dkey);
  const match = (s: string) => !!s && (nameKey(s) === dkey || (dept?.aliases || []).some((a) => nameKey(a) === nameKey(s)));
  const rows = src.ledger.filter((r) => match(r.dept));
  const name = dept?.name || rows[0]?.dept || decodeURIComponent(dkey);
  const byItem = new Map<string, { item: string; issued: number; back: number; people: Set<string> }>();
  for (const r of rows) {
    const k = nameKey(r.itemName);
    const x = byItem.get(k) || { item: r.itemName, issued: 0, back: 0, people: new Set<string>() };
    if (r.kind === 'issue') x.issued += r.qty;
    else x.back += r.qty;
    if (r.person) x.people.add(r.person);
    byItem.set(k, x);
  }
  const items = Array.from(byItem.values()).sort((a, b) => b.issued - b.back - (a.issued - a.back));
  const drives = A.drives.filter((x) => match(x.holder?.dept || x.dept));
  const data = A.catalog.filter((c) => match(c.dept));
  const members = Array.from(new Set(rows.map((r) => r.person).filter(Boolean).concat(A.persons.filter((p) => p.depts.some(match)).map((p) => p.name))));
  return (
    <>
      <PageHeader
        title={name}
        sub={[dept?.head && 'Head: ' + dept.head, dept?.location, members.length + ' members'].filter(Boolean).join(' · ')}
        actions={
          <>
            {A.can('persons', 'edit') && (
              <button type="button" className="btn" onClick={() => setEdit(true)}>
                <Pencil aria-hidden className="ic" /> {dept ? 'Edit' : 'Create profile'}
              </button>
            )}
            <button
              type="button"
              className="btn"
              onClick={() =>
                setPrint({
                  title: name + ' — Items',
                  subtitle: members.join(', '),
                  head: ['Item', 'Issued', 'Returned', 'With dept now', 'Persons'],
                  align: ['left', 'right', 'right', 'right', 'left'],
                  sections: [{ rows: items.map((i) => [i.item, String(i.issued), String(i.back), String(i.issued - i.back), Array.from(i.people).join(', ')]) }],
                  blocks: [{ label: 'Drives', value: drives.map((d) => d.displayName).join(', ') || '—' }],
                })
              }
            >
              <Printer aria-hidden className="ic" /> Print
            </button>
            {A.can('reports', 'view') && (
              <button type="button" className="btn ghost" onClick={() => router.push('/reports?dataset=ledger&dept=' + encodeURIComponent(name))}>
                Report builder
              </button>
            )}
          </>
        }
      />
      <div className="u-grid c4">
        <Stat index={0} label="Members" value={members.length} icon={Users} />
        <Stat index={1} label="Items issued (pcs)" value={rows.filter((r) => r.kind === 'issue').reduce((a, r) => a + r.qty, 0)} icon={Package} tone="violet" />
        <Stat index={2} label="Drives" value={drives.length} icon={HardDrive} tone="blue" sub={gb(drives.reduce((a, d) => a + d.capacityGB, 0))} />
        <Stat index={3} label="Data records" value={data.length} icon={Database} tone="green" />
      </div>
      <div className="u-grid c2">
        <Card title="Items">
          {items.length === 0 ? (
            <p className="u-muted">Koi item nahi.</p>
          ) : (
            <table className="u-table">
              <thead>
                <tr>
                  <th>Item</th>
                  <th className="num">Issued</th>
                  <th className="num">Returned</th>
                  <th className="num">Now</th>
                  <th>Persons</th>
                </tr>
              </thead>
              <tbody>
                {items.map((i) => (
                  <tr key={i.item}>
                    <td>
                      <b>{i.item}</b>
                    </td>
                    <td className="num">{i.issued}</td>
                    <td className="num">{i.back || '—'}</td>
                    <td className="num">{i.issued - i.back}</td>
                    <td className="u-sm">{Array.from(i.people).join(', ')}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </Card>
        <div className="u-stack">
          <Card title="Members">
            <div className="u-row">
              {members.map((m) => (
                <Link key={m} href={'/persons/' + encodeURIComponent(nameKey(m))} className="u-chip">
                  {m}
                </Link>
              ))}
              {!members.length && <span className="u-muted">—</span>}
            </div>
          </Card>
          <Card title="Drives">
            {drives.length === 0 ? (
              <p className="u-muted">Koi drive nahi.</p>
            ) : (
              drives.map((d) => (
                <div key={d.id} className="u-between" style={{ padding: '6px 0' }}>
                  <Link className="u-link" href={'/drives/' + d.id}>
                    {d.displayName}
                  </Link>
                  <span className="u-sm u-muted">
                    {gb(d.capacityGB)} · {DRIVE_STATUS_LABEL[d.status]} · {whereIs(d, A.locMap)}
                  </span>
                </div>
              ))
            )}
          </Card>
        </div>
      </div>
      {edit && <DeptForm dept={dept || null} presetName={name} onClose={() => setEdit(false)} />}
      {print && <PrintDesignerModal open onClose={() => setPrint(null)} doc={print} storeKey="dept" />}
    </>
  );
}
