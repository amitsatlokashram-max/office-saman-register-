'use client';

// App ka dhancha: login gate, live data (purchases + naye modules), grouped sidebar, header (breadcrumbs, global search,
// notifications, quick add, theme, bhasha), phone ke liye bottom nav, aur purane modals/print jo har page pe chahiye.

import Link from 'next/link';
import { usePathname, useRouter } from 'next/navigation';
import { AnimatePresence, MotionConfig, motion, useReducedMotion } from 'motion/react';
import { useCallback, useEffect, useMemo, useRef, useState, type ReactNode } from 'react';
import {
  Bell,
  Boxes,
  ChevronDown,
  ChevronRight,
  Database,
  HardDrive,
  Languages,
  LayoutDashboard,
  LogOut,
  Menu,
  Moon,
  PanelLeftClose,
  PanelLeftOpen,
  Plus,
  ScanLine,
  Search,
  Sun,
  Package,
  ArrowLeftRight,
} from 'lucide-react';

import { fetchAiStatus, type AiStatus } from '@/lib/ai';
import { buildAlerts } from '@/lib/assets/alerts';
import { subscribeAccess, subscribeProfile, type AccessDoc } from '@/lib/assets/db';
import { copyState } from '@/lib/assets/model';
import { saveFile } from '@/lib/bills';
import { DEF, EMPTY_FILTERS, allIssues, distinct, initials, stockGroups } from '@/lib/calc';
import { buildCsv } from '@/lib/csv';
import { configOK, missingFirebaseConfig, setNotifier, signInGoogle, signOutUser, subscribeItems, subscribeMin, watchAuth, writeMin } from '@/lib/firebase';
import { fetchGoogleStatus } from '@/lib/google';
import { LangProvider, useLang } from '@/lib/i18n';
import { authMsg, explain } from '@/lib/messages';
import { ROLE_LABEL } from '@/lib/perm';
import { COLOR_KEY, MODE_KEY, applyTheme, setThemePref } from '@/lib/theme';
import { initSync, setSyncMe, type SyncState } from '@/lib/sync';
import type { Filters, Item, Me, MinMap, Tab } from '@/lib/types';

import { AssetsProvider, resolveAccess, useAssets } from './assets/store';
import { RegContext, useReg, type Reg } from './context';
import { EntryDrawer } from './EntryDrawer';
import { EntryPrint } from './EntryPrint';
import { Gate, type GateKind } from './Gate';
import { ItemFormModal } from './ItemFormModal';
import { IssueModal, Lightbox, MoveModal } from './Modals';
import { CommandPalette } from './shell/CommandPalette';
import { NAV, crumbFor } from './shell/nav';
import { NotificationPanel } from './shell/Notifications';
import { useToast } from './Toast';

type Phase = GateKind | 'ready';

/* ---------- THEME ---------- */
const THEME_MODE_KEY = MODE_KEY;
const THEME_COLOR_KEY = COLOR_KEY;
const applySavedTheme = () => applyTheme();
/** Owner / main admin ka default dikhne wala naam (profile me badal sakte ho) */
const ADMIN_NAME = (process.env.NEXT_PUBLIC_ADMIN_NAME || 'Amit').trim() || 'Amit';

/** Purane code ke liye (kuch jagah PAGES import hota tha). */
export const PAGES = NAV.flatMap((g) => g.items).map((n) => ({ href: n.href, label: n.label, id: 'nav-' + n.href.replace(/\W+/g, '-') }));

export default function Shell({ children }: { children: ReactNode }) {
  return (
    <LangProvider>
      <MotionConfig reducedMotion="user">
        <ShellInner>{children}</ShellInner>
      </MotionConfig>
    </LangProvider>
  );
}

function ShellInner({ children }: { children: ReactNode }) {
  const router = useRouter();
  const path = usePathname() || '/';

  const [phase, setPhase] = useState<Phase>(configOK ? 'loading' : 'setup');
  const [didCheckAuth, setDidCheckAuth] = useState(false);
  const [me, setMe] = useState<Me | null>(null);
  const [items, setItems] = useState<Item[]>([]);
  const [minMap, setMinMap] = useState<MinMap>({});
  const [f, setF] = useState<Filters>(EMPTY_FILTERS);
  const [noticeMsg, setNoticeMsg] = useState('');
  const [accessDoc, setAccessDoc] = useState<AccessDoc | null>(null);
  const [itemsState, setItemsState] = useState<'wait' | 'ok' | 'denied'>('wait');
  const [profileName, setProfileName] = useState('');

  const [ai, setAi] = useState<AiStatus>({ enabled: false, provider: '' });
  const [googleOn, setGoogleOn] = useState(false);
  const [sync, setSync] = useState<SyncState>({ enabled: false, pending: 0, pendingIds: [], running: false, lastOk: '', lastErr: '' });

  const [openId, setOpenId] = useState<string | null>(null);
  const [form, setForm] = useState<{ editId: string | null } | null>(null);
  const [issueFor, setIssueFor] = useState<string | null>(null);
  const [moveFor, setMoveFor] = useState<string | null>(null);
  const [photo, setPhoto] = useState<{ url: string; name: string } | null>(null);
  const [slipId, setSlipId] = useState<string | null>(null);

  const { show: toast, node: toastNode } = useToast();
  const itemsRef = useRef<Item[]>([]);
  const meRef = useRef<Me | null>(null);
  const lastUid = useRef('');
  itemsRef.current = items;

  useEffect(() => {
    applySavedTheme();
    const onStorage = (e: StorageEvent) => {
      if (e.key === THEME_MODE_KEY || e.key === THEME_COLOR_KEY || e.key === null) applySavedTheme();
    };
    window.addEventListener('storage', onStorage);
    return () => window.removeEventListener('storage', onStorage);
  }, []);

  /* ---------- FIREBASE ---------- */
  useEffect(() => {
    setNotifier({
      late: (e) => toast(explain(e)),
      queued: () => toast('You are offline. This entry is saved on this device and will sync when you reconnect.'),
    });
  }, [toast]);

  useEffect(() => {
    if (!configOK) return;
    return watchAuth(
      (m) => {
        setMe(m);
        if (!m) {
          setItems([]);
          setAccessDoc(null);
          setItemsState('wait');
          setPhase('login');
        } else if (!didCheckAuth) setDidCheckAuth(true);
        // Wahi user dobara aaya (listener re-subscribe) to khula hua page mat giraao
        else setPhase((p) => (p === 'ready' && lastUid.current === m.uid ? p : 'loading'));
        lastUid.current = m ? m.uid : '';
      },
      (e) => toast(authMsg(e)),
    );
  }, [toast, didCheckAuth]);

  const uidKey = me?.uid ?? '';

  useEffect(() => {
    if (!uidKey || !accessDoc) return;
    return subscribeProfile(uidKey, (p) => setProfileName(p?.displayName || ''));
  }, [uidKey, !!accessDoc]); // eslint-disable-line react-hooks/exhaustive-deps

  // Dikhne wala naam: profile ka naam, warna owner = "Amit", warna Google ka naam. Login identity nahi badalti.
  const meView = useMemo<Me | null>(() => {
    if (!me) return null;
    const owner = resolveAccess(me, accessDoc)?.isOwner;
    return { ...me, name: profileName || (owner ? ADMIN_NAME : me.name) };
  }, [me, profileName, accessDoc]);

  // Pehle access (role + permission) padho. Ye na padh sake = register ka member nahi.
  useEffect(() => {
    if (!uidKey) return;
    return subscribeAccess(
      (a) => setAccessDoc(a),
      (code) => {
        if (code === 'permission-denied') setPhase('denied');
        else setNoticeMsg('Could not load access settings. Check your internet connection and reload.');
      },
    );
  }, [uidKey]);

  useEffect(() => {
    if (!uidKey || !accessDoc) return;
    const u1 = subscribeItems(
      (list) => {
        setItems(list);
        setItemsState('ok');
        setNoticeMsg('');
      },
      (code) => {
        if (code === 'permission-denied') setItemsState('denied');
        else {
          setItemsState('ok');
          setNoticeMsg('The register is not updating. Check your internet connection and reload the page.');
        }
      },
    );
    const u2 = subscribeMin(setMinMap);
    return () => {
      u1();
      u2();
    };
  }, [uidKey, !!accessDoc]); // eslint-disable-line react-hooks/exhaustive-deps

  // Access + purchases dono aa gaye to app dikhao (auth dobara fire ho kar 'loading' kare tab bhi wapas 'ready').
  useEffect(() => {
    if (phase === 'loading' && accessDoc && itemsState !== 'wait') setPhase('ready');
  }, [phase, accessDoc, itemsState]);

  useEffect(() => {
    if (phase !== 'ready') return;
    let live = true;
    fetchAiStatus().then((s) => live && setAi(s));
    fetchGoogleStatus().then((on) => {
      if (!live) return;
      setGoogleOn(on);
      initSync({ enabled: on, getItem: (id) => itemsRef.current.find((x) => x.id === id), me: meRef.current, notify: toast, onChange: setSync });
    });
    return () => {
      live = false;
    };
  }, [phase, toast]);

  useEffect(() => {
    meRef.current = meView;
    setSyncMe(meView);
  }, [meView]);

  /* ---------- PRINT (ek entry ki parchi) ---------- */
  useEffect(() => {
    if (!slipId) return;
    const html = document.documentElement;
    html.classList.add('slip-mode');
    const done = () => setSlipId(null);
    window.addEventListener('afterprint', done, { once: true });
    const t = window.setTimeout(() => window.print(), 120);
    return () => {
      window.clearTimeout(t);
      window.removeEventListener('afterprint', done);
      html.classList.remove('slip-mode');
    };
  }, [slipId]);

  /* ---------- ACTIONS ---------- */
  const signIn = async (remember: boolean) => {
    try {
      await signInGoogle(remember);
    } catch (e) {
      toast(authMsg(e));
    }
  };
  const signOutNow = useCallback(() => {
    setOpenId(null);
    signOutUser().catch(() => {});
  }, []);

  const minRef = useRef<MinMap>({});
  minRef.current = minMap;
  const saveMin = useCallback(
    (key: string, n: number) => {
      const m = { ...minRef.current };
      if (n > 0) m[key] = n;
      else delete m[key];
      minRef.current = m;
      setMinMap(m);
      writeMin(m).then(
        () => toast(n > 0 ? 'Minimum stock set to ' + n : 'Minimum stock level removed'),
        (e) => toast(explain(e)),
      );
    },
    [toast],
  );

  const goList = useCallback(
    (patch: Partial<Filters>, to = '/saman') => {
      setF((p) => ({ ...EMPTY_FILTERS, sort: p.sort, ...patch }));
      router.push(to);
    },
    [router],
  );
  const clearFilters = useCallback(() => setF((p) => ({ ...EMPTY_FILTERS, sort: p.sort })), []);
  const groups = useMemo(() => stockGroups(items, minMap), [items, minMap]);

  const exportCsv = useCallback(
    (tab: Tab) => {
      const { name, text } = buildCsv(tab, itemsRef.current, groups, f);
      saveFile(name, new Blob([text], { type: 'text/csv;charset=utf-8' }));
      toast('File downloaded. Open it in Excel.');
    },
    [groups, f, toast],
  );
  const printPage = useCallback(() => {
    setSlipId(null);
    document.documentElement.classList.remove('slip-mode');
    window.print();
  }, []);
  const printEntry = useCallback((id: string) => {
    setOpenId(null);
    setSlipId(id);
  }, []);
  const newEntry = useCallback(() => setForm({ editId: null }), []);
  const getItem = useCallback((id: string) => itemsRef.current.find((x) => x.id === id), []);

  const reg = useMemo<Reg>(
    () => ({
      me: meView,
      items,
      getItem,
      toast,
      notice: setNoticeMsg,
      ai,
      groups,
      f,
      setF,
      clearFilters,
      goList,
      openEntry: setOpenId,
      newEntry,
      saveMin,
      exportCsv,
      printPage,
      printEntry,
      google: { enabled: googleOn, sync },
      signOut: signOutNow,
    }),
    [meView, items, getItem, toast, ai, groups, f, clearFilters, goList, newEntry, saveMin, exportCsv, printPage, printEntry, googleOn, sync, signOutNow],
  );

  const iss = allIssues(items);
  const lists = {
    item: distinct(items.map((i) => i.item)),
    category: distinct(DEF.category.concat(items.map((i) => i.category))),
    vendor: distinct(DEF.vendor.concat(items.map((i) => i.vendor))),
    brought: distinct(DEF.brought.concat(items.map((i) => i.broughtBy))),
    person: distinct(iss.map((i) => i.person)),
    dept: distinct(DEF.dept.concat(iss.map((i) => i.dept))),
  };
  const slipItem = slipId ? items.find((x) => x.id === slipId) : undefined;

  return (
    <RegContext.Provider value={reg}>
      {phase !== 'ready' ? (
        <Gate kind={phase} email={me?.email} missingConfig={missingFirebaseConfig} onSignIn={signIn} onSignOut={signOutNow} />
      ) : (
        <AssetsProvider me={meView} accessDoc={accessDoc}>
          <div className="aurora-bg" aria-hidden>
            <i />
            <i />
            <i />
          </div>
          <AppFrame path={path} notice={noticeMsg} itemsDenied={itemsState === 'denied'} counts={{ items: items.length, stock: groups.length, issues: iss.length }}>
            {children}
          </AppFrame>
          {/* SHARED DATALISTS */}
          {(Object.keys(lists) as (keyof typeof lists)[]).map((k) => (
            <datalist id={'dl-' + k} key={k}>
              {lists[k].map((v) => (
                <option value={v} key={v} />
              ))}
            </datalist>
          ))}
          <AssetDatalists />
        </AssetsProvider>
      )}

      <EntryDrawer id={openId} onClose={() => setOpenId(null)} onEdit={(id) => setForm({ editId: id })} onIssue={setIssueFor} onMove={setMoveFor} onViewBill={setPhoto} />
      <ItemFormModal open={!!form} editId={form?.editId ?? null} onClose={() => setForm(null)} />
      <IssueModal itemId={issueFor} onClose={() => setIssueFor(null)} />
      <MoveModal itemId={moveFor} onClose={() => setMoveFor(null)} />
      <Lightbox bill={photo} onClose={() => setPhoto(null)} />
      <div className="slip-wrap" aria-hidden={slipItem ? undefined : true}>
        {slipItem && <EntryPrint it={slipItem} items={items} me={meView} />}
      </div>
      {toastNode}
    </RegContext.Provider>
  );
}

/** Drive / catalogue forms ke liye suggestions (logo ke naam, department, brand). */
function AssetDatalists() {
  const A = useAssets();
  const people = distinct([...A.drives.map((d) => d.holder?.name), ...A.transfers.map((t) => t.to.name)].filter((x) => x && x !== 'Store'));
  const depts = distinct([...DEF.dept, ...A.drives.map((d) => d.dept), ...A.catalog.map((c) => c.dept)]);
  const brands = distinct(['Seagate', 'WD', 'Western Digital', 'Toshiba', 'Samsung', 'SanDisk', 'Crucial', 'Kingston', 'LaCie', 'Transcend', ...A.drives.map((d) => d.brand)]);
  const projects = distinct(A.catalog.map((c) => c.project));
  const owners = distinct(A.catalog.map((c) => c.owner));
  const { items } = useReg();
  const allPeople = distinct([
    ...A.persons.map((p) => p.name),
    ...people,
    ...items.flatMap((i) => i.issues.map((x) => x.person)),
    ...owners,
    ...A.events.flatMap((e) => [...e.participants, ...e.mainPersons, e.submittedBy, e.receivedBy, e.responsible]),
  ]);
  const places = distinct([
    'Main Media Office',
    'Computer Room',
    'Delhi Office',
    'Store',
    'Outside for repair',
    'In transit',
    ...A.drives.map((d) => d.place),
    ...A.transfers.map((t) => t.to.place),
    ...items.flatMap((i) => i.issues.map((x) => x.location)),
    ...A.persons.map((p) => p.location),
    ...A.events.map((e) => e.location),
  ]);
  const allDeptNames = distinct([...depts, ...A.depts.map((d) => d.name), ...items.flatMap((i) => i.issues.map((x) => x.dept))]);
  const L: Record<string, string[]> = { 'dl-people': people, 'dl-allpeople': allPeople, 'dl-places': places, 'dl-depts': allDeptNames, 'dl-brands': brands, 'dl-projects': distinct([...projects, ...A.events.map((e) => e.project)]), 'dl-owners': owners };
  return (
    <>
      {Object.entries(L).map(([id, vals]) => (
        <datalist id={id} key={id}>
          {vals.map((v) => (
            <option value={v} key={v} />
          ))}
        </datalist>
      ))}
    </>
  );
}

function AppFrame({
  path,
  notice,
  itemsDenied,
  counts,
  children,
}: {
  path: string;
  notice: string;
  itemsDenied: boolean;
  counts: { items: number; stock: number; issues: number };
  children: ReactNode;
}) {
  const { me, items, groups, signOut, newEntry } = useReg();
  const A = useAssets();
  const { t, lang, setLang } = useLang();
  const router = useRouter();
  const reduce = useReducedMotion();

  const [collapsed, setCollapsed] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);
  const [cmdOpen, setCmdOpen] = useState(false);
  const [bellOpen, setBellOpen] = useState(false);
  const [addOpen, setAddOpen] = useState(false);
  const [closedGroups, setClosedGroups] = useState<string[]>([]);
  const [dark, setDark] = useState(false);

  useEffect(() => {
    try {
      setCollapsed(localStorage.getItem('osr-side-collapsed') === '1');
      setClosedGroups(JSON.parse(localStorage.getItem('osr-side-groups') || '[]'));
    } catch {
      /* ignore */
    }
    setDark(document.documentElement.dataset.theme === 'dark');
  }, []);
  useEffect(() => setMenuOpen(false), [path]);
  useEffect(() => {
    const k = (e: KeyboardEvent) => {
      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'k') {
        e.preventDefault();
        setCmdOpen((o) => !o);
      } else if (e.key === '/' && !(e.target as HTMLElement).closest('input,textarea,select,[contenteditable]')) {
        e.preventDefault();
        setCmdOpen(true);
      } else if (e.key === 'Escape') {
        setMenuOpen(false);
        setAddOpen(false);
      }
    };
    window.addEventListener('keydown', k);
    return () => window.removeEventListener('keydown', k);
  }, []);

  const toggleCollapsed = () =>
    setCollapsed((c) => {
      try {
        localStorage.setItem('osr-side-collapsed', c ? '0' : '1');
      } catch {
        /* ignore */
      }
      return !c;
    });
  const toggleGroup = (id: string) =>
    setClosedGroups((g) => {
      const n = g.includes(id) ? g.filter((x) => x !== id) : [...g, id];
      try {
        localStorage.setItem('osr-side-groups', JSON.stringify(n));
      } catch {
        /* ignore */
      }
      return n;
    });
  const toggleTheme = () => {
    const next = document.documentElement.dataset.theme === 'dark' ? 'light' : 'dark';
    setThemePref(THEME_MODE_KEY, next);
    setDark(next === 'dark');
  };

  const alerts = useMemo(
    () =>
      buildAlerts({
        items,
        groups,
        drives: A.drives,
        catalog: A.catalog,
        backups: A.backups,
        pendingDemands: A.pendingDemands,
        canDrives: A.can('drives', 'view'),
        canCatalog: A.can('catalog', 'view'),
      }),
    [items, groups, A],
  );
  const risk = useMemo(() => A.catalog.filter((c) => (c.priority === 'Critical' || c.priority === 'High') && copyState(c, A.backups).state === 'none').length, [A.catalog, A.backups]);
  const navCounts: Record<string, number> = {
    ...counts,
    drives: A.drives.length,
    demands: Math.max(0, A.pendingDemands),
    catalog: A.catalog.length,
    risk,
  };

  const isOn = (href: string) => (href === '/' ? path === '/' : path === href || path.startsWith(href + '/'));
  const crumb = crumbFor(path);

  const quick = [
    A.can('inventory', 'create') && { label: t('New item'), icon: Package, go: () => newEntry() },
    A.can('drives', 'create') && { label: t('New drive'), icon: HardDrive, go: () => router.push('/drives?new=1') },
    A.can('drives', 'transfer') && { label: 'Issue / return drive', icon: ArrowLeftRight, go: () => router.push('/scan') },
    A.can('catalog', 'create') && { label: t('Catalogue entry'), icon: Database, go: () => router.push('/catalog?new=1') },
  ].filter(Boolean) as { label: string; icon: typeof Plus; go: () => void }[];

  return (
    <div className={'app' + (collapsed ? ' collapsed' : '') + (menuOpen ? ' menu-open' : '')}>
      <aside className="app-side" aria-label="Main menu">
        <Link href="/" className="app-brand">
          <span className="app-logo" aria-hidden>
            <Boxes />
          </span>
          <span className="app-brand-t">
            <b>Office Saman Register</b>
            <small>Inventory · Storage · Assets</small>
          </span>
        </Link>
        <nav className="app-nav">
          {NAV.map((g) => {
            const list = g.items.filter((n) => !n.need || A.can(n.need[0], n.need[1]));
            if (!list.length) return null;
            const open = collapsed || !closedGroups.includes(g.id);
            return (
              <div className="nav-group" key={g.id}>
                <button type="button" className="nav-gh" aria-expanded={open} onClick={() => !collapsed && toggleGroup(g.id)}>
                  <span>{t(g.label)}</span>
                  <ChevronDown aria-hidden />
                </button>
                <AnimatePresence initial={false}>
                  {open && (
                    <motion.div
                      className="nav-items"
                      initial={reduce ? false : { height: 0, opacity: 0 }}
                      animate={{ height: 'auto', opacity: 1 }}
                      exit={reduce ? undefined : { height: 0, opacity: 0 }}
                      transition={{ duration: 0.22, ease: [0.2, 0.8, 0.2, 1] }}
                    >
                      {list.map((n) => {
                        const on = isOn(n.href);
                        const c = n.count ? navCounts[n.count] : 0;
                        return (
                          <Link key={n.href} href={n.href} className={'nav-link' + (on ? ' on' : '')} aria-current={on ? 'page' : undefined} title={collapsed ? t(n.label) : undefined}>
                            <n.icon aria-hidden />
                            <span>{t(n.label)}</span>
                            {c > 0 && <b className={'nav-c' + (n.count === 'risk' ? ' warn' : '')}>{c}</b>}
                          </Link>
                        );
                      })}
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>
            );
          })}
        </nav>
        <div className="app-side-foot">
          <div className="side-user2">
            <span className="u-avatar">{initials(me?.name)}</span>
            <span className="who">
              <b>{me?.name || '—'}</b>
              <small>{A.access ? ROLE_LABEL[A.access.role] + (A.access.isOwner ? ' · Owner' : '') : me?.email}</small>
            </span>
          </div>
          <button type="button" className="nav-link" onClick={signOut} style={{ border: 0, background: 'none', cursor: 'pointer', font: 'inherit', width: '100%' }} title={t('Logout')}>
            <LogOut aria-hidden />
            <span>{t('Logout')}</span>
          </button>
        </div>
      </aside>
      <div className="app-scrim" onClick={() => setMenuOpen(false)} aria-hidden />

      <div className="app-main">
        <header className="app-top">
          <button type="button" className="u-iconbtn show-m" onClick={() => setMenuOpen(true)} aria-label={t('Menu')}>
            <Menu aria-hidden />
          </button>
          <button type="button" className="u-iconbtn hide-m" onClick={toggleCollapsed} aria-label={collapsed ? 'Expand sidebar' : 'Collapse sidebar'} title={collapsed ? 'Expand sidebar' : 'Collapse sidebar'}>
            {collapsed ? <PanelLeftOpen aria-hidden /> : <PanelLeftClose aria-hidden />}
          </button>
          <nav className="crumbs" aria-label="Breadcrumb">
            <Link href="/">{t('Dashboard')}</Link>
            {crumb && crumb.href !== '/' && (
              <>
                <ChevronRight aria-hidden />
                <span className="hide-m">{t(crumb.group)}</span>
                <ChevronRight aria-hidden className="hide-m" />
                {path === crumb.href ? <b>{t(crumb.label)}</b> : <Link href={crumb.href}>{t(crumb.label)}</Link>}
                {path !== crumb.href && (
                  <>
                    <ChevronRight aria-hidden />
                    <b>Details</b>
                  </>
                )}
              </>
            )}
          </nav>
          <button type="button" className="top-search" onClick={() => setCmdOpen(true)} aria-label={t('Search')}>
            <Search aria-hidden />
            <span>{t('Search everything…')}</span>
            <kbd>Ctrl K</kbd>
          </button>
          <div className="top-actions">
            {quick.length > 0 && (
              <div className="u-cols hide-m">
                <button type="button" className="btn primary sm" onClick={() => setAddOpen((o) => !o)} aria-expanded={addOpen} style={{ height: 38 }}>
                  <Plus aria-hidden className="ic" /> {t('Quick add')}
                </button>
                <AnimatePresence>
                  {addOpen && (
                    <motion.div
                      className="u-pop"
                      initial={reduce ? false : { opacity: 0, y: -6, scale: 0.97 }}
                      animate={{ opacity: 1, y: 0, scale: 1 }}
                      exit={reduce ? undefined : { opacity: 0, y: -4, scale: 0.97 }}
                      transition={{ type: 'spring', stiffness: 500, damping: 32 }}
                      onMouseLeave={() => setAddOpen(false)}
                      style={{ transformOrigin: 'top right' }}
                    >
                      {quick.map((q) => (
                        <button
                          key={q.label}
                          type="button"
                          className="mi"
                          onClick={() => {
                            setAddOpen(false);
                            q.go();
                          }}
                        >
                          <q.icon aria-hidden /> {q.label}
                        </button>
                      ))}
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>
            )}
            <button type="button" className="u-iconbtn" onClick={() => setLang(lang === 'en' ? 'hi' : 'en')} aria-label="Language" title={lang === 'en' ? 'हिन्दी में देखें' : 'View in English'}>
              <Languages aria-hidden />
            </button>
            <button type="button" className="u-iconbtn" onClick={toggleTheme} aria-label={dark ? 'Light theme' : 'Midnight theme'} title={dark ? 'Light theme' : 'Midnight theme'}>
              {dark ? <Sun aria-hidden /> : <Moon aria-hidden />}
            </button>
            <button type="button" className="u-iconbtn" data-bell onClick={() => setBellOpen((o) => !o)} aria-label={t('Notifications') + ' (' + alerts.length + ')'}>
              <Bell aria-hidden />
              {alerts.length > 0 && <span className="dot">{alerts.length > 99 ? '99+' : alerts.length}</span>}
            </button>
            <Link href="/settings" className="u-avatar hide-m" aria-label="Settings">
              {initials(me?.name)}
            </Link>
          </div>
        </header>

        <main className="app-content" id="main">
          {notice && (
            <div className="notice" role="status">
              {notice}
            </div>
          )}
          {itemsDenied && (
            <div className="notice" role="status">
              Aapke role ko purchases / stock dekhne ki ijaazat nahi hai. Zaroorat ho to Super Admin se kaho.
            </div>
          )}
          <AnimatePresence mode="wait" initial={false}>
            <motion.div
              key={path}
              className="main-anim main"
              initial={reduce ? false : { opacity: 0, y: 8 }}
              animate={{ opacity: 1, y: 0 }}
              exit={reduce ? undefined : { opacity: 0, y: -4 }}
              transition={{ duration: 0.2, ease: [0.2, 0.8, 0.2, 1] }}
            >
              {children}
            </motion.div>
          </AnimatePresence>
        </main>
      </div>

      <nav className="app-bottom" aria-label="Quick navigation">
        <Link href="/" className={path === '/' ? 'on' : ''}>
          <LayoutDashboard aria-hidden />
          {t('Dashboard')}
        </Link>
        <Link href="/drives" className={isOn('/drives') ? 'on' : ''}>
          <HardDrive aria-hidden />
          {t('Drives')}
        </Link>
        <Link href="/scan" className="fab" aria-label={t('QR scan')}>
          <ScanLine aria-hidden />
        </Link>
        <button type="button" onClick={() => setCmdOpen(true)}>
          <Search aria-hidden />
          {t('Search')}
        </button>
        <button type="button" onClick={() => setMenuOpen(true)}>
          <Menu aria-hidden />
          {t('Menu')}
        </button>
      </nav>

      <CommandPalette open={cmdOpen} onClose={() => setCmdOpen(false)} />
      <NotificationPanel open={bellOpen} onClose={() => setBellOpen(false)} alerts={alerts} />
    </div>
  );
}
