# Windows / Mac Storage Scanner — architecture (Phase 2)

Abhi website me **manual import** chalta hai (drive ke page → Files → Import scan (CSV)). Desktop agent agla phase hai. Ye document batata hai ki agent kaise banega taaki website ka data model abhi se uske liye taiyaar rahe.

## Jo abhi website me hai

- `parseScanCsv()` (`lib/assets/csv.ts`): `path,size,modified` CSV padhta hai (PowerShell `Export-Csv` aur macOS `find | stat` dono). Drive letter / `/Volumes/<name>` hata deta hai, system files (`._*`, `.DS_Store`, `Thumbs.db`) chhod deta hai.
- `importScan()` (`lib/assets/db.ts`): purana index hatata hai, folder ke hisaab se `fileIndex` docs (har doc max 400 files + search tokens) likhta hai, `scans` me history (+added / −removed) aur drive ka `lastScanAt` / `usedGB` update karta hai.
- Global search (Ctrl K) `fileIndex.tokens` pe `array-contains` query chalata hai — poora index browser me nahi mangwata.

Agent **wahi data model** use karega, isliye website me kuch badalna nahi padega.

## Agent ka design

```
┌──────────── Windows / macOS ────────────┐        ┌─────────── Vercel ───────────┐        ┌── Firestore ──┐
│ Tray app (Tauri / Electron, read-only)  │        │ /api/agent/register          │        │ agents/{id}   │
│  • drive connect detect                 │ HTTPS  │ /api/agent/scan  (batch)     │ Admin  │ fileIndex/*   │
│  • volume serial / label → registered?  │ ─────▶ │ /api/agent/heartbeat         │ ─────▶ │ scans/*       │
│  • capacity + free space                │ device │  • device token verify       │  SDK   │ drives/{id}   │
│  • walk files (metadata only)           │ token  │  • rate limit, size limits   │        │ auditLogs/*   │
│  • SMART (smartctl) agar support ho     │        │  • role: drives.edit /        │        └───────────────┘
│  • offline queue (SQLite)               │        │    catalog.create            │
└─────────────────────────────────────────┘        └──────────────────────────────┘
```

### Pehchaan (drive registered hai ya nahi)
1. Drive ke root me `.osr-asset` file **nahi likhenge** (read-only rule). Iske bajaye: volume serial number (Windows `Get-Volume`, macOS `diskutil info`) + disk serial (agar mile) ko drive ke `custom.volumeSerial` / `serialKey` se match karo.
2. Match na ho to agent user se poochhe: "Ye kaunsi Mark hai?" — QR scan ya list se chuno. Pehli baar ke baad yaad rahe.

### Scan
- Incremental: pichhle scan ka `(path, size, mtime)` local SQLite me; sirf badla hua bhejo. Website pe `added/removed` wahi formula.
- Pause / resume / cancel: walker ek queue se chalta hai; progress tray me.
- Bade index: 400 files / chunk, ek request me max ~200 chunks. Bahut bade index (lakhon files) ke liye dedicated search service (Typesense / Algolia / Meilisearch) — **lagane se pehle approval**, kyunki ye paid ho sakta hai.

### Suraksha
- **Read-only by default**: agent kabhi format / delete / move / rename nahi karta. Koi "write" feature hi nahi hoga.
- Original video / file **upload nahi** hoti — sirf metadata.
- Device token: website pe Admin → Agents se "Add device" → ek-baar ka code → agent usse long-lived device token leta hai. Server pe sirf token ka SHA-256 hash `agents/{id}` me. Token revoke kar sakte hai.
- Server APIs Firebase Admin SDK se likhenge (service account sirf Vercel env me: `FIREBASE_SERVICE_ACCOUNT`). Frontend / logs / responses me kabhi nahi.
- Har request: token verify → device active? → rate limit → payload size limit → audit log.

### SMART health
- Windows: `smartctl` (smartmontools) agar install ho, warna `Get-PhysicalDisk | Get-StorageReliabilityCounter`.
- macOS: `smartctl` (Homebrew) — USB enclosures aksar SMART nahi dete; tab `health = "Unknown"` hi bhejo, andaza mat lagao.

### Website pe Phase 2 me kya judega
- `app/api/agent/*` routes (Firebase Admin SDK, `firebase-admin` dependency).
- Admin → Agents page (devices, last seen, revoke).
- Scan progress live (agent heartbeat).
