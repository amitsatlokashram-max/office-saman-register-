import type { Metadata } from 'next';
import { Suspense } from 'react';
import { Guard } from '@/components/assets/Guard';
import { BackupsPage } from '@/components/assets/BackupsPage';

export const metadata: Metadata = { title: 'Backups' };

export default function Page() {
  return (
    <Guard m="backups">
      <Suspense>
        <BackupsPage />
      </Suspense>
    </Guard>
  );
}
