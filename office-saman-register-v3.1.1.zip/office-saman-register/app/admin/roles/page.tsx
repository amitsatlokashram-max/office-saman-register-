import type { Metadata } from 'next';
import { Suspense } from 'react';
import { Guard } from '@/components/assets/Guard';
import { RolesPage } from '@/components/assets/AdminPages';

export const metadata: Metadata = { title: 'Roles & permissions' };

export default function Page() {
  return (
    <Guard m="roles">
      <Suspense>
        <RolesPage />
      </Suspense>
    </Guard>
  );
}
