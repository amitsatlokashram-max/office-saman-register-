import type { Metadata } from 'next';
import { Suspense } from 'react';
import { Guard } from '@/components/assets/Guard';
import { RecyclePage } from '@/components/assets/AdminPages';

export const metadata: Metadata = { title: 'Recycle bin' };

export default function Page() {
  return (
    <Guard m="drives" a="delete">
      <Suspense>
        <RecyclePage />
      </Suspense>
    </Guard>
  );
}
