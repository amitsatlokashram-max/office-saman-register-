import type { Metadata } from 'next';
import { Suspense } from 'react';
import { Guard } from '@/components/assets/Guard';
import { AuditPage } from '@/components/assets/AdminPages';

export const metadata: Metadata = { title: 'Audit log' };

export default function Page() {
  return (
    <Guard m="audit">
      <Suspense>
        <AuditPage />
      </Suspense>
    </Guard>
  );
}
