import type { MetadataRoute } from 'next';

// Opens like an app when added to a phone's home screen.
export default function manifest(): MetadataRoute.Manifest {
  return {
    name: 'Office Saman Register',
    short_name: 'Saman Register',
    description: 'Office inventory, hard disk custody, data catalogue and backups.',
    start_url: '/',
    display: 'standalone',
    background_color: '#F5F7FB',
    theme_color: '#6366F1',
    icons: [{ src: '/icon.svg', sizes: 'any', type: 'image/svg+xml', purpose: 'any' }],
  };
}
