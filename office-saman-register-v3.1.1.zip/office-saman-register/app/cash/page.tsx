import type { Metadata } from 'next';
import { CashCalculator } from '@/components/tools/CashCalculator';

export const metadata: Metadata = { title: 'Cash calculator' };

export default function Page() {
  return <CashCalculator />;
}
