'use client';

// QR sticker ka link: /a/DRV-0001 (ya Mark number). Login ke baad sahi drive ka profile kholta hai.

import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { use, useEffect } from 'react';
import { HardDrive } from 'lucide-react';
import { useAssets } from '@/components/assets/store';
import { Card, Empty } from '@/components/ui';
import { resolveCode } from '@/lib/assets/resolve';

export default function Page({ params }: { params: Promise<{ code: string }> }) {
  const { code } = use(params);
  const A = useAssets();
  const router = useRouter();
  const hit = resolveCode(decodeURIComponent(code), A.allDrives);
  useEffect(() => {
    if (hit) router.replace('/drives/' + hit.id);
  }, [hit, router]);
  if (!A.loaded.drives || hit) return <p className="u-muted">Opening…</p>;
  return (
    <Card>
      <Empty icon={HardDrive} title={'"' + decodeURIComponent(code) + '" nahi mila'} action={<Link className="btn" href="/drives">All drives</Link>}>
        Ye sticker kisi registered drive ka nahi hai, drive hata di gayi hai, ya aapko dekhne ki ijaazat nahi hai.
      </Empty>
    </Card>
  );
}
