'use client';

import { Suspense, use } from 'react';
import { Guard } from '@/components/assets/Guard';
import { EventDetail } from '@/components/events/Events';

export default function Page({ params }: { params: Promise<{ id: string }> }) {
  const p = use(params);
  return (
    <Guard m="events">
      <Suspense>
        <EventDetail id={decodeURIComponent(p.id)} />
      </Suspense>
    </Guard>
  );
}
