import type { Metadata } from 'next';
import { Suspense } from 'react';
import { Guard } from '@/components/assets/Guard';
import { EventsPage } from '@/components/events/Events';

export const metadata: Metadata = { title: 'Events' };

export default function Page() {
  return (
    <Guard m="events">
      <Suspense>
        <EventsPage />
      </Suspense>
    </Guard>
  );
}
