import type { Metadata } from 'next';
import { Suspense } from 'react';
import { Guard } from '@/components/assets/Guard';
import { ScanPage } from '@/components/assets/ScanPage';

export const metadata: Metadata = { title: 'QR scan' };

export default function Page() {
  return (
    <Guard m="drives">
      <Suspense>
        <ScanPage />
      </Suspense>
    </Guard>
  );
}
