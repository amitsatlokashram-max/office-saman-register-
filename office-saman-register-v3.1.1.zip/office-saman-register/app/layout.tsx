import type { Metadata, Viewport } from 'next';
import type { ReactNode } from 'react';
import '@fontsource-variable/inter/index.css';
import '@fontsource-variable/noto-sans-devanagari/index.css';
import './globals.css';
import './ui.css';
import Shell from '@/components/Shell';
import { THEME_BOOT } from '@/lib/theme';

export const metadata: Metadata = {
  title: { default: 'Office Saman Register', template: '%s · Office Saman Register' },
  description: 'Office inventory, stock, purchases, hard disk custody, data catalogue and backups in one place.',
  applicationName: 'Office Saman Register',
  appleWebApp: { capable: true, title: 'Saman Register', statusBarStyle: 'default' },
};

export const viewport: Viewport = {
  width: 'device-width',
  initialScale: 1,
  viewportFit: 'cover',
  themeColor: [
    { media: '(prefers-color-scheme: light)', color: '#F6F7FC' },
    { media: '(prefers-color-scheme: dark)', color: '#0B1020' },
  ],
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en" data-theme="light" data-color="aurora" suppressHydrationWarning>
      <head>
        <script dangerouslySetInnerHTML={{ __html: THEME_BOOT }} />
      </head>
      <body>
        <Shell>{children}</Shell>
      </body>
    </html>
  );
}
