import type { Metadata } from 'next';
import { HomeDashboard } from '@/components/assets/HomeDashboard';

export const metadata: Metadata = { title: 'Dashboard' };

export default function Page() {
  return <HomeDashboard />;
}
