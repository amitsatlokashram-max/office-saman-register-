import type { Metadata } from 'next';
import { Suspense } from 'react';
import { Guard } from '@/components/assets/Guard';
import { LocationsPage } from '@/components/assets/LocationsPage';

export const metadata: Metadata = { title: 'Locations' };

export default function Page() {
  return (
    <Guard m="locations">
      <Suspense>
        <LocationsPage />
      </Suspense>
    </Guard>
  );
}
