import type { Metadata } from 'next';
import { Suspense } from 'react';
import { Guard } from '@/components/assets/Guard';
import { DepartmentsPage } from '@/components/people/People';

export const metadata: Metadata = { title: 'Departments' };

export default function Page() {
  return (
    <Guard m="persons">
      <Suspense>
        <DepartmentsPage />
      </Suspense>
    </Guard>
  );
}
