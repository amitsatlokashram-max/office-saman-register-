'use client';

import { Suspense, use } from 'react';
import { Guard } from '@/components/assets/Guard';
import { PersonProfile } from '@/components/people/People';

export default function Page({ params }: { params: Promise<{ key: string }> }) {
  const p = use(params);
  return (
    <Guard m="persons">
      <Suspense>
        <PersonProfile pkey={decodeURIComponent(p.key)} />
      </Suspense>
    </Guard>
  );
}
