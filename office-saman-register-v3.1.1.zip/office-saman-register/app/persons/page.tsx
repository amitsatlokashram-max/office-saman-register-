import type { Metadata } from 'next';
import { Suspense } from 'react';
import { Guard } from '@/components/assets/Guard';
import { PersonsPage } from '@/components/people/People';

export const metadata: Metadata = { title: 'Persons' };

export default function Page() {
  return (
    <Guard m="persons">
      <Suspense>
        <PersonsPage />
      </Suspense>
    </Guard>
  );
}
