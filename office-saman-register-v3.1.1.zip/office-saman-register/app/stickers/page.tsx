import type { Metadata } from 'next';
import { Suspense } from 'react';
import { Guard } from '@/components/assets/Guard';
import { StickersPage } from '@/components/assets/StickersPage';

export const metadata: Metadata = { title: 'QR stickers' };

export default function Page() {
  return (
    <Guard m="stickers">
      <Suspense>
        <StickersPage />
      </Suspense>
    </Guard>
  );
}
