import type { Metadata } from 'next';
import { Suspense } from 'react';
import { Guard } from '@/components/assets/Guard';
import { ReportBuilder } from '@/components/reports/ReportBuilder';

export const metadata: Metadata = { title: 'Report builder' };

export default function Page() {
  return (
    <Guard m="reports">
      <Suspense>
        <ReportBuilder />
      </Suspense>
    </Guard>
  );
}
