import type { Metadata } from 'next';
import { Suspense } from 'react';
import { Guard } from '@/components/assets/Guard';
import { CatalogPage } from '@/components/assets/CatalogPage';

export const metadata: Metadata = { title: 'Data catalogue' };

export default function Page() {
  return (
    <Guard m="catalog">
      <Suspense>
        <CatalogPage />
      </Suspense>
    </Guard>
  );
}
