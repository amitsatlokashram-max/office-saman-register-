import type { Metadata } from 'next';
import { Suspense } from 'react';
import { Guard } from '@/components/assets/Guard';
import { DrivesPage } from '@/components/assets/DrivesPage';

export const metadata: Metadata = { title: 'Hard Disks' };

export default function Page() {
  return (
    <Guard m="drives">
      <Suspense>
        <DrivesPage />
      </Suspense>
    </Guard>
  );
}
