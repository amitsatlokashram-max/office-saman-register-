'use client';

import { Suspense, use } from 'react';
import { DriveProfile } from '@/components/assets/DriveProfile';
import { Guard } from '@/components/assets/Guard';

export default function Page({ params }: { params: Promise<{ id: string }> }) {
  const { id } = use(params);
  return (
    <Guard m="drives">
      <Suspense>
        <DriveProfile id={decodeURIComponent(id)} />
      </Suspense>
    </Guard>
  );
}
