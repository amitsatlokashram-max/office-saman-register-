import type { Metadata } from 'next';
import { Suspense } from 'react';
import { Guard } from '@/components/assets/Guard';
import { DataDashboard } from '@/components/assets/DataDashboard';

export const metadata: Metadata = { title: 'Data Manager' };

export default function Page() {
  return (
    <Guard m="drives">
      <Suspense>
        <DataDashboard />
      </Suspense>
    </Guard>
  );
}
