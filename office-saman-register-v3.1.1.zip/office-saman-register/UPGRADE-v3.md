# v3.1 upgrade (v3.0 ke upar)

1. Code push karo.
2. **Nayi `firestore.rules` dobara paste + Publish** (apna Gmail daal ke). Naye collections (persons, events…) ke rules isme hai.
3. Agar aapne v3.0 me "Save roles" kar diya tha: **Admin → Roles → Save roles** ek baar dobara dabao, taaki naye modules (Persons, Events) ki permission roles me chali jaye. (Super Admin / owner ko hamesha sab dikhta hai.)
4. **Settings → Naming series**: SSD ka start number daalo (jaise aakhri SSD Mark 79 tha to start 80), HDD ka prefix "Mark " ya jo aap use karte ho. Save.
5. Purani drives (jo v3.0 me bani) apne aap series me aa jati hai (type ke hisaab se).
6. Optional: Vercel me `NEXT_PUBLIC_ADMIN_NAME` (khaali = "Amit").

Purane purchases / issues me location / purpose / wapsi ka naam nahi tha — wo khaali dikhenge, data nahi badalta. Aage ki entries me bharo.

---

# Office Saman Register v3 — Upgrade guide (purane v2 se)

Ye upgrade **purana data nahi badalta, nahi mitata**. `purchases`, `demands`, `bills`, `settings`, `config/access` sab waise hi rehte hai. Naye modules apne **naye collections** me likhte hai. Koi migration script chalane ki zaroorat nahi.

Lagbhag 10 minute.

## Step 1 — Code GitHub pe daalo

1. Is zip ko unzip karo aur apne purane project folder ki **saari files isse badal do** (`.env.local` ho to use mat hatao).
2. GitHub Desktop me commit karke **Push** karo. Vercel apne aap naya version deploy kar dega.

## Step 2 — Naye Firestore Rules lagao (zaroori)

Naye modules (Hard Disk, catalogue, backup, roles, audit log) ke liye rules badle hai.

1. Firebase console → **Firestore Database → Rules**.
2. Jo likha hai sab hata do, is project ki `firestore.rules` file ka poora text paste karo.
3. `APNA_EMAIL@gmail.com` ki jagah **apna Gmail** likho (chhote letters me) — wahi jo pehle tha.
4. **Publish** dabao.

> Jab tak aap Roles page pe "Save roles" nahi dabate, **purana tareeka hi chalta hai**: har team member sab kuch kar sakta hai (jaise pehle). Isliye rules badalne se kisi ka kaam nahi rukta.

## Step 3 — Audit log ka index (ek click)

Audit log ko module ke hisaab se filter karne ke liye Firestore ek index maangta hai.

- Aasaan tareeka: app me **Admin → Audit log** kholo, upar "Module" filter me koi module chuno. Agar error aaye to browser console (F12) me Firebase ka ek link dikhega — us link ko kholo aur **Create index** dabao. 2–3 minute me ban jayega.
- Ya `firestore.indexes.json` ko Firebase CLI se deploy karo: `firebase deploy --only firestore:indexes`.

(Bina filter ke audit log index ke bina bhi chalta hai.)

## Step 4 — Roles chuno

1. App me **Admin → Roles & access** kholo (sirf owner / Super Admin badal sakta hai).
2. Har team member ka role chuno: Super Admin, Admin, Store Manager, Purchase Manager, Accountant, Data Manager, Editor, Viewer.
3. Neeche permission matrix me har role ki ijaazat dekh / badal lo.
4. **Save roles** dabao. Ab se ye permissions **Firestore Rules aur server APIs** dono me lagu hongi (sirf button chhupana nahi).

## Step 5 — Optional settings (Vercel → Environment Variables)

| Name | Kab chahiye |
|---|---|
| `NEXT_PUBLIC_APP_URL` | QR sticker me pakka website link chahiye (jaise custom domain). Khaali ho to jis link se app khola hai wahi chhapta hai. |
| `NEXT_PUBLIC_OWNER_EMAIL` | Sirf tab jab owner ka Gmail Team list me bhi likha ho. |

Badalne ke baad **Deployments → ⋯ → Redeploy**.

## Step 6 — Shuru karo

1. **Locations**: Office → Building → Floor → Room → Rack → Shelf banao, phir shelf me "Add slots".
2. **Hard Disks → Register drives**: ek saath kai drives (Mark 1 se Mark 50 tak bhi). Purchase entry se jodo taaki bill/warranty/price aa jaye — kharcha dobara nahi judta.
3. **QR stickers**: Mark range chuno → Print / Save PDF → drive pe chipkao.
4. **QR scan** (phone pe): Issue / Return / Verify stock.
5. **Data catalogue**: kaunsi drive me kaunsa project / episode hai.
6. Drive ke page pe **Files → Import scan (CSV)**: poori file list (sirf naam/size/tareekh) — phir Ctrl K se kisi bhi file ka naam dhoondho.
7. **Backups**: important data ki doosri drive pe copy assign karo, copy hone par hash daal ke verify karo.

## Wapas purane version pe jaana ho to

Purana code dobara push kar do. Naye collections (`drives`, `locations`, …) pade rahenge, purane app ko unse koi farak nahi padta. Purane rules wapas lagane ho to purani `firestore.rules` file paste karo.

## Naye Firestore collections

| Collection | Kya hai |
|---|---|
| `drives/{id}` | Har physical drive: assetId (DRV-0001), markNo, displayName, type, capacity, used, holder, status, locationId, purchaseId… |
| `driveMarks/{markNo}`, `driveSerials/{serial}`, `slots/{slotId}`, `counters/drives` | Duplicate rok: ek Mark number / serial / slot = ek hi drive (transaction me check) |
| `driveTransfers/{id}` | Custody history (issue, return, transfer, repair…). Mitayi nahi ja sakti. |
| `locations/{id}` | Office → … → Slot (parentId se tree) |
| `catalog/{id}` | Drive ke andar ka data (project, episode, event, folder, size, priority, tags) |
| `fileIndex/{id}` | Scan se file list — folder ke hisaab se chhote tukde (har document max 400 files), taaki koi document 1 MB se bada na ho |
| `scans/{id}` | Har scan import ki history (+added / −removed) |
| `backups/{id}` | Original ↔ copy mapping, status, hash, history |
| `auditLogs/{id}` | Kisne kab kya badla (sirf likh sakte hai, badal / mita nahi sakte) |
| `config/access` | Purana `emails` + naye `roles` aur `perms` fields |

Google Sheet sync pehle jaisa sirf purchases / kisko diya / trip expenses ka **reporting copy** hai. Drive / catalogue ki report CSV export se nikalti hai.
