// Har bande / department ka hisaab: kis tareekh ko kya diya, kitna, kitna wapas aaya, abhi kitna paas hai.
// Purane records (jisme wapsi ke saath naam nahi likha tha) ka hisaab alag dikhaya jata hai, andaza chhupaya nahi jata.

import { nameKey } from './assets/model';
import type { AshramEvent, CatalogEntry, Department, Drive, Person, Transfer } from './assets/types';
import { num } from './calc';
import type { Item } from './types';

export type LedgerKind = 'issue' | 'return' | 'damaged';
export type LedgerRow = {
  id: string;
  date: string;
  kind: LedgerKind;
  itemId: string;
  itemName: string;
  category: string;
  qty: number;
  rate: number;
  value: number;
  person: string;
  personKey: string;
  dept: string;
  location: string;
  purpose: string;
  note: string;
  /** recorded = entry me naam likha tha; auto = purani wapsi, item sirf isi bande ko diya gaya tha */
  source: 'recorded' | 'auto';
  by: string;
};

export type AliasMap = Map<string, { key: string; name: string }>;

export function aliasMap(persons: Person[]): AliasMap {
  const m: AliasMap = new Map();
  for (const p of persons) {
    const key = nameKey(p.name);
    for (const n of [p.name, ...p.aliases]) if (nameKey(n)) m.set(nameKey(n), { key, name: p.name });
  }
  return m;
}
export function canon(name: string, am: AliasMap): { key: string; name: string } {
  const k = nameKey(name);
  return am.get(k) || { key: k, name: name.trim() };
}

export function buildLedger(items: Item[], am: AliasMap): LedgerRow[] {
  const out: LedgerRow[] = [];
  for (const it of items) {
    const rate = num(it.rate);
    const issuedTo = new Set<string>();
    for (const is of it.issues) {
      const c = canon(is.person || '', am);
      if (c.key) issuedTo.add(c.key);
      out.push({
        id: it.id + ':' + is.id,
        date: is.date,
        kind: 'issue',
        itemId: it.id,
        itemName: it.item,
        category: it.category,
        qty: num(is.qty),
        rate,
        value: num(is.qty) * rate,
        person: c.name,
        personKey: c.key,
        dept: is.dept,
        location: is.location || '',
        purpose: is.purpose || '',
        note: is.note,
        source: 'recorded',
        by: is.byName,
      });
    }
    const only = issuedTo.size === 1 ? Array.from(issuedTo)[0] : '';
    const onlyName = only ? it.issues.find((i) => canon(i.person, am).key === only)?.person || '' : '';
    for (const mv of it.moves) {
      if (mv.type === 'vendor') continue;
      if (mv.type === 'damaged' && !mv.person) continue; // store me kharab hua, kisi bande ka nahi
      const recorded = !!mv.person;
      const c = recorded ? canon(mv.person!, am) : only ? canon(onlyName, am) : { key: '', name: '' };
      out.push({
        id: it.id + ':' + mv.id,
        date: mv.date,
        kind: mv.type === 'back' ? 'return' : 'damaged',
        itemId: it.id,
        itemName: it.item,
        category: it.category,
        qty: num(mv.qty),
        rate,
        value: num(mv.qty) * rate,
        person: c.name,
        personKey: c.key,
        dept: mv.dept || '',
        location: '',
        purpose: '',
        note: mv.note,
        source: recorded ? 'recorded' : 'auto',
        by: '',
      });
    }
  }
  // Ek bande ka ek hi naam dikhe: registry wala, warna sabse zyada likha gaya spelling ("Amit" vs "amit")
  const counts = new Map<string, Map<string, number>>();
  for (const r of out) {
    if (!r.personKey) continue;
    const m = counts.get(r.personKey) || new Map<string, number>();
    m.set(r.person, (m.get(r.person) || 0) + 1);
    counts.set(r.personKey, m);
  }
  const best = new Map<string, string>();
  for (const [k, m] of counts) {
    const reg = Array.from(am.values()).find((x) => x.key === k);
    best.set(k, reg ? reg.name : Array.from(m.entries()).sort((a, b) => b[1] - a[1] || (/[A-Z]/.test(b[0][0] || '') ? 1 : 0) - (/[A-Z]/.test(a[0][0] || '') ? 1 : 0))[0][0]);
  }
  for (const r of out) if (r.personKey) r.person = best.get(r.personKey) || r.person;
  return out.sort((a, b) => (a.date || '').localeCompare(b.date || ''));
}

export type Holding = { itemKey: string; itemName: string; category: string; issued: number; returned: number; damaged: number; current: number; value: number; first: string; last: string };
export type PersonSummary = {
  key: string;
  name: string;
  depts: string[];
  issued: number;
  returned: number;
  damaged: number;
  current: number;
  currentValue: number;
  txns: number;
  last: string;
  holdings: Holding[];
};

/** Bande ke hisaab se jod. asOf = us tareekh tak ka hisaab (purani tareekh ko kiske paas kya tha). */
export function summarize(rows: LedgerRow[], asOf = ''): Map<string, PersonSummary> {
  const m = new Map<string, PersonSummary & { _h: Map<string, Holding>; _d: Set<string> }>();
  for (const r of rows) {
    if (!r.personKey) continue;
    if (asOf && r.date && r.date > asOf) continue;
    let p = m.get(r.personKey);
    if (!p) {
      p = { key: r.personKey, name: r.person, depts: [], issued: 0, returned: 0, damaged: 0, current: 0, currentValue: 0, txns: 0, last: '', holdings: [], _h: new Map(), _d: new Set() };
      m.set(r.personKey, p);
    }
    if (r.dept) p._d.add(r.dept);
    p.txns++;
    if (r.date > p.last) p.last = r.date;
    const ik = nameKey(r.itemName) || r.itemId;
    let h = p._h.get(ik);
    if (!h) {
      h = { itemKey: ik, itemName: r.itemName, category: r.category, issued: 0, returned: 0, damaged: 0, current: 0, value: 0, first: r.date, last: r.date };
      p._h.set(ik, h);
    }
    if (r.date && (!h.first || r.date < h.first)) h.first = r.date;
    if (r.date > h.last) h.last = r.date;
    const sign = r.kind === 'issue' ? 1 : -1;
    if (r.kind === 'issue') {
      h.issued += r.qty;
      p.issued += r.qty;
    } else if (r.kind === 'return') {
      h.returned += r.qty;
      p.returned += r.qty;
    } else {
      h.damaged += r.qty;
      p.damaged += r.qty;
    }
    h.current += sign * r.qty;
    h.value += sign * r.value;
  }
  const out = new Map<string, PersonSummary>();
  for (const [k, p] of m) {
    const holdings = Array.from(p._h.values()).sort((a, b) => b.current - a.current || a.itemName.localeCompare(b.itemName));
    const current = holdings.reduce((s, h) => s + Math.max(0, h.current), 0);
    const currentValue = holdings.reduce((s, h) => s + Math.max(0, h.value), 0);
    out.set(k, { key: k, name: p.name, depts: Array.from(p._d), issued: p.issued, returned: p.returned, damaged: p.damaged, current, currentValue, txns: p.txns, last: p.last, holdings });
  }
  return out;
}

/** Item ke hisaab se: kis item ki wapsi kisi naam ke bina hai (purane records). */
export function unattributedReturns(items: Item[], am: AliasMap): { itemId: string; itemName: string; qty: number }[] {
  const out: { itemId: string; itemName: string; qty: number }[] = [];
  for (const it of items) {
    const to = new Set(it.issues.map((i) => canon(i.person, am).key).filter(Boolean));
    if (to.size <= 1) continue;
    const q = it.moves.filter((m) => m.type === 'back' && !m.person).reduce((s, m) => s + num(m.qty), 0);
    if (q > 0) out.push({ itemId: it.id, itemName: it.item, qty: q });
  }
  return out;
}

/** Sab naam ek jagah: registry + jin naamo se kabhi kuch diya / liya / event me aaye. */
export type PersonIndex = { key: string; name: string; person?: Person; depts: string[] };
export function allPeople(o: {
  persons: Person[];
  rows: LedgerRow[];
  drives: Drive[];
  transfers: Transfer[];
  catalog: CatalogEntry[];
  events: AshramEvent[];
  am: AliasMap;
}): PersonIndex[] {
  const m = new Map<string, PersonIndex>();
  const add = (raw: string, dept = '') => {
    if (!raw || !raw.trim() || /^store$/i.test(raw.trim())) return;
    const c = canon(raw, o.am);
    if (!c.key) return;
    const cur = m.get(c.key) || { key: c.key, name: c.name, depts: [] };
    if (dept && !cur.depts.includes(dept)) cur.depts.push(dept);
    m.set(c.key, cur);
  };
  for (const p of o.persons) {
    const k = nameKey(p.name);
    m.set(k, { key: k, name: p.name, person: p, depts: [...p.depts] });
  }
  for (const r of o.rows) add(r.person, r.dept);
  for (const d of o.drives) if (d.holder?.name) add(d.holder.name, d.holder.dept);
  for (const t of o.transfers) {
    add(t.to.name, t.to.dept);
    add(t.from.name);
  }
  for (const c of o.catalog) add(c.owner, c.dept);
  for (const e of o.events) for (const n of [...e.participants, ...e.mainPersons, ...e.recordingTeam, e.submittedBy, e.receivedBy, e.responsible]) add(n);
  return Array.from(m.values()).sort((a, b) => a.name.localeCompare(b.name));
}

export function deptKey(s: string) {
  return nameKey(s);
}
export function allDepts(o: { depts: Department[]; rows: LedgerRow[]; drives: Drive[]; catalog: CatalogEntry[]; persons: Person[] }): { key: string; name: string; dept?: Department }[] {
  const m = new Map<string, { key: string; name: string; dept?: Department }>();
  const add = (n: string) => {
    const k = nameKey(n);
    if (k && !m.has(k)) m.set(k, { key: k, name: n.trim() });
  };
  for (const d of o.depts) {
    const k = nameKey(d.name);
    m.set(k, { key: k, name: d.name, dept: d });
    for (const a of d.aliases) if (nameKey(a)) m.set(nameKey(a), { key: k, name: d.name, dept: d });
  }
  for (const r of o.rows) add(r.dept);
  for (const d of o.drives) {
    add(d.dept);
    if (d.holder?.dept) add(d.holder.dept);
  }
  for (const c of o.catalog) add(c.dept);
  for (const p of o.persons) p.depts.forEach(add);
  const seen = new Set<string>();
  return Array.from(m.values())
    .filter((x) => (seen.has(x.key) ? false : (seen.add(x.key), true)))
    .sort((a, b) => a.name.localeCompare(b.name));
}
