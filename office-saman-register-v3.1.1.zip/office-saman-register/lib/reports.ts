// Ek hi Report Builder sab data ke liye: dataset chuno → filter → column → group → total → print / Excel / CSV.

import { copyState, freeGB, gb, locLabel, usedPct, whereIs } from './assets/model';
import { BACKUP_STATUS_LABEL, DRIVE_STATUS_LABEL, TRANSFER_LABEL, type AshramEvent, type Backup, type CatalogEntry, type Drive, type Loc, type Transfer } from './assets/types';
import { myPay, num, remaining, status } from './calc';
import { summarize, type LedgerRow } from './people';
import type { Item, StockGroup } from './types';

export type ColType = 'text' | 'number' | 'money' | 'date';
export type RCol = { key: string; label: string; type: ColType; get: (r: Row) => string | number; def?: boolean; total?: boolean };
type Row = Record<string, unknown>;

export type Dataset = {
  id: string;
  label: string;
  hint: string;
  dateKey?: string;
  /** filter boxes jo is dataset pe lagte hai */
  filters: ('person' | 'dept' | 'location' | 'item' | 'category' | 'status' | 'drive' | 'event')[];
  cols: RCol[];
  rows: (src: Sources) => Row[];
  need: string;
};

export type Sources = {
  items: Item[];
  groups: StockGroup[];
  ledger: LedgerRow[];
  drives: Drive[];
  transfers: Transfer[];
  catalog: CatalogEntry[];
  events: AshramEvent[];
  backups: Backup[];
  locs: Map<string, Loc>;
  driveMap: Map<string, Drive>;
  asOf: string;
};

const t = (key: string, label: string, def = true): RCol => ({ key, label, type: 'text', get: (r) => String(r[key] ?? ''), def });
const n = (key: string, label: string, def = true, total = true): RCol => ({ key, label, type: 'number', get: (r) => num(r[key]), def, total });
const m = (key: string, label: string, def = true): RCol => ({ key, label, type: 'money', get: (r) => num(r[key]), def, total: true });
const d = (key: string, label: string, def = true): RCol => ({ key, label, type: 'date', get: (r) => String(r[key] ?? ''), def });

export const DATASETS: Dataset[] = [
  {
    id: 'ledger',
    label: 'Item transactions (kisko kya diya / wapas)',
    hint: 'Har issue aur wapsi alag line me — tareekh, bande, department, jagah, kaam',
    dateKey: 'date',
    filters: ['person', 'dept', 'location', 'item', 'category', 'status'],
    need: 'inventory',
    cols: [d('date', 'Date'), t('kindLabel', 'Type'), t('itemName', 'Item'), t('category', 'Category', false), n('qty', 'Qty'), m('rate', 'Rate', false), m('value', 'Value'), t('person', 'Person'), t('dept', 'Department'), t('location', 'Location'), t('purpose', 'Purpose'), t('note', 'Note', false), t('by', 'Entry by', false)],
    rows: (s) =>
      s.ledger.map((r) => ({
        ...r,
        status: r.kind,
        kindLabel: r.kind === 'issue' ? 'Issued' : r.kind === 'return' ? 'Returned' + (r.source === 'auto' ? ' (old entry)' : '') : 'Damaged',
        qty: r.kind === 'issue' ? r.qty : -r.qty,
        value: r.kind === 'issue' ? r.value : -r.value,
      })),
  },
  {
    id: 'holdings',
    label: 'Person-wise holdings (abhi kiske paas kitna)',
    hint: 'Har bande ke paas har item: kul diya, wapas, abhi. "As of" tareekh se purana hisaab bhi',
    filters: ['person', 'dept', 'item', 'category'],
    need: 'inventory',
    cols: [t('person', 'Person'), t('depts', 'Department'), t('itemName', 'Item'), t('category', 'Category', false), n('issued', 'Total issued'), n('returned', 'Returned'), n('damaged', 'Damaged', false), n('current', 'Holding now'), m('value', 'Value now'), d('first', 'First issue', false), d('last', 'Last activity')],
    rows: (s) => {
      const sum = summarize(s.ledger, s.asOf);
      const out: Row[] = [];
      for (const p of sum.values())
        for (const h of p.holdings)
          out.push({ person: p.name, dept: p.depts.join(', '), depts: p.depts.join(', '), itemName: h.itemName, category: h.category, issued: h.issued, returned: h.returned, damaged: h.damaged, current: h.current, value: Math.max(0, h.value), first: h.first, last: h.last, status: h.current > 0 ? 'holding' : 'cleared' });
      return out;
    },
  },
  {
    id: 'purchases',
    label: 'Purchases (saman register)',
    hint: 'Har purchase entry: rate, total, vendor, bill, mera paisa',
    dateKey: 'orderDate',
    filters: ['item', 'category', 'status'],
    need: 'inventory',
    cols: [d('orderDate', 'Order date'), d('receivedDate', 'Received'), t('item', 'Item'), t('category', 'Category'), n('qty', 'Qty'), m('rate', 'Rate'), m('total', 'Total'), t('vendor', 'Vendor'), t('broughtBy', 'Brought by', false), t('billNo', 'Bill no.'), t('statusLabel', 'Status'), n('left', 'In stock', false), m('myPaid', 'My money paid', false), m('myDue', 'My money due', false), t('serials', 'Serials', false), d('warrantyTill', 'Warranty', false)],
    rows: (s) =>
      s.items.map((it) => {
        const p = myPay(it);
        return { ...it, statusLabel: status(it).label, status: status(it).key, left: Math.max(0, remaining(it)), myPaid: p.paid, myDue: p.due, serials: it.serials.replace(/\n/g, ', '), hasBill: it.bills.length ? 'yes' : 'no' };
      }),
  },
  {
    id: 'stock',
    label: 'Stock (available)',
    hint: 'Ek naam ke saman ka jod: aaya, diya, wapas, kharab, bacha',
    filters: ['item', 'category', 'status'],
    need: 'inventory',
    cols: [t('name', 'Item'), t('category', 'Category'), n('aaya', 'Received'), n('rasta', 'In transit', false), n('diya', 'Issued'), n('wapas', 'Returned'), n('kharab', 'Damaged / vendor'), n('bacha', 'Available'), n('min', 'Minimum', false), t('label', 'Status')],
    rows: (s) => s.groups.map((g) => ({ ...g, itemName: g.name, label: g.st.label, status: g.st.cls })),
  },
  {
    id: 'drives',
    label: 'Hard Disk / SSD report',
    hint: 'Har drive: capacity, used, free, kiske paas, kahan, status',
    dateKey: 'purchaseDate',
    filters: ['person', 'dept', 'location', 'status', 'drive', 'category'],
    need: 'drives',
    cols: [t('displayName', 'Drive'), t('assetId', 'Asset ID'), t('type', 'Type'), t('brand', 'Brand', false), t('serial', 'Serial', false), n('capacityGB', 'Capacity GB'), n('usedGB', 'Used GB'), n('freeGB', 'Free GB'), n('pct', 'Used %', false, false), t('statusLabel', 'Status'), t('person', 'Holder'), t('dept', 'Department'), t('where', 'Where'), d('purchaseDate', 'Purchase date', false), m('price', 'Price', false), d('warrantyTill', 'Warranty', false), d('lastScanAt', 'Last scan', false), n('dataCount', 'Data records', false)],
    rows: (s) =>
      s.drives.map((x) => ({
        ...x,
        category: x.type,
        freeGB: freeGB(x),
        pct: Math.round(usedPct(x)),
        statusLabel: DRIVE_STATUS_LABEL[x.status],
        status: x.status,
        person: x.holder?.name || '',
        dept: x.holder?.dept || x.dept,
        where: whereIs(x, s.locs),
        location: whereIs(x, s.locs),
        drive: x.displayName,
        dataCount: s.catalog.filter((c) => c.driveId === x.id).length,
      })),
  },
  {
    id: 'transfers',
    label: 'Drive transfer history',
    hint: 'Har drive kab kisko di, kab wapas aayi',
    dateKey: 'date',
    filters: ['person', 'dept', 'location', 'drive', 'status'],
    need: 'drives',
    cols: [d('date', 'Date'), t('mark', 'Drive'), t('kindLabel', 'Action'), t('fromText', 'From'), t('toText', 'To'), t('dept', 'Department'), t('purpose', 'Purpose'), d('expectedReturn', 'Return by', false), d('actualReturn', 'Returned on', false), t('condition', 'Condition', false), t('byName', 'Entry by', false)],
    rows: (s) =>
      s.transfers.map((x) => ({
        ...x,
        kindLabel: TRANSFER_LABEL[x.kind],
        status: x.kind,
        fromText: [x.from.name, x.from.place].filter(Boolean).join(' · '),
        toText: [x.to.name, x.to.place || (x.to.locationId ? locLabel(s.locs, x.to.locationId) : '')].filter(Boolean).join(' · '),
        person: [x.to.name, x.from.name].filter((v) => v && v !== 'Store').join(' '),
        dept: x.to.dept || x.from.dept,
        location: [x.to.place, x.from.place].filter(Boolean).join(' '),
        drive: x.mark,
      })),
  },
  {
    id: 'catalog',
    label: 'Data catalogue (kaunsi drive me kya)',
    hint: 'Project, episode, event, folder, size, drive, abhi kahan, backup',
    dateKey: 'eventDate',
    filters: ['person', 'dept', 'location', 'drive', 'event', 'category', 'status'],
    need: 'catalog',
    cols: [t('project', 'Project'), t('title', 'Title'), t('episode', 'Episode'), t('eventName', 'Event'), d('eventDate', 'Event date'), t('category', 'Category'), t('drive', 'Drive'), t('where', 'Drive is'), t('folderPath', 'Folder'), n('sizeGB', 'Size GB'), n('fileCount', 'Files', false), t('owner', 'Responsible'), t('dept', 'Department', false), t('priority', 'Priority', false), t('backup', 'Backup'), t('statusText', 'Status', false), t('tags', 'Tags', false)],
    rows: (s) =>
      s.catalog.map((c) => {
        const dr = s.driveMap.get(c.driveId);
        const st = copyState(c, s.backups);
        const ev = c.eventId ? s.events.find((e) => e.id === c.eventId) : undefined;
        return {
          ...c,
          eventName: c.eventName || ev?.title || '',
          eventDate: c.eventDate || ev?.date || '',
          event: (c.eventName || '') + ' ' + (ev?.title || ''),
          drive: dr?.displayName || '',
          where: dr ? whereIs(dr, s.locs) : '',
          location: dr ? whereIs(dr, s.locs) : '',
          person: [c.owner, dr?.holder?.name].filter(Boolean).join(' '),
          backup: st.state === 'none' ? 'Single copy' : st.state === 'verified' ? st.verified + ' verified' : st.state === 'outdated' ? 'Outdated' : st.copies + ' unverified',
          status: st.state,
          statusText: c.status,
          tags: c.tags.join(', '),
        };
      }),
  },
  {
    id: 'events',
    label: 'Events (Panchayat, Satsang…)',
    hint: 'Event, tareekh, jagah, kaun aaye the, data kisne diya / liya, kaunsi drives',
    dateKey: 'date',
    filters: ['person', 'location', 'event', 'category', 'drive'],
    need: 'events',
    cols: [t('eventNo', 'Event no.', false), d('date', 'Date'), t('type', 'Type'), t('title', 'Title'), t('location', 'Location'), t('participantsText', 'Persons present'), t('mainText', 'Main persons', false), t('teamText', 'Recording team', false), t('submittedBy', 'Data submitted by'), t('receivedBy', 'Data received by', false), t('responsible', 'Responsible', false), t('drivesText', 'Drives'), n('dataCount', 'Data records'), n('sizeGB', 'Size GB', false), t('description', 'Description', false)],
    rows: (s) =>
      s.events.map((e) => {
        const data = s.catalog.filter((c) => c.eventId === e.id);
        const drives = Array.from(new Set(data.map((c) => s.driveMap.get(c.driveId)?.displayName).filter(Boolean)));
        return {
          ...e,
          category: e.type,
          participantsText: e.participants.join(', '),
          mainText: e.mainPersons.join(', '),
          teamText: e.recordingTeam.join(', '),
          person: [...e.participants, ...e.mainPersons, ...e.recordingTeam, e.submittedBy, e.receivedBy, e.responsible].join(' '),
          event: e.title,
          drivesText: drives.join(', '),
          drive: drives.join(' '),
          dataCount: data.length,
          sizeGB: data.reduce((a, c) => a + c.sizeGB, 0),
        };
      }),
  },
  {
    id: 'backups',
    label: 'Backup report',
    hint: 'Original aur copy, status, verify',
    dateKey: 'completedAt',
    filters: ['drive', 'status'],
    need: 'backups',
    cols: [t('data', 'Data'), t('source', 'Original on'), t('copy', 'Copy on'), t('copyPath', 'Copy path', false), t('statusLabel', 'Status'), t('method', 'Method', false), d('completedAt', 'Copied'), d('verifiedAt', 'Verified'), t('verifiedBy', 'Verified by', false)],
    rows: (s) =>
      s.backups.map((b) => {
        const c = s.catalog.find((x) => x.id === b.catalogId);
        return {
          ...b,
          data: c ? [c.project, c.title].filter(Boolean).join(' · ') : '',
          source: s.driveMap.get(b.sourceDriveId)?.displayName || '',
          copy: s.driveMap.get(b.copyDriveId)?.displayName || '',
          drive: (s.driveMap.get(b.sourceDriveId)?.displayName || '') + ' ' + (s.driveMap.get(b.copyDriveId)?.displayName || ''),
          statusLabel: BACKUP_STATUS_LABEL[b.status],
          status: b.status,
        };
      }),
  },
];

export type Spec = {
  dataset: string;
  from: string;
  to: string;
  asOf: string;
  person: string;
  dept: string;
  location: string;
  item: string;
  category: string;
  status: string;
  drive: string;
  event: string;
  q: string;
  cols: string[];
  groupBy: string;
  sortBy: string;
  sortDir: 'asc' | 'desc';
  title: string;
};

export function blankSpec(ds = 'ledger'): Spec {
  const D = DATASETS.find((x) => x.id === ds) || DATASETS[0];
  return { dataset: D.id, from: '', to: '', asOf: '', person: '', dept: '', location: '', item: '', category: '', status: '', drive: '', event: '', q: '', cols: D.cols.filter((c) => c.def !== false).map((c) => c.key), groupBy: '', sortBy: D.dateKey || D.cols[0].key, sortDir: D.dateKey ? 'asc' : 'asc', title: D.label };
}

const has = (v: unknown, q: string) => String(v ?? '').toLowerCase().includes(q.toLowerCase().trim());

export function runReport(spec: Spec, src: Sources) {
  const D = DATASETS.find((x) => x.id === spec.dataset) || DATASETS[0];
  let rows = D.rows({ ...src, asOf: spec.asOf });
  const dk = D.dateKey;
  if (dk && spec.from) rows = rows.filter((r) => String(r[dk] || '').slice(0, 10) >= spec.from);
  if (dk && spec.to) rows = rows.filter((r) => String(r[dk] || '').slice(0, 10) <= spec.to);
  if (spec.asOf && D.id === 'ledger') rows = rows.filter((r) => String(r.date || '') <= spec.asOf);
  if (spec.person) rows = rows.filter((r) => has(r.person, spec.person));
  if (spec.dept) rows = rows.filter((r) => has(r.dept, spec.dept) || has(r.depts, spec.dept));
  if (spec.location) rows = rows.filter((r) => has(r.location, spec.location) || has(r.where, spec.location));
  if (spec.item) rows = rows.filter((r) => has(r.itemName ?? r.item ?? r.name, spec.item));
  if (spec.category) rows = rows.filter((r) => has(r.category, spec.category));
  if (spec.status) rows = rows.filter((r) => String(r.status ?? '') === spec.status);
  if (spec.drive) rows = rows.filter((r) => has(r.drive, spec.drive));
  if (spec.event) rows = rows.filter((r) => has(r.event, spec.event));
  if (spec.q.trim()) rows = rows.filter((r) => Object.values(r).some((v) => typeof v !== 'object' && has(v, spec.q)));
  const cols = spec.cols.map((k) => D.cols.find((c) => c.key === k)).filter((c): c is RCol => !!c);
  const sc = D.cols.find((c) => c.key === spec.sortBy);
  if (sc) {
    rows = rows.slice().sort((a, b) => {
      const x = sc.get(a);
      const y = sc.get(b);
      const r = typeof x === 'number' && typeof y === 'number' ? x - y : String(x).localeCompare(String(y), 'en', { numeric: true });
      return spec.sortDir === 'asc' ? r : -r;
    });
  }
  const gc = D.cols.find((c) => c.key === spec.groupBy);
  const totals = (list: Row[]) => Object.fromEntries(cols.filter((c) => c.total && (c.type === 'number' || c.type === 'money')).map((c) => [c.key, list.reduce((s, r) => s + num(c.get(r)), 0)]));
  const groups: { key: string; rows: Row[]; totals: Record<string, number> }[] = [];
  if (gc) {
    const m = new Map<string, Row[]>();
    for (const r of rows) {
      const k = String(gc.get(r) || '—');
      const a = m.get(k) || [];
      a.push(r);
      m.set(k, a);
    }
    for (const [k, list] of m) groups.push({ key: k, rows: list, totals: totals(list) });
  }
  return { D, cols, rows, groups, grand: totals(rows) };
}

export function fmtCell(c: RCol, v: string | number): string {
  if (c.type === 'money') {
    const x = Math.round(num(v) * 100) / 100;
    return x ? (x < 0 ? '−₹' : '₹') + Math.abs(x).toLocaleString('en-IN') : '';
  }
  if (c.type === 'number') return v || v === 0 ? Number(v).toLocaleString('en-IN', { maximumFractionDigits: 2 }) : '';
  if (c.type === 'date') {
    const s = String(v || '').slice(0, 10);
    const p = s.split('-');
    return p.length === 3 ? p[2] + '-' + p[1] + '-' + p[0] : s;
  }
  return String(v ?? '');
}
export { gb };
