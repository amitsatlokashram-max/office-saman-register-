// Theme: mode (light / dark / system), palette, density, ambient background. Har browser me apni pasand.

export const MODE_KEY = 'office-theme-mode';
export const COLOR_KEY = 'office-theme-color';
export const DENSITY_KEY = 'office-density';
export const AMBIENT_KEY = 'office-ambient';

export const PALETTES = [
  { id: 'aurora', label: 'Aurora (default)', a: '#7256E8', b: '#4F7BEA' },
  { id: 'ocean', label: 'Ocean Blue', a: '#2F6FEB', b: '#06B6D4' },
  { id: 'emerald', label: 'Emerald Mint', a: '#0E9F77', b: '#22C1A0' },
  { id: 'royal', label: 'Royal Purple', a: '#6D28D9', b: '#C026D3' },
  { id: 'minimal', label: 'Minimal White', a: '#1F2937', b: '#475569' },
] as const;
const LEGACY = ['purple', 'blue', 'green', 'red', 'orange', 'pink', 'cyan'];

export type Mode = 'light' | 'dark' | 'system';
export type Density = 'compact' | 'comfortable' | 'spacious';

function get(k: string): string {
  try {
    return localStorage.getItem(k) || '';
  } catch {
    return '';
  }
}
export function readTheme(): { mode: Mode; color: string; density: Density; ambient: boolean } {
  const m = get(MODE_KEY);
  const c = get(COLOR_KEY);
  const d = get(DENSITY_KEY);
  return {
    mode: m === 'dark' || m === 'system' ? m : 'light',
    color: PALETTES.some((p) => p.id === c) || LEGACY.includes(c) ? c : 'aurora',
    density: d === 'compact' || d === 'spacious' ? d : 'comfortable',
    ambient: get(AMBIENT_KEY) !== '0',
  };
}

let mql: MediaQueryList | null = null;
export function applyTheme(animate = false) {
  if (typeof window === 'undefined') return;
  const t = readTheme();
  const root = document.documentElement;
  if (animate) root.classList.add('theme-anim');
  const dark = t.mode === 'dark' || (t.mode === 'system' && window.matchMedia('(prefers-color-scheme: dark)').matches);
  root.dataset.theme = dark ? 'dark' : 'light';
  root.dataset.color = t.color;
  root.dataset.density = t.density;
  root.classList.toggle('no-ambient', !t.ambient);
  if (!mql) {
    mql = window.matchMedia('(prefers-color-scheme: dark)');
    mql.addEventListener('change', () => readTheme().mode === 'system' && applyTheme(true));
  }
  if (animate) window.setTimeout(() => root.classList.remove('theme-anim'), 350);
}
export function setThemePref(k: string, v: string) {
  try {
    localStorage.setItem(k, v);
  } catch {
    /* ignore */
  }
  applyTheme(true);
}

/** Paint se pehle (layout.tsx inline script) */
export const THEME_BOOT =
  "try{var s=localStorage,m=s.getItem('office-theme-mode'),c=s.getItem('office-theme-color')||'aurora',d=s.getItem('office-density')||'comfortable',r=document.documentElement;" +
  "var dk=m==='dark'||(m==='system'&&matchMedia('(prefers-color-scheme: dark)').matches);r.dataset.theme=dk?'dark':'light';r.dataset.color=c;r.dataset.density=d;" +
  "if(s.getItem('office-ambient')==='0')r.classList.add('no-ambient');if(s.getItem('osr-lang')==='hi')r.lang='hi'}catch(e){document.documentElement.dataset.theme='light';document.documentElement.dataset.color='aurora'}";
