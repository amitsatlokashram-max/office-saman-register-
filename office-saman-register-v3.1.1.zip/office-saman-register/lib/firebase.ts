// Saari Firebase baat-cheet isi file me hai: login, entries, stock setting, team list aur bill files.
// Ye sirf browser me chalti hai (components ke useEffect / click se).

import { getApp, getApps, initializeApp, type FirebaseApp } from 'firebase/app';
import {
  GoogleAuthProvider,
  browserLocalPersistence,
  browserSessionPersistence,
  getAuth,
  setPersistence,
  getRedirectResult,
  onAuthStateChanged,
  signInWithPopup,
  signInWithRedirect,
  signOut,
  type Auth,
} from 'firebase/auth';
import {
  Bytes,
  collection,
  deleteDoc,
  doc,
  getDoc,
  getFirestore,
  initializeFirestore,
  memoryLocalCache,
  onSnapshot,
  persistentLocalCache,
  persistentMultipleTabManager,
  setDoc,
  type Firestore,
} from 'firebase/firestore';
import { normalizeItem } from './calc';
import { errCode } from './errors';
import { clearSignIn, markSignIn, sessionValid } from './session';
import type { Item, Me, MinMap } from './types';

const config = {
  apiKey: process.env.NEXT_PUBLIC_FIREBASE_API_KEY || '',
  authDomain: process.env.NEXT_PUBLIC_FIREBASE_AUTH_DOMAIN || '',
  projectId: process.env.NEXT_PUBLIC_FIREBASE_PROJECT_ID || '',
  storageBucket: process.env.NEXT_PUBLIC_FIREBASE_STORAGE_BUCKET || '',
  messagingSenderId: process.env.NEXT_PUBLIC_FIREBASE_MESSAGING_SENDER_ID || '',
  appId: process.env.NEXT_PUBLIC_FIREBASE_APP_ID || '',
};

const REQUIRED_FIREBASE_CONFIG = [
  ['NEXT_PUBLIC_FIREBASE_API_KEY', config.apiKey],
  ['NEXT_PUBLIC_FIREBASE_AUTH_DOMAIN', config.authDomain],
  ['NEXT_PUBLIC_FIREBASE_PROJECT_ID', config.projectId],
  ['NEXT_PUBLIC_FIREBASE_STORAGE_BUCKET', config.storageBucket],
  ['NEXT_PUBLIC_FIREBASE_MESSAGING_SENDER_ID', config.messagingSenderId],
  ['NEXT_PUBLIC_FIREBASE_APP_ID', config.appId],
] as const;

export const missingFirebaseConfig = REQUIRED_FIREBASE_CONFIG
  .filter(([, value]) => !value.trim())
  .map(([key]) => key);

export const configOK = missingFirebaseConfig.length === 0;

const SAFE_CONFIG = {
  apiKey: 'demo-key',
  authDomain: 'demo-project.firebaseapp.com',
  projectId: 'demo-project',
  storageBucket: 'demo-project.firebasestorage.app',
  messagingSenderId: '0000000000',
  appId: '1:0000000000:web:demo',
};

let _app: FirebaseApp | null = null;
let _auth: Auth | null = null;
let _db: Firestore | null = null;

function fbApp(): FirebaseApp {
  if (!_app) _app = getApps().length ? getApp() : initializeApp(configOK ? config : SAFE_CONFIG);
  return _app;
}
function fbAuth(): Auth {
  if (!_auth) _auth = getAuth(fbApp());
  return _auth;
}
function fbDb(): Firestore {
  if (_db) return _db;

  if (!configOK) {
    _db = getFirestore(fbApp());
    return _db;
  }

  if (typeof window !== 'undefined') {
    try {
      // Net na ho tab bhi chale: data phone me bhi rehta hai
      _db = initializeFirestore(fbApp(), {
        ignoreUndefinedProperties: true,
        localCache: persistentLocalCache({ tabManager: persistentMultipleTabManager() }),
      });
      return _db;
    } catch {
      // Fall through to in-memory cache for browsers that block persistent storage.
    }
  }

  try {
    _db = initializeFirestore(fbApp(), { ignoreUndefinedProperties: true, localCache: memoryLocalCache() });
  } catch {
    _db = getFirestore(fbApp());
  }
  return _db;
}


/** Naye modules (Hard Disk, catalogue, backup…) ke liye wahi database. */
export function database(): Firestore {
  return fbDb();
}

/** Login wala user (email ke saath) — audit log aur permissions ke liye. */
export function currentEmail(): string {
  return (fbAuth().currentUser?.email || '').toLowerCase();
}

/* ---------- write helpers ---------- */
type Notifier = { late: (e: unknown) => void; queued: () => void };
let notifier: Notifier = { late: () => {}, queued: () => {} };
export function setNotifier(n: Notifier) {
  notifier = n;
}

// 3 second me jawab na aaye (net nahi hai) to aage badh jao; Firestore write ko queue me rakh ke baad me bhej deta hai.
function settle<T>(p: Promise<T>): Promise<T | 'queued'> {
  return new Promise((resolve, reject) => {
    let done = false;
    const t = setTimeout(() => {
      if (done) return;
      done = true;
      if (typeof navigator !== 'undefined' && !navigator.onLine) notifier.queued();
      resolve('queued');
    }, 3000);
    p.then(
      (v) => {
        if (done) return;
        done = true;
        clearTimeout(t);
        resolve(v);
      },
      (e) => {
        clearTimeout(t);
        if (done) notifier.late(e);
        else {
          done = true;
          reject(e);
        }
      },
    );
  });
}

/* ---------- login ---------- */
export function watchAuth(cb: (me: Me | null) => void, onAuthError: (e: unknown) => void): () => void {
  const a = fbAuth();
  getRedirectResult(a).catch(onAuthError);
  let firstCall = true;
  return onAuthStateChanged(a, (u) => {
    // Pehle call par loading dikhavo, Firebase initialize hon ka baad.
    if (firstCall) {
      firstCall = false;
      // Agar pehle call me user nahi aaya, tabhi login dikhavo.
      if (!u) {
        cb(null);
        return;
      }
      // User mil gaya, loading hatake dashboard dikhavo.
      cb(u ? { uid: u.uid, name: u.displayName || u.email || 'Koi', email: u.email || '' } : null);
      return;
    }
    // Doosre call (state change) par: ya user login hai ya logout hua.
    if (u && !sessionValid()) {
      signOut(a).catch(() => {});
      cb(null);
      return;
    }
    cb(u ? { uid: u.uid, name: u.displayName || u.email || 'Koi', email: u.email || '' } : null);
  });
}

/** remember = true: is device pe login yaad rahe. false: tab band karte hi logout. */
export async function signInGoogle(remember: boolean): Promise<void> {
  const p = new GoogleAuthProvider();
  p.setCustomParameters({ prompt: 'select_account' });
  try {
    await setPersistence(fbAuth(), remember ? browserLocalPersistence : browserSessionPersistence);
  } catch {
    /* purana browser: jo chal raha hai wahi */
  }
  markSignIn(remember);

  // Phone check: mobile pe bina pop-up direct redirect se login hoga
  const isMobile = typeof navigator !== 'undefined' && /iPhone|iPad|iPod|Android/i.test(navigator.userAgent);
  if (isMobile) {
    await signInWithRedirect(fbAuth(), p);
    return;
  }

  try {
    await signInWithPopup(fbAuth(), p);
  } catch (e) {
    const c = errCode(e);
    if (c === 'auth/popup-blocked' || c === 'auth/operation-not-supported-in-this-environment' || c === 'auth/cancelled-popup-request') {
      await signInWithRedirect(fbAuth(), p);
      return;
    }
    if (c === 'auth/popup-closed-by-user') return;
    throw e;
  }
}

export function signOutUser(): Promise<void> {
  clearSignIn();
  return signOut(fbAuth());
}

export async function idToken(): Promise<string | null> {
  const u = fbAuth().currentUser;
  return u ? u.getIdToken() : null;
}

/* ---------- entries ---------- */
export function subscribeItems(next: (items: Item[]) => void, onError: (code: string) => void): () => void {
  return onSnapshot(
    collection(fbDb(), 'purchases'),
    (snap) => next(snap.docs.map((d) => normalizeItem(d.id, d.data()))),
    (e) => onError(errCode(e)),
  );
}

export function newItemId(): string {
  return doc(collection(fbDb(), 'purchases')).id;
}

const chain: Record<string, Promise<unknown>> = {};

export function writeItem(it: Item, me: Me | null): Promise<unknown> {
  const { id, ...rest } = it;
  const data = { ...rest, updatedAt: new Date().toISOString(), ...(me ? { updatedBy: me.uid, updatedByName: me.name } : {}) };
  const p = (chain[id] || Promise.resolve())
    .catch(() => {})
    .then(() => setDoc(doc(fbDb(), 'purchases', id), data));
  chain[id] = p;
  return settle(p);
}

export function deleteItemDoc(id: string): Promise<unknown> {
  return settle(deleteDoc(doc(fbDb(), 'purchases', id)));
}

/* ---------- kam se kam stock ---------- */
export function subscribeMin(next: (m: MinMap) => void): () => void {
  return onSnapshot(
    doc(fbDb(), 'settings', 'stock'),
    (s) => {
      const d = s.exists() ? s.data() : null;
      const m: MinMap = {};
      if (d && d.min && typeof d.min === 'object') {
        for (const [k, v] of Object.entries(d.min as Record<string, unknown>)) {
          const n = Number(v);
          if (n > 0) m[k] = n;
        }
      }
      next(m);
    },
    () => {},
  );
}

export function writeMin(m: MinMap): Promise<unknown> {
  const p = (chain.__min || Promise.resolve()).catch(() => {}).then(() => setDoc(doc(fbDb(), 'settings', 'stock'), { min: m }));
  chain.__min = p;
  return settle(p);
}

/* ---------- team ---------- */
export async function readTeam(): Promise<string[]> {
  const s = await getDoc(doc(fbDb(), 'config', 'access'));
  const e = s.exists() ? s.data().emails : null;
  return Array.isArray(e) ? e.filter((x): x is string => typeof x === 'string') : [];
}

export function writeTeam(list: string[], me: Me | null): Promise<void> {
  // merge: roles / perms (Roles page wale) na mitein
  return setDoc(
    doc(fbDb(), 'config', 'access'),
    {
      emails: list,
      updatedAt: new Date().toISOString(),
      updatedBy: me ? me.email : '',
    },
    { merge: true },
  );
}

/* ---------- bill files (Firestore ke andar, free plan ke liye) ---------- */
export async function putBillDoc(bytes: Uint8Array, meta: { type: string; name: string }, me: Me | null): Promise<string> {
  const ref = doc(collection(fbDb(), 'bills'));
  await settle(
    setDoc(ref, {
      data: Bytes.fromUint8Array(bytes),
      type: meta.type,
      name: meta.name,
      size: bytes.length,
      createdAt: new Date().toISOString(),
      by: me ? me.uid : '',
    }),
  );
  return ref.id;
}

export async function readBillDoc(id: string): Promise<{ bytes: Uint8Array; type: string; name: string }> {
  const s = await getDoc(doc(fbDb(), 'bills', id));
  if (!s.exists()) throw { code: 'not-found' };
  const d = s.data();
  return {
    bytes: (d.data as Bytes).toUint8Array(),
    type: typeof d.type === 'string' ? d.type : 'application/octet-stream',
    name: typeof d.name === 'string' ? d.name : 'bill',
  };
}

export function deleteBillDoc(id: string): Promise<void> {
  return deleteDoc(doc(fbDb(), 'bills', id));
}