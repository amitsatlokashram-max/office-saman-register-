'use client';

// Do bhasha: English / हिन्दी. Menu, headings aur zaroori shabd. Choice is browser me yaad rehti hai.

import { createContext, useCallback, useContext, useEffect, useState, type ReactNode } from 'react';

export type Lang = 'en' | 'hi';

const HI: Record<string, string> = {
  Dashboard: 'डैशबोर्ड',
  Overview: 'मुख्य',
  Inventory: 'इन्वेंटरी',
  Items: 'सामान रजिस्टर',
  Stock: 'स्टॉक',
  'Issued items': 'किसको दिया',
  'Demand list': 'डिमांड लिस्ट',
  Storage: 'स्टोरेज',
  'Hard Disks': 'हार्ड डिस्क',
  'Data catalogue': 'डेटा कैटलॉग',
  Backups: 'बैकअप',
  Locations: 'लोकेशन / रैक',
  Tools: 'टूल्स',
  'QR stickers': 'QR स्टिकर',
  'QR scan': 'QR स्कैन',
  Search: 'खोजें',
  Accounts: 'हिसाब',
  Reports: 'रिपोर्ट',
  Admin: 'एडमिन',
  'Roles & access': 'रोल और एक्सेस',
  'Audit log': 'ऑडिट लॉग',
  'Recycle bin': 'रीसायकल बिन',
  Settings: 'सेटिंग्स',
  Logout: 'लॉगआउट',
  Notifications: 'सूचनाएं',
  'Quick add': 'जल्दी जोड़ें',
  Menu: 'मेन्यू',
  Scan: 'स्कैन',
  Drives: 'ड्राइव',
  'Search everything…': 'सब कुछ खोजें…',
  'New item': 'नया सामान',
  'New drive': 'नई ड्राइव',
  'Catalogue entry': 'कैटलॉग एंट्री',
  'All caught up': 'सब ठीक है',
  'Report builder': 'रिपोर्ट बिल्डर',
  'Persons & Departments': 'व्यक्ति और विभाग',
  Persons: 'व्यक्ति',
  Departments: 'विभाग',
  'Digital Data Manager': 'डिजिटल डेटा मैनेजर',
  'Data dashboard': 'डेटा डैशबोर्ड',
  'All drives': 'सभी ड्राइव',
  Events: 'इवेंट',
  'Accounts reports': 'हिसाब रिपोर्ट',
  'Cash calculator': 'कैश कैलकुलेटर',
  'Racks (optional)': 'रैक (वैकल्पिक)',
};

type Ctx = { lang: Lang; setLang: (l: Lang) => void; t: (s: string) => string };
const LangCtx = createContext<Ctx>({ lang: 'en', setLang: () => {}, t: (s) => s });

export function LangProvider({ children }: { children: ReactNode }) {
  const [lang, setL] = useState<Lang>('en');
  useEffect(() => {
    try {
      if (localStorage.getItem('osr-lang') === 'hi') setL('hi');
    } catch {
      /* ignore */
    }
  }, []);
  const setLang = useCallback((l: Lang) => {
    setL(l);
    document.documentElement.lang = l === 'hi' ? 'hi' : 'en';
    try {
      localStorage.setItem('osr-lang', l);
    } catch {
      /* ignore */
    }
  }, []);
  const t = useCallback((s: string) => (lang === 'hi' ? HI[s] || s : s), [lang]);
  return <LangCtx.Provider value={{ lang, setLang, t }}>{children}</LangCtx.Provider>;
}

export const useLang = () => useContext(LangCtx);
