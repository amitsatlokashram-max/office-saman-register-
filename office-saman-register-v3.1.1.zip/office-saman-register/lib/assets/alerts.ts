// Notification Centre: sab alert asli data se nikalte hai (koi hardcoded number nahi).

import { daysTo, myPay, today, warrantyState } from '../calc';
import type { Item, StockGroup } from '../types';
import { almostFull, copyState, overdue, usedPct } from './model';
import type { Backup, CatalogEntry, Drive } from './types';

export type AlertKind = 'stock' | 'warranty' | 'overdue' | 'full' | 'backup' | 'money' | 'demand' | 'damaged';
export type AppAlert = {
  id: string;
  kind: AlertKind;
  level: 'red' | 'amber' | 'blue';
  title: string;
  detail: string;
  href: string;
};

export function buildAlerts(o: {
  items: Item[];
  groups: StockGroup[];
  drives: Drive[];
  catalog: CatalogEntry[];
  backups: Backup[];
  pendingDemands: number;
  canDrives: boolean;
  canCatalog: boolean;
}): AppAlert[] {
  const out: AppAlert[] = [];
  const t = today();

  for (const g of o.groups.filter((x) => x.low)) {
    out.push({ id: 'low-' + g.key, kind: 'stock', level: 'red', title: 'Low stock: ' + g.name, detail: g.bacha + ' left (minimum ' + g.min + ')', href: '/stock' });
  }
  for (const it of o.items) {
    const w = warrantyState(it);
    if (w && w.key === 'soon') out.push({ id: 'w-' + it.id, kind: 'warranty', level: 'amber', title: 'Warranty ending: ' + it.item, detail: w.label, href: '/saman' });
  }
  const due = o.items.reduce((s, it) => s + myPay(it).due, 0);
  if (due > 0) out.push({ id: 'money', kind: 'money', level: 'blue', title: 'Reimbursement pending', detail: '₹' + due.toLocaleString('en-IN') + ' of your own money is still due', href: '/hisaab' });
  if (o.pendingDemands > 0) out.push({ id: 'dem', kind: 'demand', level: 'blue', title: o.pendingDemands + ' demand(s) pending', detail: 'Items requested but not yet received', href: '/demand' });

  if (o.canDrives) {
    for (const d of o.drives) {
      if (overdue(d, t)) {
        const n = -(daysTo(d.holder!.expectedReturn) || 0);
        out.push({ id: 'od-' + d.id, kind: 'overdue', level: 'red', title: 'Overdue return: ' + d.displayName, detail: (d.holder?.name || '') + ' · ' + n + ' day(s) late', href: '/drives/' + d.id });
      }
      if (almostFull(d)) out.push({ id: 'full-' + d.id, kind: 'full', level: 'amber', title: 'Almost full: ' + d.displayName, detail: Math.round(usedPct(d)) + '% used', href: '/drives/' + d.id });
      const wd = daysTo(d.warrantyTill);
      if (wd !== null && wd >= 0 && wd <= 30) out.push({ id: 'dw-' + d.id, kind: 'warranty', level: 'amber', title: 'Drive warranty ending: ' + d.displayName, detail: wd + ' day(s) left', href: '/drives/' + d.id });
      if (d.status === 'damaged' || d.health === 'Bad') out.push({ id: 'dmg-' + d.id, kind: 'damaged', level: 'red', title: 'Damaged / bad health: ' + d.displayName, detail: 'Check data and backups on this drive', href: '/drives/' + d.id });
    }
  }
  if (o.canCatalog) {
    for (const c of o.catalog) {
      if (c.priority !== 'Critical' && c.priority !== 'High') continue;
      const s = copyState(c, o.backups);
      if (s.state === 'none') out.push({ id: 'nb-' + c.id, kind: 'backup', level: 'red', title: 'No backup: ' + (c.title || c.project), detail: c.priority + ' priority data has only one copy', href: '/backups' });
      else if (s.state === 'outdated') out.push({ id: 'ob-' + c.id, kind: 'backup', level: 'amber', title: 'Backup outdated: ' + (c.title || c.project), detail: 'Data changed after the last copy', href: '/backups' });
    }
  }
  const rank = { red: 0, amber: 1, blue: 2 };
  return out.sort((a, b) => rank[a.level] - rank[b.level]);
}
