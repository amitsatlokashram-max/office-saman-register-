// CSV padhna (drive scan ki list) aur kisi bhi table ko CSV banana.

import type { ParsedFile } from './db';

/** RFC-4180 jaisa CSV parser: quotes, commas aur newline quotes ke andar. */
export function parseCsv(text: string): string[][] {
  const rows: string[][] = [];
  let row: string[] = [];
  let cell = '';
  let q = false;
  const t = text.replace(/^\uFEFF/, '');
  for (let i = 0; i < t.length; i++) {
    const c = t[i];
    if (q) {
      if (c === '"') {
        if (t[i + 1] === '"') {
          cell += '"';
          i++;
        } else q = false;
      } else cell += c;
      continue;
    }
    if (c === '"') q = true;
    else if (c === ',') {
      row.push(cell);
      cell = '';
    } else if (c === '\n' || c === '\r') {
      if (c === '\r' && t[i + 1] === '\n') i++;
      row.push(cell);
      cell = '';
      if (row.some((x) => x.trim() !== '')) rows.push(row);
      row = [];
    } else cell += c;
  }
  row.push(cell);
  if (row.some((x) => x.trim() !== '')) rows.push(row);
  return rows;
}

/**
 * Drive scan CSV: columns path,size,modified (header ho ya na ho).
 * Windows PowerShell ka Export-Csv (FullName, Length, LastWriteTime) bhi chalega.
 * Drive letter / volume ka hissa hata dete hai taaki path drive ke andar se shuru ho.
 */
export function parseScanCsv(text: string): { files: ParsedFile[]; skipped: number } {
  const rows = parseCsv(text);
  if (!rows.length) return { files: [], skipped: 0 };
  const head = rows[0].map((h) => h.trim().toLowerCase());
  const known = (n: string[]) => head.findIndex((h) => n.includes(h));
  let ip = known(['path', 'fullname', 'full path', 'file']);
  let is = known(['size', 'length', 'bytes']);
  let im = known(['modified', 'lastwritetime', 'mtime', 'date']);
  let start = 1;
  if (ip < 0) {
    ip = 0;
    is = 1;
    im = 2;
    start = 0;
  }
  const files: ParsedFile[] = [];
  let skipped = 0;
  for (const r of rows.slice(start)) {
    let p = (r[ip] || '').trim();
    const size = Number(String(r[is] ?? '').replace(/[^\d.]/g, ''));
    if (!p || !Number.isFinite(size)) {
      skipped++;
      continue;
    }
    p = p.replace(/\\/g, '/');
    p = p.replace(/^[A-Za-z]:\//, ''); // E:/…
    p = p.replace(/^\/Volumes\/[^/]+\//, ''); // macOS
    p = p.replace(/^\/media\/[^/]+\/[^/]+\//, ''); // Linux
    p = p.replace(/^\.\//, '');
    p = p.replace(/^\/+/, '');
    const base = p.split('/').pop() || '';
    if (!base || base.startsWith('._') || base === '.DS_Store' || base === 'Thumbs.db' || base === 'desktop.ini') {
      skipped++;
      continue;
    }
    files.push({ path: p, size: Math.round(size), modified: (r[im] || '').trim().slice(0, 19) });
  }
  return { files, skipped };
}

export function toCsv(headers: string[], rows: (string | number | boolean | null | undefined)[][]): string {
  const esc = (v: unknown) => {
    const s = v === null || v === undefined ? '' : String(v);
    return /[",\n\r]/.test(s) ? '"' + s.replace(/"/g, '""') + '"' : s;
  };
  return '\uFEFF' + [headers, ...rows].map((r) => r.map(esc).join(',')).join('\r\n');
}
