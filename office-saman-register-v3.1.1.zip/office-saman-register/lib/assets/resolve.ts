import type { Drive } from './types';

/** QR / barcode / haath se likha code → drive. "DRV-0001", ".../a/DRV-0001", "Mark 12", "12" sab chalte hai. */
export function resolveCode(raw: string, drives: Drive[]): Drive | undefined {
  let s = String(raw || '').trim();
  const m = /\/a\/([^/?#]+)/.exec(s);
  if (m) s = decodeURIComponent(m[1]);
  const up = s.toUpperCase();
  const live = drives.filter((d) => !d.deletedAt);
  const byAsset = live.find((d) => d.assetId.toUpperCase() === up) || drives.find((d) => d.assetId.toUpperCase() === up);
  if (byAsset) return byAsset;
  const byName = live.find((d) => d.displayName.toUpperCase() === up);
  if (byName) return byName;
  const n = /^(?:[A-Z ]*?)\s*(\d+)$/.exec(up);
  if (n) return live.find((d) => d.markNo === Number(n[1]));
  const bySerial = live.find((d) => d.serialKey && d.serialKey === up.replace(/[^A-Z0-9]/g, ''));
  return bySerial;
}
