// Hard Disk / SSD, location, data catalogue, backup aur audit ke types.

export const DRIVE_TYPES = ['HDD', 'SSD', 'NVMe', 'USB', 'MemoryCard'] as const;
export type DriveType = (typeof DRIVE_TYPES)[number];
export const DRIVE_TYPE_LABEL: Record<DriveType, string> = {
  HDD: 'Hard Disk (HDD)',
  SSD: 'SSD',
  NVMe: 'NVMe SSD',
  USB: 'USB / Pen drive',
  MemoryCard: 'Memory card',
};

export const DRIVE_FORMS = ['external', 'internal'] as const;
export type DriveForm = (typeof DRIVE_FORMS)[number];

export const DRIVE_STATUS = ['in_store', 'issued', 'temp_issued', 'repair', 'damaged', 'lost', 'retired'] as const;
export type DriveStatus = (typeof DRIVE_STATUS)[number];
export const DRIVE_STATUS_LABEL: Record<DriveStatus, string> = {
  in_store: 'In store',
  issued: 'Issued',
  temp_issued: 'Temporary issue',
  repair: 'In repair',
  damaged: 'Damaged',
  lost: 'Lost',
  retired: 'Retired',
};
export const DRIVE_STATUS_TONE: Record<DriveStatus, Tone> = {
  in_store: 'green',
  issued: 'indigo',
  temp_issued: 'blue',
  repair: 'amber',
  damaged: 'red',
  lost: 'red',
  retired: 'gray',
};

export const CONDITIONS = ['New', 'Good', 'Fair', 'Poor', 'Damaged'] as const;
export const HEALTH = ['Unknown', 'Good', 'Caution', 'Bad'] as const;

export type Tone = 'green' | 'indigo' | 'blue' | 'amber' | 'red' | 'gray' | 'violet';

export type Holder = {
  name: string;
  dept: string;
  since: string;
  expectedReturn: string;
  transferId: string;
  temporary: boolean;
};

export const SERIES = ['HDD', 'SSD', 'USB', 'CARD'] as const;
export type SeriesKey = (typeof SERIES)[number];
export const SERIES_OF: Record<DriveType, SeriesKey> = { HDD: 'HDD', SSD: 'SSD', NVMe: 'SSD', USB: 'USB', MemoryCard: 'CARD' };
export type NamingSeries = { prefix: string; suffix: string; pad: number; start: number };
export const DEFAULT_NAMING: Record<SeriesKey, NamingSeries> = {
  HDD: { prefix: 'Mark ', suffix: '', pad: 0, start: 1 },
  SSD: { prefix: 'SSD Mark ', suffix: '', pad: 0, start: 1 },
  USB: { prefix: 'Pen Drive ', suffix: '', pad: 0, start: 1 },
  CARD: { prefix: 'Card ', suffix: '', pad: 0, start: 1 },
};
export const SERIES_LABEL: Record<SeriesKey, string> = { HDD: 'Hard Disk', SSD: 'SSD / NVMe', USB: 'Pen drive', CARD: 'Memory card' };

export type Drive = {
  id: string;
  assetId: string;
  /** naam ki series (HDD / SSD / …). Mark number isi series me unique */
  series: SeriesKey;
  markNo: number;
  /** Ashram wali simple jagah: "Main Media Office", "Delhi Office"… (rack/slot optional) */
  place: string;
  displayName: string;
  type: DriveType;
  form: DriveForm;
  brand: string;
  model: string;
  serial: string;
  serialKey: string;
  capacityGB: number;
  usedGB: number;
  iface: string;
  fileSystem: string;
  purchaseDate: string;
  price: number;
  purchaseId: string;
  billNo: string;
  warrantyTill: string;
  photos: string[];
  condition: string;
  health: string;
  status: DriveStatus;
  holder: Holder | null;
  dept: string;
  locationId: string;
  lastScanAt: string;
  lastBackupAt: string;
  description: string;
  custom: Record<string, string>;
  tokens: string[];
  deletedAt: string;
  deletedBy: string;
  createdAt: string;
  createdBy: string;
  createdByName: string;
  updatedAt: string;
  updatedBy: string;
  updatedByName: string;
};

export const TRANSFER_KINDS = [
  'issue',
  'temp_issue',
  'return',
  'dept_transfer',
  'location_transfer',
  'repair',
  'damaged',
  'lost',
  'retire',
  'restore',
] as const;
export type TransferKind = (typeof TRANSFER_KINDS)[number];
export const TRANSFER_LABEL: Record<TransferKind, string> = {
  issue: 'Issued to person',
  temp_issue: 'Temporary issue',
  return: 'Returned to store',
  dept_transfer: 'Department transfer',
  location_transfer: 'Location transfer',
  repair: 'Sent for repair',
  damaged: 'Marked damaged',
  lost: 'Marked lost',
  retire: 'Retired',
  restore: 'Back in service',
};

export type Party = { name: string; dept: string; locationId: string; place?: string };

export type Transfer = {
  id: string;
  driveId: string;
  assetId: string;
  mark: string;
  kind: TransferKind;
  from: Party;
  to: Party;
  purpose: string;
  date: string;
  expectedReturn: string;
  actualReturn: string;
  condition: string;
  usedGB: number;
  confirmed: boolean;
  confirmedBy: string;
  confirmedAt: string;
  notes: string;
  at: string;
  by: string;
  byName: string;
};

export const LOCATION_KINDS = ['office', 'building', 'floor', 'room', 'rack', 'shelf', 'slot'] as const;
export type LocationKind = (typeof LOCATION_KINDS)[number];
export const LOCATION_LABEL: Record<LocationKind, string> = {
  office: 'Office',
  building: 'Building',
  floor: 'Floor',
  room: 'Room',
  rack: 'Rack',
  shelf: 'Shelf',
  slot: 'Slot',
};

export type Loc = {
  id: string;
  name: string;
  kind: LocationKind;
  parentId: string;
  order: number;
  note: string;
  deletedAt: string;
  createdAt: string;
};

export const CATALOG_CATEGORIES = [
  'Raw Footage',
  'Final Videos',
  'Premiere Pro Projects',
  'After Effects Projects',
  'Audio',
  'Photos',
  'Graphics',
  'Documents',
  'Live Broadcasts',
  'Thumbnails',
  'Other',
] as const;

export const PRIORITIES = ['Critical', 'High', 'Normal', 'Low'] as const;
export type Priority = (typeof PRIORITIES)[number];

export const DATA_STATUS = ['Received', 'Registered', 'Editing', 'Edited', 'Backed up', 'Archived'] as const;

export type CatalogEntry = {
  id: string;
  driveId: string;
  eventId: string;
  recordingDate: string;
  status: string;
  project: string;
  title: string;
  episode: string;
  eventName: string;
  eventDate: string;
  year: string;
  dept: string;
  category: string;
  fileType: string;
  folderPath: string;
  sizeGB: number;
  fileCount: number;
  owner: string;
  priority: Priority;
  tags: string[];
  description: string;
  custom: Record<string, string>;
  tokens: string[];
  deletedAt: string;
  createdAt: string;
  createdBy: string;
  createdByName: string;
  updatedAt: string;
  updatedByName: string;
};

export const BACKUP_STATUS = ['assigned', 'completed', 'verified', 'failed'] as const;
export type BackupStatus = (typeof BACKUP_STATUS)[number];
export const BACKUP_STATUS_LABEL: Record<BackupStatus, string> = {
  assigned: 'Assigned (copy pending)',
  completed: 'Copied — not verified',
  verified: 'Verified',
  failed: 'Verification failed',
};

export type BackupEvent = { at: string; by: string; what: string };

export type Backup = {
  id: string;
  catalogId: string;
  sourceDriveId: string;
  copyDriveId: string;
  copyPath: string;
  status: BackupStatus;
  method: '' | 'sha256' | 'md5' | 'xxhash';
  sourceHash: string;
  copyHash: string;
  sourceFiles: number;
  copyFiles: number;
  completedAt: string;
  verifiedAt: string;
  verifiedBy: string;
  notes: string;
  history: BackupEvent[];
  deletedAt: string;
  createdAt: string;
  createdByName: string;
};

export type IndexedFile = { n: string; s: number; m: string };

export type FileChunk = {
  id: string;
  driveId: string;
  scanId: string;
  folder: string;
  files: IndexedFile[];
  count: number;
  bytes: number;
  tokens: string[];
};

export type Scan = {
  id: string;
  driveId: string;
  source: 'csv' | 'agent';
  at: string;
  by: string;
  byName: string;
  files: number;
  folders: number;
  bytes: number;
  added: number;
  removed: number;
  capacityGB: number;
  freeGB: number;
  note: string;
};

export type Audit = {
  id: string;
  at: string;
  by: string;
  byName: string;
  email: string;
  module: string;
  action: string;
  targetId: string;
  targetLabel: string;
  summary: string;
};

export const EVENT_TYPES = ['Panchayat', 'Satsang', 'Samagam', 'Interview', 'Meeting', 'Spiritual Discourse', 'Live Broadcast', 'Special Program', 'Other'] as const;

export type AshramEvent = {
  id: string;
  eventNo: string;
  title: string;
  type: string;
  date: string;
  time: string;
  recordingDate: string;
  location: string;
  description: string;
  participants: string[];
  mainPersons: string[];
  recordingTeam: string[];
  submittedBy: string;
  receivedBy: string;
  responsible: string;
  project: string;
  episode: string;
  tags: string[];
  links: string[];
  notes: string;
  confidential: boolean;
  tokens: string[];
  deletedAt: string;
  createdAt: string;
  createdByName: string;
  updatedAt: string;
  updatedByName: string;
};

export type Person = {
  id: string;
  name: string;
  aliases: string[];
  depts: string[];
  location: string;
  responsibilities: string;
  phone: string;
  status: 'active' | 'inactive';
  notes: string;
  createdAt: string;
  updatedAt: string;
};

export type Department = {
  id: string;
  name: string;
  aliases: string[];
  head: string;
  location: string;
  notes: string;
  archived: boolean;
  createdAt: string;
};
