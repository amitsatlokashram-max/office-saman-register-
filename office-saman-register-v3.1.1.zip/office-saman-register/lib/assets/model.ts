// Firestore data ko surakshit tareeke se padhna (purane / adhoore documents se app na toote) aur chhote formule.

import { num } from '../calc';
import {
  BACKUP_STATUS,
  DRIVE_FORMS,
  DRIVE_STATUS,
  DRIVE_TYPES,
  LOCATION_KINDS,
  PRIORITIES,
  TRANSFER_KINDS,
  SERIES,
  SERIES_OF,
  DEFAULT_NAMING,
  type AshramEvent,
  type Department,
  type NamingSeries,
  type Person,
  type SeriesKey,
  type Audit,
  type Backup,
  type BackupStatus,
  type CatalogEntry,
  type Drive,
  type DriveStatus,
  type FileChunk,
  type Holder,
  type Loc,
  type Party,
  type Scan,
  type Transfer,
} from './types';

type D = Record<string, unknown>;

const str = (d: D, k: string) => (typeof d[k] === 'string' ? (d[k] as string) : '');
const pick = <T extends string>(v: unknown, list: readonly T[], def: T): T => (list.includes(v as T) ? (v as T) : def);
const strMap = (v: unknown): Record<string, string> => {
  const out: Record<string, string> = {};
  if (v && typeof v === 'object' && !Array.isArray(v)) {
    for (const [k, x] of Object.entries(v as D)) if (typeof x === 'string' || typeof x === 'number') out[k] = String(x);
  }
  return out;
};
const strArr = (v: unknown): string[] => (Array.isArray(v) ? v.filter((x): x is string => typeof x === 'string') : []);
const obj = (v: unknown): D => (v && typeof v === 'object' && !Array.isArray(v) ? (v as D) : {});

/* ---------- text search ---------- */
export function words(...parts: (string | number | undefined | null)[]): string[] {
  const set = new Set<string>();
  for (const p of parts) {
    const s = String(p ?? '').toLowerCase();
    for (const w of s.split(/[^\p{L}\p{N}]+/u)) if (w.length >= 2) set.add(w);
  }
  return Array.from(set);
}
/** Firestore array-contains search ke liye tokens (max 120). */
export const tokens = (...parts: (string | number | undefined | null)[]) => words(...parts).slice(0, 120);

export function matches(hay: string, q: string): boolean {
  const ws = words(q);
  if (!ws.length) return true;
  const h = hay.toLowerCase();
  return ws.every((w) => h.includes(w));
}

export const serialKey = (s: string) => String(s || '').toUpperCase().replace(/[^A-Z0-9]/g, '');

/* ---------- normalizers ---------- */
function holderOf(v: unknown): Holder | null {
  const h = obj(v);
  if (!str(h, 'name') && !str(h, 'dept')) return null;
  return {
    name: str(h, 'name'),
    dept: str(h, 'dept'),
    since: str(h, 'since'),
    expectedReturn: str(h, 'expectedReturn'),
    transferId: str(h, 'transferId'),
    temporary: h.temporary === true,
  };
}

export function normalizeDrive(id: string, d: D): Drive {
  const type = pick(d.type, DRIVE_TYPES, 'HDD');
  return {
    id,
    assetId: str(d, 'assetId'),
    series: pick(d.series, SERIES, SERIES_OF[type]),
    place: str(d, 'place'),
    markNo: Math.round(num(d.markNo)),
    displayName: str(d, 'displayName') || (num(d.markNo) ? 'Mark ' + num(d.markNo) : 'Drive'),
    type,
    form: pick(d.form, DRIVE_FORMS, 'external'),
    brand: str(d, 'brand'),
    model: str(d, 'model'),
    serial: str(d, 'serial'),
    serialKey: str(d, 'serialKey'),
    capacityGB: num(d.capacityGB),
    usedGB: num(d.usedGB),
    iface: str(d, 'iface'),
    fileSystem: str(d, 'fileSystem'),
    purchaseDate: str(d, 'purchaseDate'),
    price: num(d.price),
    purchaseId: str(d, 'purchaseId'),
    billNo: str(d, 'billNo'),
    warrantyTill: str(d, 'warrantyTill'),
    photos: strArr(d.photos),
    condition: str(d, 'condition') || 'Good',
    health: str(d, 'health') || 'Unknown',
    status: pick(d.status, DRIVE_STATUS, 'in_store'),
    holder: holderOf(d.holder),
    dept: str(d, 'dept'),
    locationId: str(d, 'locationId'),
    lastScanAt: str(d, 'lastScanAt'),
    lastBackupAt: str(d, 'lastBackupAt'),
    description: str(d, 'description'),
    custom: strMap(d.custom),
    tokens: strArr(d.tokens),
    deletedAt: str(d, 'deletedAt'),
    deletedBy: str(d, 'deletedBy'),
    createdAt: str(d, 'createdAt'),
    createdBy: str(d, 'createdBy'),
    createdByName: str(d, 'createdByName'),
    updatedAt: str(d, 'updatedAt'),
    updatedBy: str(d, 'updatedBy'),
    updatedByName: str(d, 'updatedByName'),
  };
}

const party = (v: unknown): Party => {
  const p = obj(v);
  return { name: str(p, 'name'), dept: str(p, 'dept'), locationId: str(p, 'locationId'), place: str(p, 'place') };
};

export function normalizeTransfer(id: string, d: D): Transfer {
  return {
    id,
    driveId: str(d, 'driveId'),
    assetId: str(d, 'assetId'),
    mark: str(d, 'mark'),
    kind: pick(d.kind, TRANSFER_KINDS, 'issue'),
    from: party(d.from),
    to: party(d.to),
    purpose: str(d, 'purpose'),
    date: str(d, 'date'),
    expectedReturn: str(d, 'expectedReturn'),
    actualReturn: str(d, 'actualReturn'),
    condition: str(d, 'condition'),
    usedGB: num(d.usedGB),
    confirmed: d.confirmed === true,
    confirmedBy: str(d, 'confirmedBy'),
    confirmedAt: str(d, 'confirmedAt'),
    notes: str(d, 'notes'),
    at: str(d, 'at'),
    by: str(d, 'by'),
    byName: str(d, 'byName'),
  };
}

export function normalizeLoc(id: string, d: D): Loc {
  return {
    id,
    name: str(d, 'name') || 'Untitled',
    kind: pick(d.kind, LOCATION_KINDS, 'room'),
    parentId: str(d, 'parentId'),
    order: num(d.order),
    note: str(d, 'note'),
    deletedAt: str(d, 'deletedAt'),
    createdAt: str(d, 'createdAt'),
  };
}

export function normalizeCatalog(id: string, d: D): CatalogEntry {
  return {
    id,
    driveId: str(d, 'driveId'),
    eventId: str(d, 'eventId'),
    recordingDate: str(d, 'recordingDate'),
    status: str(d, 'status'),
    project: str(d, 'project'),
    title: str(d, 'title'),
    episode: str(d, 'episode'),
    eventName: str(d, 'eventName'),
    eventDate: str(d, 'eventDate'),
    year: str(d, 'year'),
    dept: str(d, 'dept'),
    category: str(d, 'category') || 'Other',
    fileType: str(d, 'fileType'),
    folderPath: str(d, 'folderPath'),
    sizeGB: num(d.sizeGB),
    fileCount: Math.round(num(d.fileCount)),
    owner: str(d, 'owner'),
    priority: pick(d.priority, PRIORITIES, 'Normal'),
    tags: strArr(d.tags),
    description: str(d, 'description'),
    custom: strMap(d.custom),
    tokens: strArr(d.tokens),
    deletedAt: str(d, 'deletedAt'),
    createdAt: str(d, 'createdAt'),
    createdBy: str(d, 'createdBy'),
    createdByName: str(d, 'createdByName'),
    updatedAt: str(d, 'updatedAt'),
    updatedByName: str(d, 'updatedByName'),
  };
}

export function normalizeBackup(id: string, d: D): Backup {
  const m = str(d, 'method');
  return {
    id,
    catalogId: str(d, 'catalogId'),
    sourceDriveId: str(d, 'sourceDriveId'),
    copyDriveId: str(d, 'copyDriveId'),
    copyPath: str(d, 'copyPath'),
    status: pick(d.status, BACKUP_STATUS, 'assigned'),
    method: m === 'sha256' || m === 'md5' || m === 'xxhash' ? m : '',
    sourceHash: str(d, 'sourceHash'),
    copyHash: str(d, 'copyHash'),
    sourceFiles: Math.round(num(d.sourceFiles)),
    copyFiles: Math.round(num(d.copyFiles)),
    completedAt: str(d, 'completedAt'),
    verifiedAt: str(d, 'verifiedAt'),
    verifiedBy: str(d, 'verifiedBy'),
    notes: str(d, 'notes'),
    history: (Array.isArray(d.history) ? d.history : []).map((h) => {
      const o = obj(h);
      return { at: str(o, 'at'), by: str(o, 'by'), what: str(o, 'what') };
    }),
    deletedAt: str(d, 'deletedAt'),
    createdAt: str(d, 'createdAt'),
    createdByName: str(d, 'createdByName'),
  };
}

export function normalizeChunk(id: string, d: D): FileChunk {
  return {
    id,
    driveId: str(d, 'driveId'),
    scanId: str(d, 'scanId'),
    folder: str(d, 'folder'),
    files: (Array.isArray(d.files) ? d.files : []).map((f) => {
      const o = obj(f);
      return { n: str(o, 'n'), s: num(o.s), m: str(o, 'm') };
    }),
    count: num(d.count),
    bytes: num(d.bytes),
    tokens: strArr(d.tokens),
  };
}

export function normalizeScan(id: string, d: D): Scan {
  return {
    id,
    driveId: str(d, 'driveId'),
    source: d.source === 'agent' ? 'agent' : 'csv',
    at: str(d, 'at'),
    by: str(d, 'by'),
    byName: str(d, 'byName'),
    files: num(d.files),
    folders: num(d.folders),
    bytes: num(d.bytes),
    added: num(d.added),
    removed: num(d.removed),
    capacityGB: num(d.capacityGB),
    freeGB: num(d.freeGB),
    note: str(d, 'note'),
  };
}

export function normalizeAudit(id: string, d: D): Audit {
  return {
    id,
    at: str(d, 'at'),
    by: str(d, 'by'),
    byName: str(d, 'byName'),
    email: str(d, 'email'),
    module: str(d, 'module'),
    action: str(d, 'action'),
    targetId: str(d, 'targetId'),
    targetLabel: str(d, 'targetLabel'),
    summary: str(d, 'summary'),
  };
}

/* ---------- drive formule ---------- */
export const freeGB = (d: Pick<Drive, 'capacityGB' | 'usedGB'>) => Math.max(0, d.capacityGB - d.usedGB);
export const usedPct = (d: Pick<Drive, 'capacityGB' | 'usedGB'>) => (d.capacityGB > 0 ? Math.min(100, (d.usedGB / d.capacityGB) * 100) : 0);
export const almostFull = (d: Drive) => d.capacityGB > 0 && usedPct(d) >= 90;
export const isOut = (s: DriveStatus) => s === 'issued' || s === 'temp_issued';
export const isActive = (d: Drive) => !d.deletedAt && d.status !== 'retired';

export function overdue(d: Drive, todayStr: string): boolean {
  return isOut(d.status) && !!d.holder?.expectedReturn && d.holder.expectedReturn < todayStr;
}

/** 1000 GB → "1 TB", 512 → "512 GB" */
export function gb(n: number): string {
  const v = Number(n) || 0;
  if (v >= 1000) return (Math.round((v / 1000) * 100) / 100).toLocaleString('en-IN') + ' TB';
  return (Math.round(v * 10) / 10).toLocaleString('en-IN') + ' GB';
}
export function bytes(n: number): string {
  const v = Number(n) || 0;
  if (v >= 1e12) return (v / 1e12).toFixed(2) + ' TB';
  if (v >= 1e9) return (v / 1e9).toFixed(2) + ' GB';
  if (v >= 1e6) return (v / 1e6).toFixed(1) + ' MB';
  if (v >= 1e3) return (v / 1e3).toFixed(0) + ' KB';
  return v + ' B';
}

/* ---------- location ---------- */
export function locPath(locs: Map<string, Loc>, id: string): Loc[] {
  const out: Loc[] = [];
  const seen = new Set<string>();
  let cur = locs.get(id);
  while (cur && !seen.has(cur.id)) {
    seen.add(cur.id);
    out.unshift(cur);
    cur = cur.parentId ? locs.get(cur.parentId) : undefined;
  }
  return out;
}
export const locLabel = (locs: Map<string, Loc>, id: string) =>
  locPath(locs, id)
    .map((l) => l.name)
    .join(' › ');

/* ---------- backup ---------- */
export type CopyState = 'verified' | 'unverified' | 'outdated' | 'none';

/** Ek catalogue entry ki backup halat. Verified sirf tab jab hash sach me mila ho. */
export function copyState(entry: CatalogEntry, list: Backup[]): { state: CopyState; verified: number; copies: number } {
  const live = list.filter((b) => !b.deletedAt && b.catalogId === entry.id);
  const done = live.filter((b) => b.status === 'completed' || b.status === 'verified');
  const verified = live.filter((b) => b.status === 'verified');
  const changedAt = entry.updatedAt || entry.createdAt;
  const outdated = done.length > 0 && done.every((b) => (b.verifiedAt || b.completedAt) < changedAt);
  let state: CopyState = 'none';
  if (done.length) state = outdated ? 'outdated' : verified.length ? 'verified' : 'unverified';
  return { state, verified: verified.length, copies: done.length };
}

export function hashVerdict(a: string, b: string): BackupStatus | null {
  const x = a.trim().toLowerCase();
  const y = b.trim().toLowerCase();
  if (!x || !y) return null;
  return x === y ? 'verified' : 'failed';
}

export function nextMarkFrom(drives: Drive[]): number {
  return drives.reduce((m, d) => Math.max(m, d.markNo || 0), 0) + 1;
}

/* ---------- naming series ---------- */
export function normalizeNaming(d: D | null): Record<SeriesKey, NamingSeries> {
  const out = { ...DEFAULT_NAMING } as Record<SeriesKey, NamingSeries>;
  const src = obj(d?.series);
  for (const k of SERIES) {
    const x = obj(src[k]);
    if (Object.keys(x).length)
      out[k] = {
        prefix: typeof x.prefix === 'string' ? x.prefix : DEFAULT_NAMING[k].prefix,
        suffix: typeof x.suffix === 'string' ? x.suffix : '',
        pad: Math.max(0, Math.min(6, Math.round(num(x.pad)))),
        start: Math.max(1, Math.round(num(x.start)) || 1),
      };
  }
  return out;
}
export function seriesName(n: NamingSeries, mark: number): string {
  return n.prefix + String(mark).padStart(n.pad || 0, '0') + n.suffix;
}
export function nextMarkIn(drives: Drive[], series: SeriesKey, naming: Record<SeriesKey, NamingSeries>): number {
  const max = drives.filter((d) => d.series === series).reduce((m, d) => Math.max(m, d.markNo || 0), 0);
  return Math.max(max + 1, naming[series].start);
}

/** Drive abhi kahan hai — ek line me (Ashram ke hisaab se). */
export function whereIs(d: Drive, locs: Map<string, Loc>): string {
  if (isOut(d.status) && d.holder?.name) return 'With ' + d.holder.name + (d.holder.dept ? ' (' + d.holder.dept + ')' : '');
  if (d.status === 'repair') return 'Outside for repair' + (d.holder?.name ? ' — ' + d.holder.name : '');
  if (d.status === 'lost') return 'Lost';
  const rack = d.locationId ? locLabel(locs, d.locationId) : '';
  return [d.place, rack].filter(Boolean).join(' · ') || 'Available in office';
}

/* ---------- events / persons / departments ---------- */
export function normalizeEvent(id: string, d: D): AshramEvent {
  return {
    id,
    eventNo: str(d, 'eventNo'),
    title: str(d, 'title') || 'Untitled event',
    type: str(d, 'type') || 'Other',
    date: str(d, 'date'),
    time: str(d, 'time'),
    recordingDate: str(d, 'recordingDate'),
    location: str(d, 'location'),
    description: str(d, 'description'),
    participants: strArr(d.participants),
    mainPersons: strArr(d.mainPersons),
    recordingTeam: strArr(d.recordingTeam),
    submittedBy: str(d, 'submittedBy'),
    receivedBy: str(d, 'receivedBy'),
    responsible: str(d, 'responsible'),
    project: str(d, 'project'),
    episode: str(d, 'episode'),
    tags: strArr(d.tags),
    links: strArr(d.links),
    notes: str(d, 'notes'),
    confidential: d.confidential === true,
    tokens: strArr(d.tokens),
    deletedAt: str(d, 'deletedAt'),
    createdAt: str(d, 'createdAt'),
    createdByName: str(d, 'createdByName'),
    updatedAt: str(d, 'updatedAt'),
    updatedByName: str(d, 'updatedByName'),
  };
}
export function normalizePerson(id: string, d: D): Person {
  return {
    id,
    name: str(d, 'name') || 'Unknown',
    aliases: strArr(d.aliases),
    depts: strArr(d.depts),
    location: str(d, 'location'),
    responsibilities: str(d, 'responsibilities'),
    phone: str(d, 'phone'),
    status: d.status === 'inactive' ? 'inactive' : 'active',
    notes: str(d, 'notes'),
    createdAt: str(d, 'createdAt'),
    updatedAt: str(d, 'updatedAt'),
  };
}
export function normalizeDept(id: string, d: D): Department {
  return {
    id,
    name: str(d, 'name') || 'Unknown',
    aliases: strArr(d.aliases),
    head: str(d, 'head'),
    location: str(d, 'location'),
    notes: str(d, 'notes'),
    archived: d.archived === true,
    createdAt: str(d, 'createdAt'),
  };
}
/** Naam ka key: "Amit ", "amit" → "amit" */
export const nameKey = (s: string) => String(s || '').toLowerCase().replace(/\s+/g, ' ').trim();
