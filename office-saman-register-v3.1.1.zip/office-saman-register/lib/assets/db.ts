// Naye modules ki Firestore baat-cheet. Jahan ek saath kai documents badalte hai wahan transaction hai,
// taaki ek hi Hard Disk do logo ko issue na ho, Mark number dobara na bane, aur stock/custody sahi rahe.

import {
  collection,
  doc,
  getDoc,
  getDocs,
  limit as qlimit,
  onSnapshot,
  orderBy,
  query,
  runTransaction,
  setDoc,
  where,
  writeBatch,
  deleteDoc,
  type DocumentReference,
  type Transaction,
} from 'firebase/firestore';
import { database, currentEmail } from '../firebase';
import { errCode } from '../errors';
import type { Me } from '../types';
import type { PermMap, Role } from '../perm';
import { asRole } from '../perm';
import {
  nameKey,
  normalizeDept,
  normalizeEvent,
  normalizeNaming,
  normalizePerson,
  seriesName,
  normalizeAudit,
  normalizeBackup,
  normalizeCatalog,
  normalizeChunk,
  normalizeDrive,
  normalizeLoc,
  normalizeScan,
  normalizeTransfer,
  serialKey,
  tokens,
} from './model';
import type {
  AshramEvent,
  Department,
  NamingSeries,
  Person,
  SeriesKey,
  Audit,
  Backup,
  CatalogEntry,
  Drive,
  DriveStatus,
  FileChunk,
  Loc,
  Party,
  Scan,
  Transfer,
  TransferKind,
} from './types';

const db = () => database();
const nowIso = () => new Date().toISOString();

export class AppError extends Error {
  code: string;
  constructor(code: string, message: string) {
    super(message);
    this.code = code;
  }
}

/* ---------- subscriptions ---------- */
type Unsub = () => void;
function sub<T>(name: string, norm: (id: string, d: Record<string, unknown>) => T, next: (rows: T[]) => void, onErr: (c: string) => void): Unsub {
  return onSnapshot(
    collection(db(), name),
    (s) => next(s.docs.map((d) => norm(d.id, d.data()))),
    (e) => onErr(errCode(e)),
  );
}
export const subscribeDrives = (n: (r: Drive[]) => void, e: (c: string) => void) => sub('drives', normalizeDrive, n, e);
export const subscribeLocs = (n: (r: Loc[]) => void, e: (c: string) => void) => sub('locations', normalizeLoc, n, e);
export const subscribeCatalog = (n: (r: CatalogEntry[]) => void, e: (c: string) => void) => sub('catalog', normalizeCatalog, n, e);
export const subscribeBackups = (n: (r: Backup[]) => void, e: (c: string) => void) => sub('backups', normalizeBackup, n, e);

export function subscribeTransfers(n: (r: Transfer[]) => void, e: (c: string) => void, max = 400): Unsub {
  return onSnapshot(
    query(collection(db(), 'driveTransfers'), orderBy('at', 'desc'), qlimit(max)),
    (s) => n(s.docs.map((d) => normalizeTransfer(d.id, d.data()))),
    (x) => e(errCode(x)),
  );
}

export function subscribeDriveTransfers(driveId: string, n: (r: Transfer[]) => void): Unsub {
  return onSnapshot(
    query(collection(db(), 'driveTransfers'), where('driveId', '==', driveId)),
    (s) => n(s.docs.map((d) => normalizeTransfer(d.id, d.data())).sort((a, b) => b.at.localeCompare(a.at))),
    () => n([]),
  );
}

export function subscribeDemandCount(n: (pending: number) => void): Unsub {
  return onSnapshot(
    collection(db(), 'demands'),
    (s) =>
      n(
        s.docs.filter((d) => {
          const x = d.data();
          const qty = Number(x.qty) || 0;
          const got = Number.isFinite(Number(x.receivedQty)) ? Number(x.receivedQty) : x.status === 'received' ? qty : 0;
          return qty - got > 0;
        }).length,
      ),
    () => n(-1),
  );
}

export type AccessDoc = { emails: string[]; roles: Record<string, Role>; perms: PermMap | null; exists: boolean };

export function subscribeAccess(n: (a: AccessDoc) => void, e: (c: string) => void): Unsub {
  return onSnapshot(
    doc(db(), 'config', 'access'),
    (s) => {
      const d = s.exists() ? s.data() : {};
      const emails = Array.isArray(d.emails) ? d.emails.filter((x: unknown): x is string => typeof x === 'string') : [];
      const roles: Record<string, Role> = {};
      if (d.roles && typeof d.roles === 'object') for (const [k, v] of Object.entries(d.roles as Record<string, unknown>)) roles[k.toLowerCase()] = asRole(v);
      let perms: PermMap | null = null;
      if (d.perms && typeof d.perms === 'object') {
        perms = {};
        for (const [r, mods] of Object.entries(d.perms as Record<string, unknown>)) {
          perms[r] = {};
          if (mods && typeof mods === 'object')
            for (const [m, acts] of Object.entries(mods as Record<string, unknown>))
              perms[r][m] = Array.isArray(acts) ? acts.filter((x): x is string => typeof x === 'string') : [];
        }
      }
      n({ emails, roles, perms, exists: s.exists() });
    },
    (x) => e(errCode(x)),
  );
}

/** Roles page: team, roles aur permissions ek saath (sirf owner / Super Admin). */
export async function saveAccess(a: { emails: string[]; roles: Record<string, Role>; perms: PermMap }, me: Me | null) {
  await setDoc(
    doc(db(), 'config', 'access'),
    { emails: a.emails, roles: a.roles, perms: a.perms, updatedAt: nowIso(), updatedBy: me ? me.email : '' },
    { merge: false },
  );
  await audit(me, 'roles', 'edit', 'config/access', 'Roles & permissions', a.emails.length + ' members');
}

/* ---------- audit ---------- */
function auditData(me: Me | null, module: string, action: string, targetId: string, targetLabel: string, summary: string) {
  return {
    at: nowIso(),
    by: me?.uid || '',
    byName: me?.name || '',
    email: currentEmail(),
    module,
    action,
    targetId,
    targetLabel: targetLabel.slice(0, 160),
    summary: summary.slice(0, 500),
  };
}
export async function audit(me: Me | null, module: string, action: string, targetId: string, targetLabel: string, summary = '') {
  try {
    await setDoc(doc(collection(db(), 'auditLogs')), auditData(me, module, action, targetId, targetLabel, summary));
  } catch {
    /* audit fail hone se kaam na ruke */
  }
}
function auditTx(tx: Transaction, me: Me | null, module: string, action: string, targetId: string, targetLabel: string, summary = '') {
  tx.set(doc(collection(db(), 'auditLogs')), auditData(me, module, action, targetId, targetLabel, summary));
}
export async function readAudit(max = 300, module = ''): Promise<Audit[]> {
  const base = collection(db(), 'auditLogs');
  const q = module ? query(base, where('module', '==', module), orderBy('at', 'desc'), qlimit(max)) : query(base, orderBy('at', 'desc'), qlimit(max));
  const s = await getDocs(q);
  return s.docs.map((d) => normalizeAudit(d.id, d.data()));
}

/* ---------- drives ---------- */
export type DriveInput = Omit<
  Drive,
  'id' | 'assetId' | 'serialKey' | 'tokens' | 'deletedAt' | 'deletedBy' | 'createdAt' | 'createdBy' | 'createdByName' | 'updatedAt' | 'updatedBy' | 'updatedByName' | 'holder' | 'status'
> & { status?: DriveStatus };

function driveTokens(d: Pick<Drive, 'assetId' | 'displayName' | 'markNo' | 'brand' | 'model' | 'serial' | 'type' | 'dept' | 'description' | 'place'>) {
  return tokens(d.assetId, d.displayName, 'mark ' + d.markNo, d.brand, d.model, d.serial, d.type, d.dept, d.description, d.place);
}

/** Mark number ki rok har series me alag: "SSD-80", "HDD-43" */
const markRef = (series: SeriesKey, n: number) => doc(db(), 'driveMarks', series + '-' + n);
const serialRef = (k: string) => doc(db(), 'driveSerials', k);
const slotRef = (id: string) => doc(db(), 'slots', id);
const counterRef = () => doc(db(), 'counters', 'drives');

export type BulkPlan = {
  series: SeriesKey;
  naming: NamingSeries;
  start: number;
  count: number;
  base: DriveInput;
  serials: string[];
  slots: string[];
  /** purani drive ka apna naam (sirf ek drive register karte waqt) */
  customName?: string;
};

/**
 * Ek ya kai drives ek saath. Mark number aur serial pehle se ho to kuch bhi save nahi hota (transaction).
 * slots[i] = kis slot me rakhni hai (khaali = base.locationId).
 */
export async function createDrives(plan: BulkPlan, me: Me | null, slotIds: Set<string>): Promise<string[]> {
  if (plan.count < 1 || plan.count > 100) throw new AppError('bad_request', 'Ek baar me 1 se 100 drives bana sakte ho.');
  const marks = Array.from({ length: plan.count }, (_, i) => plan.start + i);
  const serials = marks.map((_, i) => serialKey(plan.serials[i] || ''));
  const dupSerial = serials.filter((s, i) => s && serials.indexOf(s) !== i);
  if (dupSerial.length) throw new AppError('duplicate', 'Ye serial number list me do baar hai: ' + dupSerial.join(', '));

  return runTransaction(db(), async (tx) => {
    const counter = await tx.get(counterRef());
    const lastAsset = counter.exists() ? Number(counter.data().lastAsset) || 0 : 0;
    const lastMark = counter.exists() ? Number(counter.data().lastMark) || 0 : 0;

    const markSnaps = await Promise.all(marks.map((m) => tx.get(markRef(plan.series, m))));
    const taken = markSnaps.map((s, i) => (s.exists() ? marks[i] : 0)).filter(Boolean);
    if (taken.length) throw new AppError('duplicate', 'Ye number is series me pehle se hai: ' + taken.map((m) => seriesName(plan.naming, m)).join(', ') + '. Kisi aur ne abhi register kiya ho to page dobara khol ke try karo.');

    const serialSnaps = await Promise.all(serials.map((s) => (s ? tx.get(serialRef(s)) : Promise.resolve(null))));
    const takenS = serialSnaps.map((s, i) => (s && s.exists() ? plan.serials[i] : '')).filter(Boolean);
    if (takenS.length) throw new AppError('duplicate', 'Ye serial number wali drive pehle se register me hai: ' + takenS.join(', '));

    const slotFor = marks.map((_, i) => plan.slots[i] || plan.base.locationId || '');
    const slotUsed = slotFor.filter((s) => s && slotIds.has(s));
    const dupSlot = slotUsed.filter((s, i) => slotUsed.indexOf(s) !== i);
    if (dupSlot.length) throw new AppError('duplicate', 'Ek slot me ek hi drive rakh sakte ho.');
    const slotSnaps = await Promise.all(slotUsed.map((s) => tx.get(slotRef(s))));
    if (slotSnaps.some((s) => s.exists())) throw new AppError('slot_taken', 'Chuna hua slot pehle se bhara hai.');

    const ids: string[] = [];
    const now = nowIso();
    marks.forEach((m, i) => {
      const ref = doc(collection(db(), 'drives'));
      ids.push(ref.id);
      const assetId = 'DRV-' + String(lastAsset + i + 1).padStart(4, '0');
      const displayName = (plan.count === 1 && plan.customName?.trim()) || seriesName(plan.naming, m);
      const base = { ...plan.base, series: plan.series, markNo: m, displayName, serial: (plan.serials[i] || '').trim(), locationId: slotFor[i] };
      const data = {
        ...base,
        status: base.status || 'in_store',
        assetId,
        serialKey: serials[i],
        holder: null,
        tokens: driveTokens({ ...base, assetId }),
        deletedAt: '',
        deletedBy: '',
        createdAt: now,
        createdBy: me?.uid || '',
        createdByName: me?.name || '',
        updatedAt: now,
        updatedBy: me?.uid || '',
        updatedByName: me?.name || '',
      };
      tx.set(ref, data);
      tx.set(markRef(plan.series, m), { driveId: ref.id, at: now });
      if (serials[i]) tx.set(serialRef(serials[i]), { driveId: ref.id, at: now });
      if (slotFor[i] && slotIds.has(slotFor[i])) tx.set(slotRef(slotFor[i]), { driveId: ref.id, at: now });
    });
    tx.set(counterRef(), { lastAsset: lastAsset + plan.count, lastMark: Math.max(lastMark, marks[marks.length - 1]), updatedAt: now });
    auditTx(tx, me, 'drives', 'create', ids[0], seriesName(plan.naming, marks[0]) + (marks.length > 1 ? ' – ' + seriesName(plan.naming, marks[marks.length - 1]) : ''), plan.count + ' drive(s) registered');
    return ids;
  });
}

/** Drive ki details badlo. Series / Mark / serial / slot badle to purane guard hatao, naye pe duplicate check. */
export async function updateDrive(id: string, patch: Partial<DriveInput>, me: Me | null, slotIds: Set<string>) {
  return runTransaction(db(), async (tx) => {
    const ref = doc(db(), 'drives', id);
    const snap = await tx.get(ref);
    if (!snap.exists()) throw new AppError('not-found', 'Drive nahi mili.');
    const cur = normalizeDrive(id, snap.data());
    const next = { ...cur, ...patch };
    const now = nowIso();

    const markChanged = next.markNo !== cur.markNo || next.series !== cur.series;
    let newMark: DocumentReference | null = null;
    if (markChanged) {
      if (!(next.markNo > 0)) throw new AppError('bad_request', 'Mark number 1 ya usse bada hona chahiye.');
      newMark = markRef(next.series, next.markNo);
      const s = await tx.get(newMark);
      if (s.exists() && s.data().driveId !== id) throw new AppError('duplicate', 'Ye number is series me pehle se kisi aur drive ka hai.');
    }
    const sk = serialKey(next.serial);
    let newSerial: DocumentReference | null = null;
    if (sk !== cur.serialKey && sk) {
      newSerial = serialRef(sk);
      const s = await tx.get(newSerial);
      if (s.exists() && s.data().driveId !== id) throw new AppError('duplicate', 'Is serial number wali drive pehle se hai.');
    }
    let newSlot: DocumentReference | null = null;
    if (next.locationId !== cur.locationId && slotIds.has(next.locationId)) {
      newSlot = slotRef(next.locationId);
      const s = await tx.get(newSlot);
      if (s.exists() && s.data().driveId !== id) throw new AppError('slot_taken', 'Ye slot pehle se bhara hai.');
    }
    // purana guard (v3.0 me bina series ke "43" tha) dono hatao
    const oldGuards = [markRef(cur.series, cur.markNo)];
    if (markChanged) {
      for (const g of oldGuards) tx.delete(g);
      tx.delete(doc(db(), 'driveMarks', String(cur.markNo)));
      tx.set(newMark!, { driveId: id, at: now });
    }
    if (sk !== cur.serialKey) {
      if (cur.serialKey) tx.delete(serialRef(cur.serialKey));
      if (newSerial) tx.set(newSerial, { driveId: id, at: now });
    }
    if (next.locationId !== cur.locationId) {
      if (cur.locationId && slotIds.has(cur.locationId)) tx.delete(slotRef(cur.locationId));
      if (newSlot) tx.set(newSlot, { driveId: id, at: now });
    }
    const { id: _id, ...rest } = next;
    tx.set(ref, {
      ...rest,
      serialKey: sk,
      tokens: driveTokens(next),
      updatedAt: now,
      updatedBy: me?.uid || '',
      updatedByName: me?.name || '',
    });
    auditTx(tx, me, 'drives', 'edit', id, next.displayName, Object.keys(patch).join(', '));
  });
}

export async function softDeleteDrive(d: Drive, me: Me | null) {
  if (d.status === 'issued' || d.status === 'temp_issued') throw new AppError('conflict', 'Issue hui drive delete nahi ho sakti. Pehle wapas lo.');
  await runTransaction(db(), async (tx) => {
    const ref = doc(db(), 'drives', d.id);
    tx.update(ref, { deletedAt: nowIso(), deletedBy: me?.name || '', updatedAt: nowIso(), updatedBy: me?.uid || '', updatedByName: me?.name || '' });
    auditTx(tx, me, 'drives', 'delete', d.id, d.displayName, 'Moved to recycle bin');
  });
}
export async function restoreDrive(d: Drive, me: Me | null) {
  await runTransaction(db(), async (tx) => {
    tx.update(doc(db(), 'drives', d.id), { deletedAt: '', deletedBy: '', updatedAt: nowIso(), updatedBy: me?.uid || '', updatedByName: me?.name || '' });
    auditTx(tx, me, 'drives', 'restore', d.id, d.displayName, 'Restored from recycle bin');
  });
}
/** Hamesha ke liye hatao (sirf Super Admin). History (transfers) rehti hai. */
export async function purgeDrive(d: Drive, me: Me | null, slotIds: Set<string>) {
  await runTransaction(db(), async (tx) => {
    tx.delete(doc(db(), 'drives', d.id));
    if (d.markNo) {
      tx.delete(markRef(d.series, d.markNo));
      tx.delete(doc(db(), 'driveMarks', String(d.markNo)));
    }
    if (d.serialKey) tx.delete(serialRef(d.serialKey));
    if (d.locationId && slotIds.has(d.locationId)) tx.delete(slotRef(d.locationId));
    auditTx(tx, me, 'drives', 'purge', d.id, d.displayName, 'Permanently deleted');
  });
}

/* ---------- custody: issue / return / transfer ---------- */
export type MoveInput = {
  kind: TransferKind;
  to: Party & { place?: string };
  purpose: string;
  date: string;
  expectedReturn: string;
  condition: string;
  usedGB: number | null;
  notes: string;
};

const ALLOWED: Record<TransferKind, DriveStatus[]> = {
  issue: ['in_store'],
  temp_issue: ['in_store'],
  return: ['issued', 'temp_issued', 'repair'],
  dept_transfer: ['in_store', 'issued', 'temp_issued'],
  location_transfer: ['in_store', 'issued', 'temp_issued', 'repair', 'damaged'],
  repair: ['in_store', 'issued', 'temp_issued', 'damaged'],
  damaged: ['in_store', 'issued', 'temp_issued', 'repair'],
  lost: ['in_store', 'issued', 'temp_issued', 'repair', 'damaged'],
  retire: ['in_store', 'repair', 'damaged', 'lost'],
  restore: ['repair', 'damaged', 'lost', 'retired'],
};

export function allowedKinds(s: DriveStatus): TransferKind[] {
  return (Object.keys(ALLOWED) as TransferKind[]).filter((k) => ALLOWED[k].includes(s));
}

/**
 * Drive ki custody badlo — transaction me: taaza drive padho, halat check karo, drive + transfer record + audit ek saath likho.
 * Ek drive ek waqt me sirf ek bande ke paas ho sakti hai.
 */
export async function moveDrive(driveId: string, m: MoveInput, me: Me | null, slotIds: Set<string>): Promise<string> {
  return runTransaction(db(), async (tx) => {
    const ref = doc(db(), 'drives', driveId);
    const snap = await tx.get(ref);
    if (!snap.exists()) throw new AppError('not-found', 'Drive nahi mili.');
    const d = normalizeDrive(driveId, snap.data());
    if (d.deletedAt) throw new AppError('conflict', 'Ye drive recycle bin me hai.');
    if (!ALLOWED[m.kind].includes(d.status)) {
      const who = d.holder?.name ? ' (abhi ' + d.holder.name + ' ke paas)' : '';
      throw new AppError('conflict', 'Is halat me ye kaam nahi ho sakta: drive abhi "' + d.status.replace('_', ' ') + '" hai' + who + '.');
    }
    if ((m.kind === 'issue' || m.kind === 'temp_issue') && !m.to.name.trim()) throw new AppError('bad_request', 'Kisko de rahe ho, naam likho.');
    if (m.kind === 'temp_issue' && !m.expectedReturn) throw new AppError('bad_request', 'Temporary issue me wapsi ki tareekh zaroori hai.');
    if (m.kind === 'dept_transfer' && !m.to.dept.trim()) throw new AppError('bad_request', 'Naya department likho.');
    if (m.kind === 'location_transfer' && !m.to.locationId && !(m.to.place || '').trim()) throw new AppError('bad_request', 'Nayi jagah likho ya chuno.');

    let slotNew: DocumentReference | null = null;
    if (m.kind === 'location_transfer' && slotIds.has(m.to.locationId) && m.to.locationId !== d.locationId) {
      slotNew = slotRef(m.to.locationId);
      const s = await tx.get(slotNew);
      if (s.exists() && s.data().driveId !== driveId) throw new AppError('slot_taken', 'Ye slot pehle se bhara hai.');
    }
    let openRef: DocumentReference | null = null;
    if (m.kind === 'return' && d.holder?.transferId) {
      openRef = doc(db(), 'driveTransfers', d.holder.transferId);
      const os = await tx.get(openRef);
      if (!os.exists()) openRef = null;
    }

    const now = nowIso();
    const tRef = doc(collection(db(), 'driveTransfers'));
    const from: Party = { name: d.holder?.name || (d.status === 'in_store' ? 'Store' : ''), dept: d.holder?.dept || d.dept, locationId: d.locationId, place: d.place };
    const newPlace = (m.to.place || '').trim();
    const to: Party = {
      name: m.kind === 'return' || m.kind === 'restore' ? 'Store' : m.to.name.trim(),
      dept: m.to.dept.trim() || (m.kind === 'location_transfer' ? d.dept : ''),
      locationId: m.kind === 'location_transfer' ? m.to.locationId : d.locationId,
      place: m.kind === 'location_transfer' || ((m.kind === 'return' || m.kind === 'restore') && newPlace) ? newPlace || d.place : d.place,
    };

    let status: DriveStatus = d.status;
    let holder = d.holder;
    let dept = d.dept;
    let locationId = d.locationId;
    const place = to.place || '';
    const holderNew = (temporary: boolean) => ({
      name: to.name,
      dept: to.dept,
      since: m.date,
      expectedReturn: m.expectedReturn,
      transferId: tRef.id,
      temporary,
    });
    switch (m.kind) {
      case 'issue':
        status = 'issued';
        holder = holderNew(false);
        if (to.dept) dept = to.dept;
        break;
      case 'temp_issue':
        status = 'temp_issued';
        holder = holderNew(true);
        break;
      case 'return':
      case 'restore':
        status = 'in_store';
        holder = null;
        break;
      case 'dept_transfer':
        dept = to.dept;
        if (holder) holder = { ...holderNew(holder.temporary), name: to.name || holder.name, expectedReturn: m.expectedReturn || holder.expectedReturn };
        break;
      case 'location_transfer':
        locationId = to.locationId;
        break;
      case 'repair':
        status = 'repair';
        holder = { ...holderNew(false), name: to.name || 'Repair', dept: to.dept };
        break;
      case 'damaged':
        status = 'damaged';
        holder = null;
        break;
      case 'lost':
        status = 'lost';
        holder = null;
        break;
      case 'retire':
        status = 'retired';
        holder = null;
        break;
    }

    tx.set(tRef, {
      driveId,
      assetId: d.assetId,
      mark: d.displayName,
      kind: m.kind,
      from,
      to,
      purpose: m.purpose.trim(),
      date: m.date,
      expectedReturn: m.expectedReturn,
      actualReturn: m.kind === 'return' ? m.date : '',
      condition: m.condition,
      usedGB: m.usedGB ?? d.usedGB,
      confirmed: false,
      confirmedBy: '',
      confirmedAt: '',
      notes: m.notes.trim(),
      at: now,
      by: me?.uid || '',
      byName: me?.name || '',
    });
    if (openRef) tx.update(openRef, { actualReturn: m.date });

    const patch: Record<string, unknown> = {
      status,
      holder,
      dept,
      locationId,
      place,
      updatedAt: now,
      updatedBy: me?.uid || '',
      updatedByName: me?.name || '',
    };
    if (m.usedGB !== null && m.usedGB >= 0) patch.usedGB = m.usedGB;
    if (m.condition) patch.condition = m.condition;
    tx.update(ref, patch);
    if (locationId !== d.locationId) {
      if (d.locationId && slotIds.has(d.locationId)) tx.delete(slotRef(d.locationId));
      if (slotNew) tx.set(slotNew, { driveId, at: now });
    }
    auditTx(tx, me, 'drives', 'transfer', driveId, d.displayName, m.kind + (to.name ? ' → ' + to.name : '') + (to.dept ? ' / ' + to.dept : ''));
    return tRef.id;
  });
}

export async function confirmTransfer(t: Transfer, me: Me | null) {
  await setDoc(doc(db(), 'driveTransfers', t.id), { confirmed: true, confirmedBy: me?.name || '', confirmedAt: nowIso() }, { merge: true });
  await audit(me, 'drives', 'confirm', t.driveId, t.mark, 'Receipt confirmed: ' + t.kind);
}

/* ---------- locations ---------- */
export async function saveLoc(l: Omit<Loc, 'id' | 'createdAt' | 'deletedAt'> & { id?: string }, me: Me | null): Promise<string> {
  const ref = l.id ? doc(db(), 'locations', l.id) : doc(collection(db(), 'locations'));
  const { id: _id, ...rest } = l;
  await setDoc(ref, { ...rest, deletedAt: '', ...(l.id ? {} : { createdAt: nowIso() }), updatedAt: nowIso() }, { merge: true });
  await audit(me, 'locations', l.id ? 'edit' : 'create', ref.id, l.name, l.kind);
  return ref.id;
}

/** Ek shelf me kai slot ek saath (S1, S2…). */
export async function createSlots(parent: Loc, count: number, start: number, me: Me | null) {
  if (count < 1 || count > 200) throw new AppError('bad_request', '1 se 200 slot ek baar me.');
  const b = writeBatch(db());
  for (let i = 0; i < count; i++) {
    b.set(doc(collection(db(), 'locations')), {
      name: 'S' + (start + i),
      kind: 'slot',
      parentId: parent.id,
      order: start + i,
      note: '',
      deletedAt: '',
      createdAt: nowIso(),
    });
  }
  await b.commit();
  await audit(me, 'locations', 'create', parent.id, parent.name, count + ' slots');
}

export async function deleteLoc(l: Loc, children: number, occupied: boolean, me: Me | null) {
  if (children > 0) throw new AppError('conflict', 'Pehle andar ki locations hatao.');
  if (occupied) throw new AppError('conflict', 'Is location me drive rakhi hai. Pehle drive kahin aur bhejo.');
  await deleteDoc(doc(db(), 'locations', l.id));
  await audit(me, 'locations', 'delete', l.id, l.name, l.kind);
}

/* ---------- catalogue ---------- */
export type CatalogInput = Omit<CatalogEntry, 'id' | 'tokens' | 'deletedAt' | 'createdAt' | 'createdBy' | 'createdByName' | 'updatedAt' | 'updatedByName'>;

const catTokens = (c: CatalogInput) =>
  tokens(c.project, c.title, c.episode, c.eventName, c.year, c.dept, c.category, c.fileType, c.folderPath, c.owner, c.description, ...c.tags);

export async function saveCatalog(c: CatalogInput, me: Me | null, id?: string): Promise<string> {
  const ref = id ? doc(db(), 'catalog', id) : doc(collection(db(), 'catalog'));
  const now = nowIso();
  await setDoc(
    ref,
    {
      ...c,
      tokens: catTokens(c),
      deletedAt: '',
      ...(id ? {} : { createdAt: now, createdBy: me?.uid || '', createdByName: me?.name || '' }),
      updatedAt: now,
      updatedByName: me?.name || '',
    },
    { merge: true },
  );
  await audit(me, 'catalog', id ? 'edit' : 'create', ref.id, c.title || c.project, c.folderPath);
  return ref.id;
}
export async function setCatalogDeleted(c: CatalogEntry, del: boolean, me: Me | null) {
  await setDoc(doc(db(), 'catalog', c.id), { deletedAt: del ? nowIso() : '', updatedByName: me?.name || '' }, { merge: true });
  await audit(me, 'catalog', del ? 'delete' : 'restore', c.id, c.title || c.project, '');
}
export async function purgeCatalog(c: CatalogEntry, me: Me | null) {
  await deleteDoc(doc(db(), 'catalog', c.id));
  await audit(me, 'catalog', 'purge', c.id, c.title || c.project, 'Permanently deleted');
}

/* ---------- backups ---------- */
export type BackupInput = Pick<Backup, 'catalogId' | 'sourceDriveId' | 'copyDriveId' | 'copyPath' | 'notes'>;

export async function createBackup(b: BackupInput, me: Me | null): Promise<string> {
  if (b.copyDriveId === b.sourceDriveId) throw new AppError('bad_request', 'Backup copy usi drive pe nahi ho sakti jisme original data hai.');
  const ref = doc(collection(db(), 'backups'));
  const now = nowIso();
  await setDoc(ref, {
    ...b,
    status: 'assigned',
    method: '',
    sourceHash: '',
    copyHash: '',
    sourceFiles: 0,
    copyFiles: 0,
    completedAt: '',
    verifiedAt: '',
    verifiedBy: '',
    history: [{ at: now, by: me?.name || '', what: 'Backup assigned' }],
    deletedAt: '',
    createdAt: now,
    createdByName: me?.name || '',
  });
  await audit(me, 'backups', 'create', ref.id, b.copyPath || b.catalogId, 'Backup assigned');
  return ref.id;
}

export async function updateBackup(b: Backup, patch: Partial<Backup>, what: string, me: Me | null) {
  const { id: _id, ...rest } = { ...b, ...patch };
  await setDoc(doc(db(), 'backups', b.id), { ...rest, history: [...b.history, { at: nowIso(), by: me?.name || '', what }].slice(-40) });
  await audit(me, 'backups', 'edit', b.id, b.copyPath || b.catalogId, what);
}

/* ---------- file index (scan import) ---------- */
export type ParsedFile = { path: string; size: number; modified: string };

export async function readDriveIndex(driveId: string): Promise<FileChunk[]> {
  const s = await getDocs(query(collection(db(), 'fileIndex'), where('driveId', '==', driveId)));
  return s.docs.map((d) => normalizeChunk(d.id, d.data())).sort((a, b) => a.folder.localeCompare(b.folder));
}

export async function readScans(driveId: string): Promise<Scan[]> {
  const s = await getDocs(query(collection(db(), 'scans'), where('driveId', '==', driveId)));
  return s.docs.map((d) => normalizeScan(d.id, d.data())).sort((a, b) => b.at.localeCompare(a.at));
}

/** Ek shabd se poore file index me dhundho (Firestore index wali query, poora data nahi mangwate). */
export async function searchIndex(word: string, max = 40): Promise<FileChunk[]> {
  const w = word.toLowerCase().trim();
  if (w.length < 2) return [];
  const s = await getDocs(query(collection(db(), 'fileIndex'), where('tokens', 'array-contains', w), qlimit(max)));
  return s.docs.map((d) => normalizeChunk(d.id, d.data()));
}

const CHUNK = 400;

/**
 * Scan ki CSV list ko file index me daalo: purana index hatao, folder ke hisaab se chhote tukde (har doc max 400 files)
 * banao, scan history likho. Sirf metadata — koi file upload nahi hoti.
 */
export async function importScan(
  drive: Drive,
  files: ParsedFile[],
  opts: { capacityGB: number | null; freeGB: number | null; note: string },
  me: Me | null,
  progress: (msg: string) => void,
): Promise<Scan> {
  const old = await readDriveIndex(drive.id);
  const oldPaths = new Set<string>();
  for (const c of old) for (const f of c.files) oldPaths.add((c.folder ? c.folder + '/' : '') + f.n);

  const byFolder = new Map<string, ParsedFile[]>();
  for (const f of files) {
    const p = f.path.replace(/\\/g, '/');
    const i = p.lastIndexOf('/');
    const folder = i > 0 ? p.slice(0, i) : '';
    const arr = byFolder.get(folder) || [];
    arr.push({ ...f, path: p });
    byFolder.set(folder, arr);
  }
  const newPaths = new Set(files.map((f) => f.path.replace(/\\/g, '/')));
  let added = 0;
  for (const p of newPaths) if (!oldPaths.has(p)) added++;
  let removed = 0;
  for (const p of oldPaths) if (!newPaths.has(p)) removed++;

  const scanRef = doc(collection(db(), 'scans'));
  const docs: Record<string, unknown>[] = [];
  for (const [folder, list] of byFolder) {
    for (let i = 0; i < list.length; i += CHUNK) {
      const part = list.slice(i, i + CHUNK);
      const names = part.map((f) => f.path.slice(folder ? folder.length + 1 : 0));
      docs.push({
        driveId: drive.id,
        scanId: scanRef.id,
        folder,
        files: part.map((f, k) => ({ n: names[k], s: f.size, m: f.modified })),
        count: part.length,
        bytes: part.reduce((s, f) => s + f.size, 0),
        tokens: tokens(drive.displayName, folder, ...names.map((n) => n.replace(/\.[^.]+$/, ''))).slice(0, 400),
      });
    }
  }

  // Purana index hatao (batch me 400-400)
  for (let i = 0; i < old.length; i += 400) {
    progress('Purana index hata rahe hai… ' + Math.min(i + 400, old.length) + '/' + old.length);
    const b = writeBatch(db());
    for (const c of old.slice(i, i + 400)) b.delete(doc(db(), 'fileIndex', c.id));
    await b.commit();
  }
  for (let i = 0; i < docs.length; i += 400) {
    progress('Naya index likh rahe hai… ' + Math.min(i + 400, docs.length) + '/' + docs.length);
    const b = writeBatch(db());
    for (const d of docs.slice(i, i + 400)) b.set(doc(collection(db(), 'fileIndex')), d);
    await b.commit();
  }

  const totalBytes = files.reduce((s, f) => s + f.size, 0);
  const now = nowIso();
  const scan = {
    driveId: drive.id,
    source: 'csv' as const,
    at: now,
    by: me?.uid || '',
    byName: me?.name || '',
    files: files.length,
    folders: byFolder.size,
    bytes: totalBytes,
    added,
    removed,
    capacityGB: opts.capacityGB ?? 0,
    freeGB: opts.freeGB ?? 0,
    note: opts.note,
  };
  await setDoc(scanRef, scan);
  const patch: Record<string, unknown> = { lastScanAt: now, updatedAt: now, updatedBy: me?.uid || '', updatedByName: me?.name || '' };
  if (opts.capacityGB !== null && opts.capacityGB > 0) patch.capacityGB = opts.capacityGB;
  if (opts.freeGB !== null && opts.capacityGB !== null && opts.capacityGB > 0) patch.usedGB = Math.max(0, Math.round((opts.capacityGB - opts.freeGB) * 100) / 100);
  await setDoc(doc(db(), 'drives', drive.id), patch, { merge: true });
  await audit(me, 'catalog', 'scan', drive.id, drive.displayName, files.length + ' files, +' + added + ' / -' + removed);
  return { id: scanRef.id, ...scan };
}

export async function getDriveDoc(id: string): Promise<Drive | null> {
  const s = await getDoc(doc(db(), 'drives', id));
  return s.exists() ? normalizeDrive(s.id, s.data()) : null;
}

/* ---------- naming series ---------- */
export function subscribeNaming(n: (x: Record<SeriesKey, NamingSeries>) => void): Unsub {
  return onSnapshot(
    doc(db(), 'config', 'naming'),
    (s) => n(normalizeNaming(s.exists() ? s.data() : null)),
    () => n(normalizeNaming(null)),
  );
}
export async function saveNaming(series: Record<SeriesKey, NamingSeries>, me: Me | null) {
  await setDoc(doc(db(), 'config', 'naming'), { series, updatedAt: nowIso(), updatedBy: me?.email || '' });
  await audit(me, 'drives', 'edit', 'config/naming', 'Naming series', Object.entries(series).map(([k, v]) => k + '=' + v.prefix + '#' + v.suffix).join(', '));
}

/* ---------- profile (dikhne wala naam) ---------- */
export function subscribeProfile(uid: string, n: (p: { displayName: string } | null) => void): Unsub {
  return onSnapshot(
    doc(db(), 'users', uid),
    (s) => n(s.exists() ? { displayName: String(s.data().displayName || '') } : null),
    () => n(null),
  );
}
export async function saveProfile(uid: string, displayName: string) {
  await setDoc(doc(db(), 'users', uid), { displayName: displayName.trim().slice(0, 60), email: currentEmail(), updatedAt: nowIso() }, { merge: true });
}

/* ---------- persons / departments ---------- */
export const subscribePersons = (n: (r: Person[]) => void, e: (c: string) => void) => sub('persons', normalizePerson, n, e);
export const subscribeDepts = (n: (r: Department[]) => void, e: (c: string) => void) => sub('departments', normalizeDept, n, e);

export async function savePerson(p: Omit<Person, 'id' | 'createdAt' | 'updatedAt'>, me: Me | null, id?: string): Promise<string> {
  const ref = id ? doc(db(), 'persons', id) : doc(collection(db(), 'persons'));
  await setDoc(
    ref,
    { ...p, key: nameKey(p.name), aliases: p.aliases.map((a) => a.trim()).filter(Boolean), ...(id ? {} : { createdAt: nowIso() }), updatedAt: nowIso() },
    { merge: true },
  );
  await audit(me, 'persons', id ? 'edit' : 'create', ref.id, p.name, p.depts.join(', '));
  return ref.id;
}
export async function saveDept(d: Omit<Department, 'id' | 'createdAt'>, me: Me | null, id?: string): Promise<string> {
  const ref = id ? doc(db(), 'departments', id) : doc(collection(db(), 'departments'));
  await setDoc(ref, { ...d, ...(id ? {} : { createdAt: nowIso() }), updatedAt: nowIso() }, { merge: true });
  await audit(me, 'persons', id ? 'edit' : 'create', ref.id, d.name, 'department');
  return ref.id;
}

/* ---------- events ---------- */
export const subscribeEvents = (n: (r: AshramEvent[]) => void, e: (c: string) => void) => sub('events', normalizeEvent, n, e);
export type EventInput = Omit<AshramEvent, 'id' | 'eventNo' | 'tokens' | 'deletedAt' | 'createdAt' | 'createdByName' | 'updatedAt' | 'updatedByName'>;

export async function saveEvent(ev: EventInput, me: Me | null, id?: string): Promise<string> {
  const now = nowIso();
  const tk = tokens(ev.title, ev.type, ev.date, ev.location, ev.description, ev.project, ev.episode, ev.submittedBy, ev.receivedBy, ev.responsible, ...ev.participants, ...ev.mainPersons, ...ev.recordingTeam, ...ev.tags);
  if (id) {
    await setDoc(doc(db(), 'events', id), { ...ev, tokens: tk, updatedAt: now, updatedByName: me?.name || '' }, { merge: true });
    await audit(me, 'events', 'edit', id, ev.title, ev.type + ' ' + ev.date);
    return id;
  }
  // Event number: EVT-0001 (transaction se, dobara na bane)
  return runTransaction(db(), async (tx) => {
    const cref = doc(db(), 'counters', 'events');
    const c = await tx.get(cref);
    const n = (c.exists() ? Number(c.data().last) || 0 : 0) + 1;
    const ref = doc(collection(db(), 'events'));
    tx.set(cref, { last: n, updatedAt: now });
    tx.set(ref, { ...ev, eventNo: 'EVT-' + String(n).padStart(4, '0'), tokens: tk, deletedAt: '', createdAt: now, createdByName: me?.name || '', updatedAt: now, updatedByName: me?.name || '' });
    auditTx(tx, me, 'events', 'create', ref.id, ev.title, ev.type + ' ' + ev.date);
    return ref.id;
  });
}
export async function setEventDeleted(ev: AshramEvent, del: boolean, me: Me | null) {
  await setDoc(doc(db(), 'events', ev.id), { deletedAt: del ? nowIso() : '', updatedByName: me?.name || '' }, { merge: true });
  await audit(me, 'events', del ? 'delete' : 'restore', ev.id, ev.title, '');
}

/* ---------- saved reports (har user ke apne) ---------- */
export type SavedReport = { id: string; uid: string; name: string; spec: Record<string, unknown>; updatedAt: string };
export function subscribeSavedReports(uid: string, n: (r: SavedReport[]) => void): Unsub {
  return onSnapshot(
    query(collection(db(), 'savedReports'), where('uid', '==', uid)),
    (s) => n(s.docs.map((d) => ({ id: d.id, uid, name: String(d.data().name || ''), spec: (d.data().spec || {}) as Record<string, unknown>, updatedAt: String(d.data().updatedAt || '') }))),
    () => n([]),
  );
}
export async function saveReport(uid: string, name: string, spec: Record<string, unknown>, id?: string) {
  const ref = id ? doc(db(), 'savedReports', id) : doc(collection(db(), 'savedReports'));
  await setDoc(ref, { uid, name: name.slice(0, 120), spec: JSON.parse(JSON.stringify(spec)), updatedAt: nowIso() });
  return ref.id;
}
export async function deleteReport(id: string) {
  await deleteDoc(doc(db(), 'savedReports', id));
}
