// Roles aur permissions. Yahi matrix Firestore Rules (firestore.rules) aur server APIs me bhi lagti hai.
// Frontend sirf button chhupata hai — asli rok Rules aur server pe hai.

export const ROLES = ['superadmin', 'admin', 'store', 'purchase', 'accountant', 'data', 'editor', 'viewer'] as const;
export type Role = (typeof ROLES)[number];

export const ROLE_LABEL: Record<Role, string> = {
  superadmin: 'Super Admin',
  admin: 'Admin',
  store: 'Store Manager',
  purchase: 'Purchase Manager',
  accountant: 'Accountant',
  data: 'Data Manager',
  editor: 'Editor',
  viewer: 'Viewer',
};

export const ROLE_HINT: Record<Role, string> = {
  superadmin: 'Sab kuch, roles bhi badal sakta hai',
  admin: 'Sab kuch, roles sirf dekh sakta hai',
  store: 'Stock, Hard Disk, issue/return, location, stickers',
  purchase: 'Purchase, demand aur approval',
  accountant: 'Hisaab, payments aur reports',
  data: 'Data catalogue, backup, drive scan',
  editor: 'Catalogue dekhna/likhna, drives dekhna',
  viewer: 'Sirf dekh sakta hai',
};

export const MODULES = [
  'inventory',
  'demands',
  'persons',
  'drives',
  'locations',
  'catalog',
  'events',
  'backups',
  'stickers',
  'reports',
  'audit',
  'roles',
] as const;
export type Module = (typeof MODULES)[number];

export const MODULE_LABEL: Record<Module, string> = {
  inventory: 'Inventory, stock, purchases, bills',
  demands: 'Demand list',
  persons: 'Persons & departments',
  drives: 'Hard Disk / SSD',
  locations: 'Location & racks',
  catalog: 'Data catalogue & file index',
  events: 'Events (Panchayat, Satsang…) & participants',
  backups: 'Backups',
  stickers: 'QR / barcode stickers',
  reports: 'Reports & export',
  audit: 'Audit log',
  roles: 'Roles & permissions',
};

export const ACTIONS = ['view', 'create', 'edit', 'delete', 'approve', 'transfer', 'export', 'ai'] as const;
export type Action = (typeof ACTIONS)[number];

export const ACTION_LABEL: Record<Action, string> = {
  view: 'View',
  create: 'Create',
  edit: 'Edit',
  delete: 'Delete',
  approve: 'Approve',
  transfer: 'Transfer',
  export: 'Export',
  ai: 'AI',
};

export type PermMap = Record<string, Record<string, string[]>>;

const ALL: Action[] = [...ACTIONS];
const V: Action[] = ['view'];
const VE: Action[] = ['view', 'export'];

function row(m: Partial<Record<Module, Action[]>>, fallback: Action[] = []): Record<Module, Action[]> {
  const out = {} as Record<Module, Action[]>;
  for (const k of MODULES) out[k] = m[k] ?? fallback;
  return out;
}

/** Shuruaati (default) matrix. Super Admin Roles page se badal sakta hai. */
export const DEFAULT_PERMS: Record<Role, Record<Module, Action[]>> = {
  superadmin: row({}, ALL),
  admin: row({ roles: V }, ALL),
  store: row({
    inventory: ['view', 'create', 'edit', 'transfer', 'export'],
    demands: ['view', 'create', 'edit'],
    persons: ['view', 'create', 'edit', 'export'],
    drives: ['view', 'create', 'edit', 'transfer', 'export'],
    locations: ['view', 'create', 'edit', 'delete'],
    catalog: VE,
    backups: V,
    stickers: ['view', 'create', 'export'],
    reports: VE,
  }),
  purchase: row({
    inventory: ['view', 'create', 'edit', 'export', 'ai'],
    demands: ['view', 'create', 'edit', 'delete', 'approve', 'export'],
    persons: V,
    drives: V,
    locations: V,
    reports: VE,
  }),
  accountant: row({
    inventory: ['view', 'edit', 'export', 'ai'],
    demands: V,
    persons: VE,
    drives: V,
    reports: ['view', 'export', 'ai'],
  }),
  data: row({
    inventory: V,
    drives: ['view', 'edit', 'transfer', 'export'],
    locations: V,
    catalog: ['view', 'create', 'edit', 'delete', 'export', 'ai'],
    events: ['view', 'create', 'edit', 'delete', 'export'],
    persons: VE,
    backups: ['view', 'create', 'edit', 'delete', 'approve', 'export'],
    stickers: ['view', 'create'],
    reports: VE,
  }),
  editor: row({
    inventory: V,
    drives: V,
    locations: V,
    catalog: ['view', 'create', 'edit'],
    events: ['view', 'create', 'edit'],
    persons: V,
    backups: V,
  }),
  viewer: row({
    inventory: V,
    demands: V,
    drives: V,
    locations: V,
    catalog: V,
    persons: V,
    backups: V,
    reports: V,
  }),
};

export function defaultPermMap(): PermMap {
  const out: PermMap = {};
  for (const r of ROLES) {
    out[r] = {};
    for (const m of MODULES) out[r][m] = [...DEFAULT_PERMS[r][m]];
  }
  return out;
}

export type Access = {
  /** owner = Firestore rules me likha email */
  isOwner: boolean;
  role: Role;
  /** perms ka document me na hona = purana (legacy) tareeka: har member sab kar sakta hai */
  perms: PermMap | null;
};

export const asRole = (r: unknown): Role => (ROLES.includes(r as Role) ? (r as Role) : 'admin');

export function can(a: Access | null, mod: Module, act: Action): boolean {
  if (!a) return false;
  if (a.isOwner || a.role === 'superadmin') return true;
  if (!a.perms) return mod === 'roles' ? act === 'view' : true;
  const list = a.perms[a.role]?.[mod];
  return Array.isArray(list) && list.includes(act);
}
