// SIRF SERVER: login karne wala register ka member (owner ya team) hai ya nahi, aur uske role ko ye kaam karne ki ijaazat hai ya nahi.
// User ke apne login token se Firestore ka "config/access" padhte hai. Firestore rules wahi hai jo app ke,
// isliye sirf owner/team ko hi document milta hai (document na ho tab bhi owner ko 404 milta hai, jo theek hai).
// Koi service account / secret key frontend me nahi jaati.

import { can, asRole, type Action, type Module, type PermMap } from '../perm';

export type Member = 'yes' | 'no' | 'error';

export function bearer(req: Request): string | null {
  const m = /^Bearer\s+(\S+)$/i.exec(req.headers.get('authorization') || '');
  return m ? m[1] : null;
}

type FsValue = {
  stringValue?: string;
  arrayValue?: { values?: FsValue[] };
  mapValue?: { fields?: Record<string, FsValue> };
};

function arr(v: FsValue | undefined): string[] {
  return (v?.arrayValue?.values || []).map((x) => x.stringValue || '').filter(Boolean);
}

function emailFromToken(token: string): string {
  try {
    const p = token.split('.')[1];
    const json = JSON.parse(Buffer.from(p.replace(/-/g, '+').replace(/_/g, '/'), 'base64').toString('utf8'));
    return typeof json.email === 'string' ? json.email.toLowerCase() : '';
  } catch {
    return '';
  }
}

async function readAccess(token: string): Promise<{ status: Member; doc: Record<string, FsValue> | null }> {
  const projectId = process.env.NEXT_PUBLIC_FIREBASE_PROJECT_ID;
  if (!projectId) return { status: 'error', doc: null };
  const url = 'https://firestore.googleapis.com/v1/projects/' + encodeURIComponent(projectId) + '/databases/(default)/documents/config/access';
  try {
    const r = await fetch(url, { headers: { authorization: 'Bearer ' + token }, cache: 'no-store' });
    if (r.status === 404) return { status: 'yes', doc: null };
    if (r.status === 200) {
      const j = (await r.json()) as { fields?: Record<string, FsValue> };
      return { status: 'yes', doc: j.fields || {} };
    }
    if (r.status === 401 || r.status === 403) return { status: 'no', doc: null };
    return { status: 'error', doc: null };
  } catch {
    return { status: 'error', doc: null };
  }
}

export async function memberCheck(token: string): Promise<Member> {
  return (await readAccess(token)).status;
}

/** Member + role permission (wahi matrix jo Firestore rules me hai). */
export async function permCheck(token: string, mod: Module, act: Action): Promise<Member> {
  const { status, doc } = await readAccess(token);
  if (status !== 'yes') return status;
  if (!doc) return 'yes'; // document hi nahi = sirf owner padh sakta hai
  const email = emailFromToken(token);
  const emails = arr(doc.emails).map((e) => e.toLowerCase());
  const ownerEnv = (process.env.NEXT_PUBLIC_OWNER_EMAIL || '').trim().toLowerCase();
  const isOwner = !emails.includes(email) || (!!ownerEnv && ownerEnv === email);
  const roleRaw = doc.roles?.mapValue?.fields?.[email]?.stringValue;
  let perms: PermMap | null = null;
  const pf = doc.perms?.mapValue?.fields;
  if (pf) {
    perms = {};
    for (const [r, v] of Object.entries(pf)) {
      perms[r] = {};
      for (const [m, a] of Object.entries(v.mapValue?.fields || {})) perms[r][m] = arr(a);
    }
  }
  return can({ isOwner, role: isOwner ? 'superadmin' : asRole(roleRaw), perms }, mod, act) ? 'yes' : 'no';
}

/* ---------- rate limit (har server instance me, best-effort) ---------- */
const hits = new Map<string, number[]>();
export function rateLimited(key: string, max: number, windowMs: number): boolean {
  const now = Date.now();
  const list = (hits.get(key) || []).filter((t) => now - t < windowMs);
  list.push(now);
  hits.set(key, list);
  if (hits.size > 5000) for (const [k, v] of hits) if (!v.length || now - v[v.length - 1] > windowMs) hits.delete(k);
  return list.length > max;
}
export function clientKey(req: Request, token: string): string {
  return (emailFromToken(token) || 'anon') + '|' + (req.headers.get('x-forwarded-for') || '').split(',')[0].trim();
}

export function json(body: unknown, status = 200): Response {
  return Response.json(body, { status, headers: { 'cache-control': 'no-store' } });
}
