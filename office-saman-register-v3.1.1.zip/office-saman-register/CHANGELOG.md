# Changelog

## 3.1.0 — Ashram workflow: Persons, Events, Data Manager, Report Builder, Aurora design

### Aapki boli hui baatein
- **"Good morning / evening" hata diya.** Dashboard ka title ab sirf "Dashboard".
- **Naam "Amit"**: owner ka dikhne wala naam default "Amit" (`NEXT_PUBLIC_ADMIN_NAME` se badal sakte ho). Har user Settings → Profile se apna naam rakh sakta hai. Login (Google account) aur permissions naam se nahi, account se chalti hai.
- **Persons** (naya): har bande ka profile — kab kya diya, kitna, kitna wapas, abhi kitna paas (2+3+2 keyboard diye, 3 wapas = 4 abhi). "As of date" se kisi purani tareekh ko kiske paas kya tha. Date-wise history me running total. Uske paas ki drives, drive history, jis data ki zimmedari hai, jin events me tha. Print (designer) + Excel. Aliases ("Amit ji", "amit") ek hi bande me judte hai.
- **Departments** (naya): har department ke members, items (diya / wapas / abhi), drives, data. Aliases ("Live", "Live Setup").
- **Issue form** me ab **Location** aur **Purpose** bhi (alag-alag search / report hote hai).
- **Return form** me **"Kisne wapas kiya"** — har bande ka sahi hisaab. Purani wapsi bina naam ki: agar item sirf ek bande ko diya tha to usi ke hisaab me (old entry likha aata hai), warna alag se bataya jata hai — chupaya nahi jata.
- **Ashram wali simple jagah**: drive ki "Jagah" free text (Main Media Office, Delhi Office, Almari 2…). Rack / shelf / slot ab optional (Admin → Racks). Har jagah "With Amit (Live Department)" / "Outside for repair" / "Main Media Office" jaisa ek line me.
- **Alag Digital Data Manager dashboard** (`/data`): HDD / SSD, capacity, used / free, khaali, available, logo ke paas, overdue, almost full / full, damaged / lost / repair, never scanned, data records, single copy — aur bande-wise, department-wise, jagah-wise, category-wise storage. Aakhri scan ki tareekh dikhti hai; haath ke figure ko "verified" nahi kaha jata.
- **Auto naam (naming series)**: HDD, SSD/NVMe, Pen drive, Memory card — har series ka apna prefix / suffix / digits / start (Settings → Naming series). Jaise SSD start 80 → nayi 4 SSD = SSD Mark 80, 81, 82, 83. Same series me number dobara nahi ban sakta (transaction + guard). Purani drive ka apna naam bhi rakh sakte ho.
- **Register karte hi QR**: sab nayi drives ke QR turant dikhte hai (animation ke saath) + "Print stickers". QR asset ID se juda hai — naam / holder / jagah badalne par sticker dobara nahi chhapna. Scan → login → drive page, jisme upar hi "Is drive me data" dikhta hai.
- **Events** (naya): Panchayat, Satsang, Samagam, Interview, Meeting, Live Broadcast… — EVT-0001 number, tareekh, time, jagah, description, kaun-kaun aaye the, main persons, recording team, data kisne diya / liya, zimmedar, project / episode, tags, published links, confidential. Event se data (drive + folder) jodo. Naam se purane events dhoondho. Duplicate event warning. Print.
- **Report Builder** (naya, `/reports`): 9 dataset — item transactions, person-wise holdings (as-of date), purchases, stock, drives, drive transfers, data catalogue, events, backups. Filters: tareekh, person, department, jagah, item, category, status, drive, event, kuch bhi. Column chuno + order, group by + subtotal, total, sort. Saved reports (har user ke apne). Print / PDF / Excel (.xlsx) / CSV.
- **Print Designer** (naya): A3 / A4 / A5 / A6 / Letter / Legal / custom, portrait / landscape, margin, title / heading / first column / baaki text ka alag font size (8–72 pt), normal / medium / bold / extra bold, row spacing, line height, borders, stripes, checkbox column, sign ki jagah, footer, page number, copies, rang, live preview. Templates: Standard, Landscape, Large bold shopping list, Compact, A5 slip. Hindi sahi chhapti hai.
- **Cash Note Calculator** (`/cash`): ₹500 × 60 + ₹200 × 20… notes / coins alag, total animation, bade number box, Enter se agla, print statement (diya / liya / purpose).

### Design — Aurora Workspace
- Naye rang: Aurora (#7256E8 → #4F7BEA), Midnight dark (#0B1020, #9D85FF, #38BDF8), Ocean, Emerald Mint, Royal Purple, Minimal White. System default mode bhi.
- Gradient buttons, frosted sidebar / search / menus, halka animated aurora background (Settings se band kar sakte ho; reduced-motion pe ruk jata hai), dot texture.
- Density: compact / comfortable / spacious.
- Bento grid (alag size ke cards) Data dashboard pe.
- Sidebar groups: Overview, Inventory, Persons & Departments, Digital Data Manager, Accounts, Admin.
- Global search me ab Persons (holding ke saath) aur Events (participants se bhi) aur items me jagah / purpose / bande.

### Security / data
- Naye Firestore rules: `persons`, `departments`, `events`, `users` (apna naam), `savedReports` (sirf apne), `config/naming`, `counters/events`; drive custody me `place`.
- Naye permission modules: **Persons & departments**, **Events** (Viewer ko default me events nahi dikhte — Panchayat data gopniya).
- Mark guard ab series ke hisaab se (`driveMarks/SSD-80`).

### Abhi agle phase me
Bill Centre (ek bill → kai items, partial allocation, verification statuses), cash received / purchase advance / settlement / final purchase statement, GST, shopping mode + combined shopping list, vendor profiles, user management (email/password, MFA, sessions, security dashboard), record-level / department-level permissions, equipment (computer / camera) + repair & warranty, AI assistant, data inbox workflow, notification read/snooze, desktop scanner agent.

## 3.0.0 — Smart Office, Inventory & Digital Asset Management (Phase 1)

Purana data aur purane features waise hi hai. Upgrade ke steps: `UPGRADE-v3.md`.

### Naya design
- Poora app naye premium shell me: grouped + collapsible sidebar (Overview, Inventory, Storage, Tools, Accounts, Admin), sticky header, breadcrumbs, global search, notification centre, Quick add menu, profile.
- Light theme default (`#6366F1` indigo, `#F5F7FB` background), optional **Midnight** dark theme (header ke moon icon se, smooth switch). Purane 7 color themes Settings me hai.
- Fonts: Inter (English) + Noto Sans Devanagari (Hindi). Lucide icons.
- English / हिन्दी toggle (menu, headings) — header ke language icon se.
- Animations (Motion): page transition, staggered cards, animated counters, chart bars, spring dropdowns, modal / drawer, success checkmark, scanner line, folder expand. `prefers-reduced-motion` pe sab band.
- Phone: bottom navigation (Dashboard, Drives, QR scan button, Search, Menu), bade touch targets, table → cards.
- Reusable components: `components/ui` (Card, Stat, Badge, Bar, Modal, Tabs, Segmented, Empty, Skeleton, Field, Alert, DataTable).
- DataTable: search, sort, column dikhana/chhupana, column resize, bulk select + bulk actions, sticky header, saved view (browser me), CSV export (sab ya chuni rows), pagination, phone cards.
- Theme page paint se pehle lagta hai (flash nahi).

### Dashboard
- Purchase cards (is mahine, kul, delivery baaki, mera paisa baaki + pending demands), storage cards (HDD/SSD, capacity, used/free, available/issued/overdue, risks: almost full / damaged / no backup), 6 mahine ka chart, department-wise issued value, drive status donut, alerts, recent activity (purchases + custody). Widgets dikhana/chhupana (sliders icon).
- Sab number asli records se.

### Hard Disk & SSD Management (naya)
- Har drive: unique Asset ID (`DRV-0001`), Mark number + naam ("Mark 1", "SSD 5"…), HDD / SSD / NVMe / USB / memory card, internal / external, brand, model, serial, capacity, used/free, interface, file system, purchase date, price, bill, warranty, condition, health, department, location, last scan, description, custom fields.
- Bulk create (1–100 ek saath), agla Mark number apne aap, shelf ke khaali slots me apne aap rakhna.
- Duplicate rok **transaction me**: Mark number, serial number, slot (guard documents).
- Grid / Table / Rack view, filters (type, status, department, holder, quick: available / issued / overdue / almost full / no location / never scanned), bulk actions (stickers, recycle bin, export).
- Purchase entry se link — kharcha sirf purchase me ginta hai, drive me dobara nahi.
- Drive profile: overview, custody history, data, files, backups, QR / barcode.

### Issue / Return / Transfer (naya)
- Issue, temporary issue (wapsi tareekh zaroori), return, department transfer, location transfer, repair, damaged, lost, retire, back in service.
- Har badlav **Firestore transaction** me: taaza halat check, ek drive ek waqt me ek hi bande ke paas, slot conflict check, transfer record + audit log ek saath.
- Sender, receiver, purpose, dates, condition, used space, notes, confirmation.
- Printable receipt (Issued by / Received by sign).

### Location & Rack (naya)
- Office → Building → Floor → Room → Rack → Shelf → Slot tree, bulk slots, rename, delete (andar kuch ho to rok).
- Visual rack: occupied / empty / issued-out / damaged slots, khaali slot pe click karke drive rakho.

### Digital Data Catalogue + search (naya)
- Project, title, episode, event, date, year, department, category (Raw Footage, Final Videos, Premiere / After Effects projects, Audio, Photos, Graphics, Documents, Live Broadcasts, Thumbnails, custom), file type, folder path, size, file count, owner, priority, tags, custom metadata.
- Har result me: drive, abhi kiske paas, location, folder, size, backup copies.
- Scan CSV import (Windows PowerShell / Mac Terminal command app me hi), folder explorer, scan history (+added / −removed), used space update. Sirf metadata, koi file upload nahi.
- Global search (Ctrl K ya /): pages, drives, catalogue, items, people, locations, aur file index (Firestore indexed query).

### Backup Management (naya)
- Original ↔ copy mapping, assign → copied → verified / failed, history.
- **Verified sirf tab** jab dono hash barabar ho (aur file count barabar ho); Firestore Rules bhi yahi check karte hai. Single-copy risk, outdated copy, unverified, failed list. CSV report.

### QR & Barcode (naya)
- Har drive ka QR (login ke baad profile kholta hai: `/a/DRV-0001`) aur Code128 barcode.
- A4 sticker sheets: Mark range / chuni drives / sab, har sticker ki kai copy, 5 preset size + custom (size, rows, cols, margins, gaps), 4 design, B/W ya color, aadhi sheet ke liye "skip first labels", print preview (zoom), print / Save as PDF.
- Phone QR scan (BarcodeDetector ya jsQR): Open, Issue, Return, Verify stock (kaunsi mili / missing / galat jagah) + report audit log me. USB barcode scanner bhi chalta hai.

### Roles, permissions, security (naya)
- Roles: Super Admin, Admin, Store Manager, Purchase Manager, Accountant, Data Manager, Editor, Viewer. Permission matrix (view, create, edit, delete, approve, transfer, export, AI) har module ke liye.
- **Firestore Rules me lagu** (`firestore.rules`), aur server API (`/api/read-bill` ko `inventory.ai` chahiye). Jab tak Save nahi kiya, purana tareeka (sab members full access).
- Audit log (sirf create, koi badal / mita nahi sakta), recycle bin (drive / catalogue soft delete, restore, Super Admin permanent delete), input validation (rules + forms), API rate limit, double-submit rok.
- Settings → Team save ab `roles` / `perms` ko nahi mitata (merge).

### Bug fixes / chhote badlav
- Firebase setup screen ab missing env variables ki list dikhata hai.
- PWA naam / rang naye design ke hisaab se.

### Abhi Phase 2 me (is release me nahi)
Vendor management, repair & maintenance module, alag warranty module, computer / camera / studio equipment profiles, team member profiles, departments, purchase approvals workflow, budgets / vendor outstanding, Excel (.xlsx) / PDF reports, database-grounded AI assistant, desktop scanner agent + agent APIs (design: `docs/SCANNER.md`), offline drafts for new modules, drives / catalogue ka Google Sheet sync, server-side pagination + virtual scroll (abhi client-side pagination, ek office ke data ke liye kaafi).
